const BINANCE_BASES = ["https://data-api.binance.vision", "https://api.binance.com", "https://api1.binance.com", "https://api2.binance.com", "https://api3.binance.com", "https://api4.binance.com"];
let spotSymbolsCache = { at: 0, symbols: new Set(), details: [] };
const SPOT_SYMBOL_CACHE_MS = 10 * 60 * 1000;
const TICKER_CACHE_MS = 30 * 1000;
const REQUEST_TIMEOUT_MS = 9000;
let tickerCache = { at: 0, rows: [] };

function safeSymbol(value) {
  const s = String(value || "").toUpperCase();
  return /^[A-Z0-9]{5,30}$/.test(s) ? s : null;
}

function isSpotTradableSymbol(x) {
  if (!x || x.status !== "TRADING") return false;
  if (Array.isArray(x.permissionSets) && x.permissionSets.length) {
    return x.permissionSets.some(set => Array.isArray(set) && set.includes("SPOT"));
  }
  return x.isSpotTradingAllowed !== false;
}

async function getSpotSymbols() {
  const now = Date.now();
  if (spotSymbolsCache.symbols.size && now - spotSymbolsCache.at < SPOT_SYMBOL_CACHE_MS) return spotSymbolsCache.symbols;
  // Some Binance endpoints/regions can return an unexpectedly small exchangeInfo set.
  // Probe the public Spot mirrors and keep the largest healthy universe.
  const errors = [];
  let best = null;
  for (const base of BINANCE_BASES) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    try {
      const res = await fetch(`${base}/api/v3/exchangeInfo?symbolStatus=TRADING`, { headers: { accept: 'application/json' }, signal: controller.signal });
      const data = await res.json().catch(() => ({}));
      if (res.ok && Array.isArray(data.symbols)) {
        const tradable = data.symbols.filter(isSpotTradableSymbol);
        if (!best || tradable.length > best.tradable.length) best = { data, tradable };
      } else errors.push(`${new URL(base).hostname} ${res.status}`);
    } catch (e) { errors.push(`${new URL(base).hostname}: ${e.name === 'AbortError' ? 'timeout' : e.message}`); }
    finally { clearTimeout(timer); }
  }
  if (!best) throw new Error(`Binance exchange info unavailable (${errors.join(' · ')})`);
  const symbols = new Set(best.tradable.map(x => x.symbol));
  spotSymbolsCache = { at: now, symbols, details: best.data.symbols || [] };
  return symbols;
}

async function approvedSpotSymbol(value) {
  const s = safeSymbol(value);
  if (!s) return null;
  try {
    const symbols = await getSpotSymbols();
    return symbols.has(s) ? s : null;
  } catch {
    return s;
  }
}

async function binance(path, params = {}) {
  const qs = new URLSearchParams(params).toString();
  const errors = [];
  for (const base of BINANCE_BASES) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    try {
      const res = await fetch(`${base}${path}${qs ? `?${qs}` : ""}`, {
        headers: { accept: "application/json" }, signal: controller.signal,
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok) return data;
      errors.push(`${new URL(base).hostname} ${res.status}${data.msg ? `: ${data.msg}` : ""}`);
    } catch (e) {
      errors.push(`${new URL(base).hostname}: ${e.name === 'AbortError' ? 'timeout' : e.message}`);
    } finally { clearTimeout(timer); }
  }
  throw new Error(`Binance public Spot data unavailable (${errors.join(" · ")})`);
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=UTF-8",
      "cache-control": "no-store",
      "access-control-allow-origin": "*",
    },
  });
}

async function api(request, env) {
  const url = new URL(request.url);
  const path = url.pathname;

  const bridgePaths=new Set(['/api/integrations/tradingview','/api/integrations/ctrader']);
  if(bridgePaths.has(path)){
    const token=env?.LSAI_BRIDGE_TOKEN;
    if(token && request.headers.get('x-lsai-bridge-token')!==token)return json({error:'Bridge authentication required.'},401);
    const cache=typeof caches!=='undefined'?caches.default:null;
    const source=path.endsWith('tradingview')?'TradingView':'cTrader';
    const key=new Request(`${url.origin}${path}/latest`,{method:'GET'});
    const historyKey=new Request(`${url.origin}${path}/history`,{method:'GET'});
    if(request.method==='POST'){
      let body={};try{body=await request.json();}catch{return json({error:'Expected JSON body.'},400);}
      const symbol=safeSymbol(String(body.symbol||body.ticker||body.pair||'').replace(/\//g,''));
      if(!symbol)return json({error:'Missing valid symbol.'},400);
      const payload={source,symbol,receivedAt:Date.now(),data:body};
      if(cache){
        let history=[];try{const old=await cache.match(historyKey);if(old)history=await old.json();}catch{}
        if(!Array.isArray(history))history=[];
        history.push(payload);history=history.slice(-100);
        await cache.put(key,new Response(JSON.stringify(payload),{headers:{'content-type':'application/json','cache-control':'public, max-age=300'}}));
        await cache.put(historyKey,new Response(JSON.stringify(history),{headers:{'content-type':'application/json','cache-control':'public, max-age=300'}}));
      }
      return json({ok:true,source,symbol,receivedAt:payload.receivedAt,stored:!!cache,historyCount:cache?100:0});
    }
    if(request.method==='GET'){
      const wantsHistory=url.searchParams.get('history')==='1';
      if(cache){const hit=await cache.match(wantsHistory?historyKey:key);if(hit){const data=await hit.json();return json({source,...(wantsHistory?{records:Array.isArray(data)?data:[]} : data),stored:true});}}
      return json({source,...(wantsHistory?{records:[]}:{data:null}),stored:false});
    }
    return json({error:'Method not allowed'},405);
  }
  if (request.method !== "GET") return json({ error: "Method not allowed" }, 405);

  if (path === "/api/bridge/status") {
    let telemetry=globalThis.__LSAI_BRIDGE_TELEMETRY || null;
    try{const cache=typeof caches!=="undefined"?caches.default:null;if(cache){const hit=await cache.match(new Request(`${url.origin}/api/bridge/telemetry/latest`));if(hit)telemetry=await hit.json();}}catch{}
    return json({
      bridgeVersion:"1.0.0", serverVersion:"9.1.0", mode:"simulation-only", spotOnly:true,
      ordersEnabled:false, liveExecution:false, credentialsConfigured:false,
      connected:!!telemetry, lastHeartbeat:telemetry?.timestamp||null,
      telemetry:telemetry?{appVersion:telemetry.appVersion,brainVersion:telemetry.brainVersion,universe:telemetry.universe,candidates:telemetry.candidates,analyzed:telemetry.analyzed,qualified:telemetry.qualified,top:telemetry.top,scanInFlight:telemetry.scanInFlight,backgroundEnabled:telemetry.backgroundEnabled,safety:telemetry.safety}:null
    });
  }
  if (path === "/api/bridge/telemetry") {
    if(request.method!=="POST") return json({error:"Method not allowed"},405);
    let body={}; try{body=await request.json();}catch{return json({error:"Expected JSON body."},400);}
    const clean={
      bridgeVersion:String(body.bridgeVersion||"1.0.0").slice(0,20),appVersion:String(body.appVersion||"").slice(0,20),brainVersion:String(body.brainVersion||"").slice(0,100),timestamp:Date.now(),
      universe:Number(body.universe||0),candidates:Number(body.candidates||0),analyzed:Number(body.analyzed||0),qualified:Number(body.qualified||0),top:Number(body.top||0),scanInFlight:!!body.scanInFlight,backgroundEnabled:!!body.backgroundEnabled,
      safety:{liveLocked:true,credentialsConfigured:false,ordersEnabled:false}
    };
    globalThis.__LSAI_BRIDGE_TELEMETRY=clean;
    try{
      const cache=typeof caches!=="undefined"?caches.default:null;
      if(cache){await cache.put(new Request(`${url.origin}/api/bridge/telemetry/latest`),new Response(JSON.stringify(clean),{headers:{"content-type":"application/json","cache-control":"no-store"}}));}
    }catch{}
    return json({ok:true,bridgeVersion:"1.0.0",receivedAt:clean.timestamp});
  }

  if (path === "/api/health") {
    return json({
      mode: "simulation-only",
      spotOnly: true,
      ordersEnabled: false,
      credentialsConfigured: false,
      readOnlyMarketData: true,
      chartApi: true,
      dataSources: BINANCE_BASES.length,
      requestTimeoutMs: REQUEST_TIMEOUT_MS,
      tickerCacheMs: TICKER_CACHE_MS,
      exchangeInfoCacheMs: SPOT_SYMBOL_CACHE_MS,
    });
  }

  if (path === "/api/diagnostics") {
    const checks=[];
    try { const d=await binance("/api/v3/ping"); checks.push({name:"Binance connectivity",ok:!!d}); } catch(e) { checks.push({name:"Binance connectivity",ok:false,error:e.message}); }
    try { const rows=await binance("/api/v3/exchangeInfo",{symbolStatus:"TRADING"}); checks.push({name:"Spot exchange info",ok:Array.isArray(rows.symbols)&&rows.symbols.length>0,count:Array.isArray(rows.symbols)?rows.symbols.length:0}); } catch(e) { checks.push({name:"Spot exchange info",ok:false,error:e.message}); }
    return json({version:"9.1.0",mode:"simulation-only",checks});
  }

  if (path === "/api/exchange-info") {
    try {
      await getSpotSymbols();
      let symbols = spotSymbolsCache.details.filter(isSpotTradableSymbol).map(x => ({ symbol:x.symbol, baseAsset:x.baseAsset, quoteAsset:x.quoteAsset, status:x.status, isSpotTradingAllowed:true, permissionSets:x.permissionSets }));
      // Some regional/edge responses can return a truncated exchangeInfo. Fuse it with
      // the Spot 24h ticker universe so the application does not mistake a partial
      // exchangeInfo response for the complete Spot market universe.
      try {
        const rows = await binance("/api/v3/ticker/24hr");
        if (Array.isArray(rows)) {
          const by = new Map(symbols.map(x => [x.symbol, x]));
          for (const t of rows) {
            const symbol = String(t?.symbol || "").toUpperCase();
            if (!symbol || by.has(symbol)) continue;
            // Ticker rows come from the Spot REST endpoint, so they are valid market-data symbols.
            const match = symbol.match(/^([A-Z0-9]{1,20})(USDT|USDC|FDUSD|DAI|TUSD|USDP|USDS|EUR|TRY|BRL|GBP|AUD|JPY|PLN|RON|ZAR|UAH|NGN|RUB|MXN|ARS|IDR|VND|THB|BIDR|COP|CLP)$/);
            if (!match) continue;
            by.set(symbol, { symbol, baseAsset: match[1], quoteAsset: match[2], status:"TRADING", isSpotTradingAllowed:true, source:"spot-ticker" });
          }
          symbols = [...by.values()];
        }
      } catch (_) {}
      return json({ source: "Binance Spot public API + ticker universe fusion", cachedForMs: SPOT_SYMBOL_CACHE_MS, symbols });
    } catch (e) {
      return json({ error: e.message }, 502);
    }
  }

  if (path === "/api/tickers") {
    const now = Date.now();
    if (tickerCache.rows.length && now - tickerCache.at < TICKER_CACHE_MS) {
      return json({ source:"Binance Spot public API", cached:true, cachedForMs:TICKER_CACHE_MS, tickers:tickerCache.rows });
    }
    try {
      const rows = await binance("/api/v3/ticker/24hr");
      const tickers = Array.isArray(rows) ? rows.map(x => ({
        symbol:x.symbol, price:Number(x.lastPrice), change:Number(x.priceChangePercent), quoteVolume:Number(x.quoteVolume), volume:Number(x.volume),
      })).filter(x => x.symbol && Number.isFinite(x.price)) : [];
      tickerCache = { at: now, rows: tickers };
      return json({ source:"Binance Spot public API", cached:false, cachedForMs:TICKER_CACHE_MS, tickers });
    } catch (e) {
      if (tickerCache.rows.length) return json({ source:"Binance Spot public API", cached:true, stale:true, cachedForMs:TICKER_CACHE_MS, tickers:tickerCache.rows });
      return json({ error:e.message }, 502);
    }
  }

  if (path === "/api/market") {
    const symbol = safeSymbol(url.searchParams.get("symbol"));
    if (!symbol) return json({ error: "Use an approved Spot symbol." }, 400);
    try {
      const d = await binance("/api/v3/ticker/24hr", { symbol });
      return json({
        symbol,
        price: Number(d.lastPrice),
        change: Number(d.priceChangePercent),
        source: "Binance Spot public API",
      });
    } catch (e) {
      return json({ error: e.message }, 502);
    }
  }

  if (path === "/api/candles") {
    const symbol = safeSymbol(url.searchParams.get("symbol"));
    const interval = url.searchParams.get("interval") || "4h";
    const rawLimit = Number(url.searchParams.get("limit") || 240);
    const limit = Math.min(Math.max(Number.isFinite(rawLimit) ? rawLimit : 240, 50), 1000);
    const startTime = Number(url.searchParams.get("startTime"));
    const endTime = Number(url.searchParams.get("endTime"));
    if (!symbol || !["1m","3m","5m","15m","30m","1h","2h","4h","6h","8h","12h","1d","3d","1w","1M"].includes(interval)) {
      return json({ error: "Use an approved symbol and supported interval." }, 400);
    }
    try {
      const params = { symbol, interval, limit };
      if (Number.isFinite(startTime)) params.startTime = Math.floor(startTime);
      if (Number.isFinite(endTime)) params.endTime = Math.floor(endTime);
      const rows = await binance("/api/v3/klines", params);
      return json({
        symbol,
        interval,
        source: "Binance Spot public API",
        candles: rows.map(r => ({
          openTime: r[0],
          open: Number(r[1]),
          high: Number(r[2]),
          low: Number(r[3]),
          close: Number(r[4]),
          volume: Number(r[5]),
          closeTime: r[6],
        })),
      });
    } catch (e) {
      return json({ error: e.message }, 502);
    }
  }

  return null;
}

async function scheduled(env, controller) {
  // Server-side heartbeat: keep public Spot data warm even when no browser is open.
  // The browser remains responsible for localStorage-based learning/validation engines.
  try { await getSpotSymbols(); } catch (_) {}
  try { await binance("/api/v3/ticker/24hr"); } catch (_) {}
  return { ok: true, at: Date.now(), cron: controller?.cron || null, mode: "simulation-only" };
}

export default {
  async scheduled(controller, env, ctx) {
    ctx.waitUntil(scheduled(env, controller));
  },
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api/")) {
      const response = await api(request, env);
      if (response) return response;
    }

    // Serve the existing SPA/static assets from the same Worker.
    // Keep app assets fresh after each deployment so the browser does not retain an old broken chart build.
    const assetResponse = await env.ASSETS.fetch(request);
    const type = assetResponse.headers.get("content-type") || "";
    if (type.includes("text/html") || type.includes("javascript") || type.includes("text/css")) {
      const headers = new Headers(assetResponse.headers);
      headers.set("cache-control", "no-store, max-age=0");
      return new Response(assetResponse.body, { status: assetResponse.status, statusText: assetResponse.statusText, headers });
    }
    return assetResponse;
  },
};
