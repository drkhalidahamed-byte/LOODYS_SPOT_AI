const DEFAULT_API_BASE=(location.protocol==='capacitor:'?'http://127.0.0.1:8765':location.origin).replace(/\/$/,'');
const EXPLICIT_API_BASE=(window.LSAI_API_BASE||'').replace(/\/$/,'');
// v7.24.4: never trust stale localStorage API addresses. The deployed Worker is the primary same-origin API.
const API_BASE=/^https?:\/\//i.test(EXPLICIT_API_BASE)?EXPLICIT_API_BASE:DEFAULT_API_BASE;
async function apiFetch(path,options={}){
  const maxAttempts=Number(options.retryAttempts||3);
  const timeoutMs=Math.max(3000,Number(options.timeoutMs||12000));
  const fetchOptions={...options}; delete fetchOptions.retryAttempts; delete fetchOptions.timeoutMs;
  let last;
  for(let attempt=1;attempt<=maxAttempts;attempt++){
    const controller=new AbortController();
    const priorSignal=fetchOptions.signal;
    const timer=setTimeout(()=>controller.abort(),timeoutMs);
    try{
      const r=await fetch(`${API_BASE}${path}`,{...fetchOptions,signal:priorSignal||controller.signal});
      if(r.ok||attempt===maxAttempts||![429,502,503,504].includes(r.status)) return r;
      last=new Error(`HTTP ${r.status}`);
    }catch(e){last=e?.name==='AbortError'?new Error(`Request timeout after ${Math.round(timeoutMs/1000)}s`):e; if(attempt===maxAttempts) throw last;}
    finally{clearTimeout(timer);}
    await new Promise(res=>setTimeout(res,Math.min(1200,200*Math.pow(2,attempt-1))));
  }
  throw last||new Error('API request failed');
}
const APP_VERSION='9.1.3';
const DEFAULT={
  strategyName:'Conservative Swing', budget:1000,dealAmount:100,quote:'USDT',tradeCycleMode:'auto',trendCycleTarget:0.8,trendCyclePartial:30,trendCycleReentryScore:72,trendCycleMaxCycles:4,trendCycleTrail:0.7,positionMode:'dynamic',risk:2,tp:4.5,sl:2,holding:'auto',reviewInterval:5,autoOpen:false,autoTradeMode:'off',autoTradeArmed:false,liveTradingAcknowledged:false,
  watchlist:'BTC/USDT, ETH/USDT, SOL/USDT, BNB/USDT',quoteAssets:['USDT','USDC','FDUSD','DAI'],timeframe:'4h',timeframeMode:'auto',multiTimeframe:true,confirmationTimeframes:['1h','1d','1w'],timeframeProfiles:{fast:['1m','3m','5m','15m'],intraday:['15m','30m','1h','2h','4h'],swing:['4h','6h','8h','12h','1d','3d'],position:['1d','3d','1w']},strategyEnsemble:true,ensembleMinAgreement:2,minSignalScore:3,validationMode:'simulation',shadowEnabled:false,maxOpenPositions:null,dailyLossLimit:3,maxExposure:50,cooldownMinutes:60,slippage:0.2,minQuoteVolume:1000000,maxScanPairs:'auto',maxProjectPairs:'auto',maxOpportunities:'auto',minOpportunityScore:68,scanConcurrency:'auto',aiConsensusThreshold:68,autoSelection:true,
  assetUniverse:{stable:true,ai:true,l1:true,l2:true,defi:true,depin:true,rwa:true,gaming:false,infra:true,payments:true,meme:false},
  indicators:{utbot:{enabled:true,keyValue:1,atrPeriod:10,source:'close'},rsi:{enabled:true,period:14,threshold:38},ema:{enabled:true,period:20},macd:{enabled:true,fast:12,slow:26,signal:9},fractals:{enabled:true,lookback:2},volume:{enabled:true,multiplier:1.2},atr:{enabled:true,period:14,stopMultiplier:2},adx:{enabled:true,period:14,min:18},bollinger:{enabled:true,period:20,multiplier:2},ichimoku:{enabled:true,conversion:9,base:26,spanB:52,displacement:26}}
};
let savedSettings={};
try{savedSettings=JSON.parse(localStorage.getItem('lsai-settings')||'{}')||{};}catch(e){savedSettings={};}
const mergeDefaults=(base,extra)=>{const out={...base};for(const [k,v] of Object.entries(extra||{})){if(v&&typeof v==='object'&&!Array.isArray(v)&&base[k]&&typeof base[k]==='object'&&!Array.isArray(base[k]))out[k]=mergeDefaults(base[k],v);else out[k]=v;}return out;};
let settings=mergeDefaults(DEFAULT,savedSettings);
const CONTROL_ROOM_KEY='lsai-control-room-v1';
const CONTROL_DEFAULT={profile:'balanced',scoreFloor:68,aiFloor:68,confidenceFloor:75,riskFloor:68,rrFloor:1.45,maxUncertainty:42,externalWeight:2,learningWeight:1,strictAbstention:true};
let controlPolicy=CONTROL_DEFAULT;
try{controlPolicy=mergeDefaults(CONTROL_DEFAULT,JSON.parse(localStorage.getItem(CONTROL_ROOM_KEY)||'{}')||{});}catch{controlPolicy=CONTROL_DEFAULT;}
function persistControlPolicy(){localStorage.setItem(CONTROL_ROOM_KEY,JSON.stringify(controlPolicy));}
function controlProfileDefaults(profile){return profile==='defensive'?{scoreFloor:74,aiFloor:74,confidenceFloor:82,riskFloor:75,rrFloor:1.7,maxUncertainty:32,externalWeight:1,learningWeight:1,strictAbstention:true}:profile==='opportunity'?{scoreFloor:68,aiFloor:68,confidenceFloor:75,riskFloor:68,rrFloor:1.45,maxUncertainty:42,externalWeight:2,learningWeight:1,strictAbstention:true}:CONTROL_DEFAULT;}

let autoProjectPairs=[];
try{autoProjectPairs=JSON.parse(localStorage.getItem('lsai-auto-project-pairs')||'[]');if(!Array.isArray(autoProjectPairs))autoProjectPairs=[];}catch{autoProjectPairs=[];}

// v7.1: AUTO is the canonical mode for candidate pool, ranking capacity, and open-position capacity.
settings.maxScanPairs='auto'; settings.maxOpportunities='auto'; settings.maxOpenPositions=null;
// Never allow a stale/empty localStorage value to remove the core Spot pairs.
if(!String(settings.watchlist||'').trim()) settings.watchlist=DEFAULT.watchlist;
// v6.4 migration: automatic discovery/project selection must never inflate the manual watchlist.
// Keep a compact manual list while the full Binance Spot universe remains available to AUTO scans.
const _legacyWatchPairs=String(settings.watchlist||'').split(',').map(x=>String(x).trim()).filter(Boolean);
if(_legacyWatchPairs.length>20 && settings.autoSelection!==false) settings.watchlist=_legacyWatchPairs.slice(0,12).join(', ');
settings.quoteAssets=[...new Set([...(settings.quoteAssets||[]),settings.quote||'USDT'].map(x=>String(x).toUpperCase()).filter(Boolean))];
settings.positionMode=settings.positionMode==='manual'?'manual':'dynamic';
settings.autoTradeMode=['off','paper','live'].includes(String(settings.autoTradeMode))?String(settings.autoTradeMode):'off'; settings.autoTradeArmed=settings.autoTradeArmed===true; settings.liveTradingAcknowledged=settings.liveTradingAcknowledged===true;
settings.maxScanPairs=(String(settings.maxScanPairs).toLowerCase()==='auto'||!Number.isFinite(Number(settings.maxScanPairs)))?'auto':Math.max(10,Math.min(200,Number(settings.maxScanPairs)));
settings.maxOpportunities=(String(settings.maxOpportunities).toLowerCase()==='auto'||!Number.isFinite(Number(settings.maxOpportunities)))?'auto':Math.max(5,Math.min(100,Number(settings.maxOpportunities)));
settings.minQuoteVolume=Number.isFinite(Number(settings.minQuoteVolume))?Number(settings.minQuoteVolume):DEFAULT.minQuoteVolume;
settings.minOpportunityScore=Number(settings.minOpportunityScore)||DEFAULT.minOpportunityScore;
settings.scanConcurrency=(String(settings.scanConcurrency).toLowerCase()==='auto'||!Number.isFinite(Number(settings.scanConcurrency)))?'auto':Number(settings.scanConcurrency)||DEFAULT.scanConcurrency;
settings.aiConsensusThreshold=Number(settings.aiConsensusThreshold)||DEFAULT.aiConsensusThreshold;
settings.multiTimeframe=settings.multiTimeframe!==false;
settings.confirmationTimeframes=[...new Set((settings.confirmationTimeframes||DEFAULT.confirmationTimeframes).map(String).filter(x=>['1m','3m','5m','15m','30m','1h','2h','4h','6h','8h','12h','1d','3d','1w','1M'].includes(x)))];
if(!settings.confirmationTimeframes.length) settings.confirmationTimeframes=[...DEFAULT.confirmationTimeframes];
settings.indicators={...DEFAULT.indicators,...(settings.indicators||{})};
autoProjectPairs=[...new Set(autoProjectPairs.map(normalizePair).filter(Boolean))];

for(const k of Object.keys(DEFAULT.indicators)) settings.indicators[k]={...DEFAULT.indicators[k],...(settings.indicators[k]||{})};
function readArray(key){try{const v=JSON.parse(localStorage.getItem(key)||'[]');return Array.isArray(v)?v:[]}catch{return []}}
let balance=Number(localStorage.getItem('lsai-balance')||settings.budget),positions=readArray('lsai-positions'),closedTrades=readArray('lsai-closed-trades');
let pending=null,reviewTimer=null;
let dailyStats;try{dailyStats=JSON.parse(localStorage.getItem('lsai-daily-stats')||'{"date":"","realizedPnl":0,"entries":0}')||{};}catch{dailyStats={};}dailyStats={date:String(dailyStats.date||''),realizedPnl:Number(dailyStats.realizedPnl)||0,entries:Number(dailyStats.entries)||0};
function todayKey(){return new Date().toISOString().slice(0,10)}
function rollDailyStats(){if(dailyStats.date!==todayKey()){dailyStats={date:todayKey(),realizedPnl:0,entries:0};localStorage.setItem('lsai-daily-stats',JSON.stringify(dailyStats));}}
function currentExposure(){return positions.reduce((s,p)=>s+p.amount,0);}
function exposurePct(){return settings.budget?currentExposure()/settings.budget*100:0;}
function safetyStatus(){rollDailyStats();const lossPct=settings.budget?Math.max(0,-dailyStats.realizedPnl/settings.budget*100):0;return {lossPct,lossBreached:lossPct>=settings.dailyLossLimit,exposurePct:exposurePct(),exposureBreached:exposurePct()>=settings.maxExposure};}
function lastEntryAt(pair){const symbol=pairParts(pair).symbol||String(pair||'').replace('/','');const p=positions.find(x=>x.symbol===symbol||x.coin===pair);return p?.openedAt||0;}
const markets=[]; let exchangeSymbols=[];
let scanCandidates=[];
let qualifiedOpportunities=[];
let selectedOpportunities=[];
let lastScanStats={universe:0,candidates:0,analyzed:0,qualified:0,top:0};
// v7.24.9 performance layer: reuse short-lived public market snapshots instead of re-downloading
// unchanged 4h candles/tickers during repeated scans and auto-review cycles.
const CLIENT_TICKER_TTL=30*1000, CLIENT_CANDLE_TTL=75*1000, CLIENT_MTF_TTL=90*1000;
const clientTickerCache={at:0,rows:[]};
const clientCandleCache=new Map();
const clientMtfCache=new Map();
let scanInFlight=false;
function normalizePair(v){const raw=String(v||'').trim().toUpperCase().replace(/[-_]/g,'/'); if(raw.includes('/')){const [b,q]=raw.split('/'); return b&&q?`${b}/${q}`:'';} const qs=(settings.quoteAssets||[settings.quote||'USDT']).sort((a,b)=>b.length-a.length); const q=qs.find(x=>raw.endsWith(x)); return q?`${raw.slice(0,-q.length)}/${q}`:raw;}
function watchPairs(){
  const pairs=String(settings.watchlist||'').split(',').map(normalizePair).filter(x=>x.includes('/')&&pairParts(x).base&&pairParts(x).quote);
  return [...new Set(pairs)];
}
function ensureCorePairs(){
  if(watchPairs().length===0){settings.watchlist=DEFAULT.watchlist; persist();}
}
function pairParts(pair){const [base,quote]=normalizePair(pair).split('/');return {base,quote,symbol:base&&quote?base+quote:''};}
function ensureMarket(pair){const {base,quote,symbol}=pairParts(pair); let m=markets.find(x=>x.symbol===symbol); if(!m){m={coin:base,base,quote,symbol,price:0,change:0,rsi:50,trend:false,fractal:false,ut:'neutral',macd:false,volume:false,atr:false,adx:0,adxBull:false,bbPosition:50,bbWidth:0,ichimokuScore:50,ichimokuBull:false,ichimokuBear:false};markets.push(m);} return m;}
const UNIVERSE_CACHE_KEY='lsai-spot-universe-cache-v1';
const UNIVERSE_CACHE_TTL=1000*60*60*12;
function saveUniverseCache(list,source='Binance public Spot market data'){
  try{
    localStorage.setItem(UNIVERSE_CACHE_KEY,JSON.stringify({version:1,savedAt:Date.now(),source,symbols:Array.isArray(list)?list:[]}));
  }catch(e){addLog(`Spot Universe cache save skipped: ${e.message}`);}
}
function loadUniverseCache(){
  try{
    const raw=localStorage.getItem(UNIVERSE_CACHE_KEY); if(!raw)return false;
    const c=JSON.parse(raw); const list=Array.isArray(c?.symbols)?c.symbols:[];
    if(!list.length)return false;
    universeSymbols=list; exchangeSymbols=list;
    list.forEach(x=>ensureMarket(`${x.baseAsset}/${x.quoteAsset}`));
    renderUniverse(list);
    const age=Date.now()-Number(c.savedAt||0);
    const when=c.savedAt?new Date(c.savedAt).toLocaleString():'';
    const status=$('#universeStatus'); if(status) status.textContent=`Cached Spot Universe: ${list.length.toLocaleString()} pairs · saved ${when} · click Refresh to update`;
    const pairStatus=$('#pairStatus'); if(pairStatus) pairStatus.textContent='Cached Binance Spot Universe restored. Use Refresh to update market-pair metadata.';
    const btn=$('#discoverAssets'); if(btn) btn.textContent='Refresh Binance Spot pairs';
    addLog(`Binance Spot cache restored: ${list.length.toLocaleString()} pairs${age>UNIVERSE_CACHE_TTL?' · cache older than 12 hours':''}.`);
    return true;
  }catch(e){return false;}
}
function clearUniverseCache(){try{localStorage.removeItem(UNIVERSE_CACHE_KEY);}catch{}}
const $=s=>document.querySelector(s), money=(v,q=settings.quote)=>`${Number(v).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})} ${q}`;
function persist(){localStorage.setItem('lsai-settings',JSON.stringify(settings));localStorage.setItem('lsai-auto-project-pairs',JSON.stringify(autoProjectPairs));localStorage.setItem('lsai-daily-stats',JSON.stringify(dailyStats));localStorage.setItem('lsai-balance',balance);localStorage.setItem('lsai-positions',JSON.stringify(positions));localStorage.setItem('lsai-closed-trades',JSON.stringify(closedTrades));}
function addLog(text){const log=JSON.parse(localStorage.getItem('lsai-log')||'[]');log.unshift({text,time:new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})});localStorage.setItem('lsai-log',JSON.stringify(log.slice(0,12)));renderLog();}
let activityLogExpanded=false;
function renderLog(){const log=JSON.parse(localStorage.getItem('lsai-log')||'[]');const items=log.length?log:[{text:'MVP initialized - simulation mode only.',time:'Now'}];const visible=activityLogExpanded?items:items.slice(0,5);const box=$('#activityLog');if(box)box.innerHTML=visible.map(x=>`<li>${x.text}<time>${x.time}</time></li>`).join('');const count=$('#activityCount');if(count)count.textContent=log.length?`${log.length}`:'0';const btn=$('#toggleActivityLog');if(btn){btn.textContent=activityLogExpanded?'إخفاء':'عرض الكل';btn.setAttribute('aria-expanded',activityLogExpanded?'true':'false');btn.disabled=items.length<=5;}}
function renderMLMonitor(){const box=$('#mlMonitorPanel');if(!box)return;const m=currentQualifiedOpportunities()[0]||selectedOpportunities.map(x=>markets.find(y=>y.symbol===pairParts(x).symbol)).find(Boolean)||markets.find(x=>x.candles?.length);const prob=m?.mlProbability;$('#mlProbability').textContent=Number.isFinite(Number(prob))?Number(prob).toFixed(1)+'%':'—';$('#mlSamples').textContent=m?.mlSamples?Number(m.mlSamples).toLocaleString():'—';$('#mlAccuracy').textContent=Number.isFinite(Number(m?.mlOosAccuracy))&&m?.mlOosAccuracy?Number(m.mlOosAccuracy).toFixed(1)+'%':'—';$('#mlDrift').textContent=m?.mlDrift?`${m.mlDrift.status} · ${m.mlDrift.score}`:'—';$('#mlBaseline').textContent=Number.isFinite(Number(m?.mlBaselineAccuracy))&&m?.mlBaselineAccuracy?Number(m.mlBaselineAccuracy).toFixed(1)+'%':'—';$('#mlBrier').textContent=Number.isFinite(Number(m?.mlBrier))&&m?.mlBrier?Number(m.mlBrier).toFixed(3):'—';$('#mlPR').textContent=(m?.mlPrecision&&m?.mlRecall)?`${Number(m.mlPrecision).toFixed(0)}% / ${Number(m.mlRecall).toFixed(0)}%`:'—';const fm=feedbackModel();$('#mlFeedbackSamples').textContent=fm?.samples?Number(fm.samples).toLocaleString():'—';$('#mlFeedbackStatus').textContent=fm?.status||'NOT_READY';$('#mlMonitorStatus').textContent=m?`ML ${m.mlStatus||'INSUFFICIENT_DATA'} · ${m.base}/${m.quote}`:'Waiting for scan';}
function renderAdaptiveArchitecture(){
  const candidates=[...selectedOpportunities,...qualifiedOpportunities,...lastNearMisses.map(x=>`${x.m.base}/${x.m.quote}`)];
  const m=candidates.map(p=>markets.find(x=>x.symbol===pairParts(p).symbol)).find(Boolean)||markets.find(x=>x.candles?.length);
  if(!m){['regimeMetric','metaMetric','uncertaintyMetric','riskMultiplierMetric','concentrationMetric','abstentionMetric'].forEach(id=>{const e=$('#'+id);if(e)e.textContent='—';});return;}
  const o=opportunityScore(m),pi=portfolioIntelligence(m);
  $('#regimeMetric').textContent=`${o.regime||'—'} · ${o.regimeFit||0}/100`;
  $('#metaMetric').textContent=`${o.metaScore||0}/100`;
  $('#uncertaintyMetric').textContent=`${Number(o.uncertainty||0).toFixed(0)}%`;
  $('#riskMultiplierMetric').textContent=`${Number(o.riskMultiplier||1).toFixed(2)}×`;
  $('#concentrationMetric').textContent=`${pi.score}/100`;
  $('#abstentionMetric').textContent=o.abstain?'NO TRADE':'ELIGIBLE TO REVIEW';
  $('#architectureStatus').textContent=`${m.base}/${m.quote} · ${o.regime||'—'} · ${o.abstain?'ABSTAIN':'ACTIVE'}`;
}
function renderPerformance(){const total=closedTrades.length,wins=closedTrades.filter(t=>t.pnl>0).length,net=closedTrades.reduce((s,t)=>s+t.pnl,0),worst=total?Math.min(...closedTrades.map(t=>t.returnPct)):0;$('#performanceResults').innerHTML=`<article><span>Closed trades</span><strong>${total}</strong></article><article><span>Win rate</span><strong>${total?(wins/total*100).toFixed(1):'0.0'}%</strong></article><article><span>Net simulated P/L</span><strong class="${net>=0?'positive':'negative'}">${net>=0?'+':''}${money(net)}</strong></article><article><span>Worst closed trade</span><strong class="negative">${worst.toFixed(2)}%</strong></article>`;$('#closedTrades').innerHTML=closedTrades.slice(0,7).map(t=>`<li><strong>${t.coin}/${settings.quote}</strong> - ${t.reason}<time class="${t.pnl>=0?'positive':'negative'}">${t.pnl>=0?'+':''}${money(t.pnl)} - ${new Date(t.closedAt).toLocaleString()}</time></li>`).join('')||'<li>No simulated exits yet.<time>Adaptive exits will appear here.</time></li>';$('#reviewStatus').textContent=`Auto review: every ${settings.reviewInterval} min`;}
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function marketRegime(m){
  const adx=Number(m?.adx||0), vol=Number(m?.volatilityPct||0), slope=Number(m?.emaSlope||0), bb=Number(m?.bbWidth||0), mom=Number(m?.momentum||0);
  let regime='RANGE', fit=58, riskMultiplier=0.75, allowed=true;
  if(vol>=9 || (vol>=7 && Math.abs(mom)>=8)){regime='PANIC';fit=22;riskMultiplier=0.30;allowed=false;}
  else if(adx>=25 && slope>0.08 && mom>0){regime='TREND_UP';fit=94;riskMultiplier=1.00;}
  else if(adx>=25 && slope<-0.08){regime='TREND_DOWN';fit=18;riskMultiplier=0.25;allowed=false;}
  else if(vol>=5.5 || bb>=10){regime='HIGH_VOL';fit=52;riskMultiplier=0.55;}
  else if(adx<16){regime='LOW_TREND';fit=48;riskMultiplier=0.60;}
  else if(slope>0 && mom>0){regime='EARLY_UP';fit=82;riskMultiplier=0.85;}
  const confidence=clamp(45+adx*1.5+Math.abs(slope)*18+Math.abs(mom)*1.2,0,100);
  return {regime,fit,riskMultiplier,allowed,confidence};
}
function portfolioIntelligence(m){
  const sameQuote=positions.filter(p=>p.quote===m?.quote).length;
  const sameBase=positions.filter(p=>p.base===m?.base||p.coin===m?.base).length;
  const directional=positions.filter(p=>Number(p.score||0)>=68).length;
  const concentration=clamp(100-sameQuote*14-sameBase*30-directional*4,35,100);
  const headroom=clamp(100-(currentExposure()/Math.max(1,settings.budget))*100,0,100);
  return {concentration,headroom,score:Math.round(concentration*.65+headroom*.35),sameQuote,sameBase};
}
function metaDecisionLayer(m,components){
  const regime=m?.regimeInfo||marketRegime(m), portfolio=portfolioIntelligence(m);
  const data=Number(m?.dataQuality??100), mtf=Number(m?.mtfScore??50), align=Number(m?.mtfAlignment??50), drift=String(m?.mlDrift?.status||'INSUFFICIENT_DATA');
  const uncertainty=clamp(100-(data*.35+align*.25+regime.confidence*.20+portfolio.score*.20),0,100);
  const mlPenalty=['DRIFTED','WEAK_MODEL'].includes(drift)?18:0;
  const score=Math.round(clamp(regime.fit*.28+data*.20+mtf*.17+align*.10+portfolio.score*.15+(100-uncertainty)*.10-mlPenalty,0,100));
  const abstain=!regime.allowed || data<80 || align<45 || uncertainty>42 || portfolio.score<45;
  return {score,uncertainty,abstain,regime,portfolio};
}
function aiConsensus(m,o){
  const technical=clamp(Number(o?.signalPct||0),0,100);
  const trend=clamp((Number(m.trendStrength||0)/12)*100,0,100);
  const momentum=clamp((Number(m.momentum||0)+12)/24*100,0,100);
  const volume=clamp((Number(m.volumeRatio||1)-0.75)/1.75*100,0,100);
  const liquidity=m.quoteVolume>0?clamp((Math.log10(Math.max(1,m.quoteVolume))-5)/4*100,0,100):35;
  const regimeInfo=m.regimeInfo||marketRegime(m), regime=regimeInfo.fit;
  const volatility=Number(m.volatilityPct||0);
  const risk=clamp(100-(Math.abs(Number(m.momentum||0))*2.5 + Math.max(0,volatility-55)*1.5),0,100)*regimeInfo.riskMultiplier;
  const correlation=portfolioIntelligence(m).concentration;
  const portfolio=portfolioIntelligence(m).headroom;
  const mlStatus=String(m.mlStatus||'INSUFFICIENT_DATA');
  const ml=mlStatus==='READY'||mlStatus==='ADAPTIVE'?clamp(Number(m.mlProbability??50),0,100):50;
  const mlWeight=(mlStatus==='ADAPTIVE'||mlStatus==='READY')?0.08:0;
  const baseWeight=1-mlWeight;
  const base=(technical*.11+trend*.14+momentum*.12+volume*.09+liquidity*.10+regime*.12+risk*.15+correlation*.07+portfolio*.10);
  const consensus=Math.round(clamp(base*baseWeight+ml*mlWeight,0,100));
  const components={technical,trend,momentum,volume,liquidity,regime,risk,correlation,portfolio,ml,mlWeight};
  return {consensus,...components};
}


// v7.27: Champion / Challenger engine. Profiles compete on every analyzed setup;
// promotion requires real resolved shadow evidence, not in-sample optimism.
const CHALLENGER_KEY='lsai-champion-challenger-v1';
const MODEL_PROFILES={
  BALANCED:{label:'Balanced',weights:{score:.42,ai:.18,mtf:.12,risk:.12,meta:.10,rr:.06}},
  TREND:{label:'Trend',weights:{score:.30,ai:.14,mtf:.20,risk:.14,meta:.10,rr:.12}},
  DEFENSIVE:{label:'Defensive',weights:{score:.24,ai:.14,mtf:.10,risk:.25,meta:.17,rr:.10}}
};
function defaultChampionState(){return {version:1,champion:'BALANCED',promotedAt:0,models:Object.fromEntries(Object.keys(MODEL_PROFILES).map(k=>[k,{trials:0,wins:0,returns:[],brier:[],lastAt:0}]))};}
function championState(){try{const x=JSON.parse(localStorage.getItem(CHALLENGER_KEY)||'null');if(!x?.models)return defaultChampionState();return x;}catch{return defaultChampionState();}}
function saveChampionState(x){try{localStorage.setItem(CHALLENGER_KEY,JSON.stringify(x));}catch{}}
function modelScore(profile,m,o){const w=profile.weights;const rr=clamp(Number(o.rewardRisk||0)/2*100,0,100);return Math.round(clamp(Number(o.score||50)*w.score+Number(o.aiConsensus||50)*w.ai+Number(o.mtfScore||50)*w.mtf+Number(o.riskScore||50)*w.risk+Number(o.metaScore||50)*w.meta+rr*w.rr,0,100));}
function championStatsSummary(){const st=championState();return Object.entries(st.models).map(([key,v])=>{const trials=Number(v.trials||0),wins=Number(v.wins||0),avg=v.returns?.length?v.returns.reduce((a,b)=>a+Number(b||0),0)/v.returns.length:0;const winRate=trials?wins/trials*100:50;const uncertainty=trials?Math.max(0,12-Math.min(12,Math.sqrt(trials))):12;const posterior=winRate+Math.max(-3,Math.min(3,avg))*1.5-uncertainty;return {key,label:MODEL_PROFILES[key]?.label||key,trials,wins,avg,winRate,posterior};}).sort((a,b)=>b.posterior-a.posterior);}
function championChallenger(m,o){const st=championState(), scores=Object.fromEntries(Object.entries(MODEL_PROFILES).map(([k,p])=>[k,modelScore(p,m,o)]));const summaries=championStatsSummary();const champion=st.champion||'BALANCED';const bestEvidence=summaries[0]?.key||champion;const championEvidence=summaries.find(x=>x.key===champion)||summaries[0];let active=champion;
  // Exploration is deliberately bounded. A challenger can be preferred only after evidence.
  if(championEvidence&&championEvidence.trials>=20&&bestEvidence!==champion){const best=summaries[0];if(best.trials>=10&&best.posterior>championEvidence.posterior+2)active=best.key;}
  const activeScore=scores[active]||scores[champion]||50;return {active,champion,activeScore,scores,summaries,promotionCandidate:bestEvidence!==champion?bestEvidence:null};}
function recordChampionOutcome(entry){if(!entry?.modelScores||!Number.isFinite(Number(entry.realizedPct)))return;const st=championState();for(const key of Object.keys(MODEL_PROFILES)){const score=Number(entry.modelScores[key]??50), prob=clamp(score/100,0,1), ret=Number(entry.realizedPct||0), v=st.models[key]||{trials:0,wins:0,returns:[],brier:[],lastAt:0};v.trials++;if(ret>0)v.wins++;v.returns=[...(v.returns||[]),ret].slice(-80);v.brier=[...(v.brier||[]),Math.pow(prob-(ret>0?1:0),2)].slice(-80);v.lastAt=Date.now();st.models[key]=v;}
  const summaries=championStatsSummary();const current= summaries.find(x=>x.key===st.champion);const candidate=summaries.find(x=>x.key!==st.champion);if(current&&candidate&&current.trials>=20&&candidate.trials>=20&&candidate.posterior>current.posterior+2){st.champion=candidate.key;st.promotedAt=Date.now();addLog(`Champion promoted: ${MODEL_PROFILES[candidate.key].label} replaced ${MODEL_PROFILES[current.key].label} after resolved shadow evidence.`);}saveChampionState(st);}
function renderChampionChallenger(){const box=$('#championChallengerPanel');if(!box)return;const st=championState(),rows=championStatsSummary();const active=rows.find(x=>x.key===st.champion)||rows[0];const activeKey=championChallenger(markets[0]||{},markets[0]?.analysis||{}).active||st.champion;const metrics=rows.map(x=>`<article><span>${x.label}</span><strong>${x.winRate.toFixed(1)}%</strong><small>${x.trials} trials · avg ${x.avg>=0?'+':''}${x.avg.toFixed(2)}% · posterior ${x.posterior.toFixed(1)}</small></article>`).join('');box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">MODEL LEAGUE</p><h2>Champion / Challenger Engine</h2><p class="muted">النموذج الحالي: <strong>${MODEL_PROFILES[st.champion]?.label||st.champion}</strong>. الترقية لا تتم إلا بعد أدلة Shadow محلولة وخارجية زمنيًا.</p></div><span class="tag">Champion: ${active?MODEL_PROFILES[active.key].label:'Balanced'}</span></div><div class="performance-results">${metrics}</div><p class="muted">كل نموذج يقيّم الفرصة باستقلالية. لا يستطيع Challenger تجاوز بوابات الجودة أو المخاطر؛ دوره اكتشاف ما إذا كان وزن الاستراتيجية الحالي يفقد ميزته.</p>`;}


// v7.29: Per-asset historical strategy learning lab.
const ASSET_LEARNING_KEY='lsai-asset-learning-v2';
const STRATEGY_CATALOG={
  BALANCED:{label:'Balanced Adaptive',description:'الاستراتيجية الموحدة الحالية مع ML وMTF.',overrides:{}},
  TREND:{label:'Trend Following',description:'اتجاه + EMA + ADX/DMI + UT Bot.',overrides:{utbotEnabled:true,emaEnabled:true,adxEnabled:true,rsiEnabled:false,macdEnabled:false,fractalsEnabled:false,volumeEnabled:false,bollingerEnabled:false,ichimokuEnabled:true}},
  PULLBACK:{label:'Pullback Momentum',description:'EMA + RSI + MACD + حجم مع تأكيد الاتجاه.',overrides:{utbotEnabled:false,emaEnabled:true,adxEnabled:true,rsiEnabled:true,macdEnabled:true,fractalsEnabled:false,volumeEnabled:true,bollingerEnabled:false,ichimokuEnabled:false}},
  BREAKOUT:{label:'Volatility Breakout',description:'Bollinger + EMA + Volume + ATR.',overrides:{utbotEnabled:true,emaEnabled:true,adxEnabled:true,rsiEnabled:false,macdEnabled:false,fractalsEnabled:false,volumeEnabled:true,bollingerEnabled:true,ichimokuEnabled:false}},
  STRUCTURE:{label:'Fractal Structure',description:'Williams Fractals + EMA + ADX + ATR.',overrides:{utbotEnabled:false,emaEnabled:true,adxEnabled:true,rsiEnabled:false,macdEnabled:false,fractalsEnabled:true,volumeEnabled:true,bollingerEnabled:false,ichimokuEnabled:true}},
  DEFENSIVE:{label:'Defensive Mean-Reversion',description:'RSI + Bollinger + ATR مع فلتر الاتجاه.',overrides:{utbotEnabled:false,emaEnabled:true,adxEnabled:true,rsiEnabled:true,macdEnabled:false,fractalsEnabled:false,volumeEnabled:false,bollingerEnabled:true,ichimokuEnabled:false}}
};
// v7.32: bounded per-strategy parameter search. Parameters are deliberately small,
// interpretable and validated OOS; they never bypass the core qualification gates.
const STRATEGY_PARAMETER_CATALOG={
  BALANCED:[{name:'Balanced Base',patch:{}},{name:'Balanced Fast',patch:{ema:{period:15},rsi:{period:12},adx:{period:14,min:20},atr:{period:14,stopMultiplier:2}}},{name:'Balanced Smooth',patch:{ema:{period:30},rsi:{period:14},adx:{period:18,min:18},atr:{period:14,stopMultiplier:2.2}}}],
  TREND:[{name:'Trend Base',patch:{}},{name:'Trend Fast',patch:{ema:{period:15},adx:{period:14,min:20},utbot:{atrPeriod:8,keyValue:1.1},atr:{stopMultiplier:2.2}}},{name:'Trend Slow',patch:{ema:{period:30},adx:{period:14,min:20},utbot:{atrPeriod:12,keyValue:1.3},atr:{stopMultiplier:2.6}}}],
  PULLBACK:[{name:'Pullback Base',patch:{}},{name:'Pullback Fast',patch:{ema:{period:15},rsi:{period:12,threshold:40},macd:{fast:10,slow:24,signal:8},volume:{multiplier:1.15}}},{name:'Pullback Selective',patch:{ema:{period:30},rsi:{period:14,threshold:35},macd:{fast:12,slow:26,signal:9},volume:{multiplier:1.3}}}],
  BREAKOUT:[{name:'Breakout Base',patch:{}},{name:'Breakout Tight',patch:{bollinger:{period:20,multiplier:1.8},adx:{period:14,min:20},volume:{multiplier:1.3},atr:{stopMultiplier:2.2}}},{name:'Breakout Wide',patch:{bollinger:{period:24,multiplier:2.2},adx:{period:14,min:18},volume:{multiplier:1.15},atr:{stopMultiplier:2.6}}}],
  STRUCTURE:[{name:'Structure Base',patch:{}},{name:'Structure Fast',patch:{ema:{period:15},fractals:{lookback:2},adx:{period:14,min:20},atr:{stopMultiplier:2.2}}},{name:'Structure Slow',patch:{ema:{period:30},fractals:{lookback:3},adx:{period:18,min:18},atr:{stopMultiplier:2.6}}}],
  DEFENSIVE:[{name:'Defensive Base',patch:{}},{name:'Defensive Tight',patch:{ema:{period:30},rsi:{period:14,threshold:35},bollinger:{period:20,multiplier:1.8},atr:{stopMultiplier:1.8}}},{name:'Defensive Wide',patch:{ema:{period:50},rsi:{period:14,threshold:40},bollinger:{period:24,multiplier:2.2},atr:{stopMultiplier:2.2}}}]
};
// v7.33: bounded execution/regime learning. These values are intentionally small and
// must survive the same OOS + holdout tests as indicator parameters.
const STRATEGY_EXECUTION_CATALOG={
  BALANCED:[{name:'Balanced Risk',patch:{tp:4.5,sl:2,atrStopMultiplier:2}},{name:'Balanced Protected',patch:{tp:4.2,sl:1.8,atrStopMultiplier:1.8}}],
  TREND:[{name:'Trend Runner',patch:{tp:5.5,sl:2.4,atrStopMultiplier:2.4}},{name:'Trend Protected',patch:{tp:4.8,sl:2,atrStopMultiplier:2}}],
  PULLBACK:[{name:'Pullback Base',patch:{tp:4.5,sl:2,atrStopMultiplier:2}},{name:'Pullback Protected',patch:{tp:4,sl:1.8,atrStopMultiplier:1.8}}],
  BREAKOUT:[{name:'Breakout Base',patch:{tp:5.5,sl:2.6,atrStopMultiplier:2.6}},{name:'Breakout Protected',patch:{tp:4.8,sl:2.2,atrStopMultiplier:2.2}}],
  STRUCTURE:[{name:'Structure Base',patch:{tp:4.8,sl:2.2,atrStopMultiplier:2.2}},{name:'Structure Protected',patch:{tp:4.3,sl:2,atrStopMultiplier:2}}],
  DEFENSIVE:[{name:'Defensive Base',patch:{tp:3.5,sl:1.6,atrStopMultiplier:1.6}},{name:'Defensive Wide',patch:{tp:4,sl:2,atrStopMultiplier:2}}]
};
function deepMergeObject(base,patch){const out=JSON.parse(JSON.stringify(base||{}));for(const [k,v] of Object.entries(patch||{})){if(v&&typeof v==='object'&&!Array.isArray(v)&&out[k]&&typeof out[k]==='object')out[k]=deepMergeObject(out[k],v);else out[k]=v;}return out}
function strategyIndicatorConfig(key,variantPatch={}){return deepMergeObject(strategyProfileOverrides(key),variantPatch)}
function assetLearningStore(){try{const x=JSON.parse(localStorage.getItem(ASSET_LEARNING_KEY)||'{}');return x&&typeof x==='object'?x:{}}catch{return {}}}
function saveAssetLearning(x){try{localStorage.setItem(ASSET_LEARNING_KEY,JSON.stringify(x))}catch{}}
function assetKey(pair,tf){return `${normalizePair(pair)}|${tf}`}
function strategySnapshot(){const i=settings.indicators||{};return {utbotEnabled:!!i.utbot?.enabled,emaEnabled:!!i.ema?.enabled,adxEnabled:!!i.adx?.enabled,rsiEnabled:!!i.rsi?.enabled,macdEnabled:!!i.macd?.enabled,fractalsEnabled:!!i.fractals?.enabled,volumeEnabled:!!i.volume?.enabled,bollingerEnabled:!!i.bollinger?.enabled,ichimokuEnabled:!!i.ichimoku?.enabled}}
function applyStrategyProfile(key){const prof=STRATEGY_CATALOG[key];if(!prof)return;const i=settings.indicators||{};for(const [name,cfg] of Object.entries(i)){const k=`${name}Enabled`;if(k in prof.overrides)cfg.enabled=!!prof.overrides[k];}}
function strategyProfileOverrides(key){const prof=STRATEGY_CATALOG[key];const i=settings.indicators||{};const out={};for(const [name,cfg] of Object.entries(i)){out[name]=JSON.parse(JSON.stringify(cfg));const k=`${name}Enabled`;if(k in (prof?.overrides||{}))out[name].enabled=!!prof.overrides[k];}return out}
const ADAPTIVE_TIMEFRAMES=['15m','30m','1h','2h','4h','6h','12h','1d','3d'];
const ADAPTIVE_TF_CACHE=new Map();
const ADAPTIVE_TF_TTL=5*60*1000;
function adaptiveTimeframeCandidates(ticker={}){
  const vol=Number(ticker?.quoteVolume||0), ch=Math.abs(Number(ticker?.change||0));
  if(vol>=100000000 && ch>=6)return ['15m','30m','1h','2h','4h','6h'];
  if(vol>=10000000)return ['30m','1h','2h','4h','6h','12h'];
  if(vol>=1000000)return ['1h','2h','4h','6h','12h','1d'];
  return ['2h','4h','6h','12h','1d','3d'];
}
function adaptiveTimeframeScore(a,tf,ticker={}){
  const adx=Number(a?.adx||0), mom=Math.abs(Number(a?.momentum||0)), trend=Number(a?.trend||50), base=Number(a?.score||0);
  const vol=Math.abs(Number(ticker?.change||0));
  const volatility=Number(a?.volatilityPct||0);
  const activity=volatility>0?clamp(100-Math.abs(volatility-55)*1.25,35,100):60;
  const trendQuality=clamp(45+adx*1.6+Math.abs(Number(a?.momentum||0))*2+(trend>60?10:0),0,100);
  const stability=(Number(a?.candles||0)>=100?100:Number(a?.candles||0)>=60?78:55);
  const speedPenalty={'15m':volatility>80?0:4,'30m':0,'1h':0,'2h':1,'4h':1.5,'6h':2,'12h':3,'1d':4,'3d':6}[tf]||0;
  const activeBonus=vol>=6&&['15m','30m','1h','2h'].includes(tf)?3:0;
  return clamp(base*.46+trendQuality*.22+activity*.17+stability*.10+activeBonus-speedPenalty,0,100);
}
function symbolToPair(symbol){const raw=String(symbol||'').toUpperCase();const known=universeSymbols.find(x=>String(x.symbol||'').toUpperCase()===raw);return known?`${known.baseAsset}/${known.quoteAsset}`:raw.replace(/([A-Z0-9]+)(USDT|USDC|FDUSD|DAI|TUSD|USDP|USDS|PYUSD|EURC|USDE)$/,'$1/$2');}
async function selectAdaptiveTimeframe(symbol,ticker={}){
  const key=`${symbol}|${Math.round((Number(ticker?.quoteVolume)||0)/1000000)}|${Math.round(Number(ticker?.change)||0)}`;
  const cached=ADAPTIVE_TF_CACHE.get(key);if(cached&&Date.now()-cached.at<ADAPTIVE_TF_TTL)return cached.value;
  const candidates=adaptiveTimeframeCandidates(ticker);const rows=[];let cursor=0;
  const worker=async()=>{while(cursor<candidates.length){const tf=candidates[cursor++];try{const c=await fetchCandleSeries(symbol,tf,140);if(c.length<60)continue;const a=analyzeTimeframe(c);rows.push({tf,score:adaptiveTimeframeScore(a,tf,ticker),analysis:a});}catch{}}};
  await Promise.all(Array.from({length:Math.min(3,candidates.length)},worker));
  const learnedStore=assetLearningStore();const learnedRows=rows.map(x=>{const st=learnedStore[assetKey(symbolToPair(symbol),x.tf)];const boost=st&&Number(st.confidence)>=70&&st.validation?.oosRobust?10:0;return {...x,learnedBoost:boost,learnedConfidence:Number(st?.confidence||0),learnedStrategy:st?.winner||null,score:x.score+boost};});
  learnedRows.sort((a,b)=>b.score-a.score);const best=learnedRows[0]||{tf:'4h',score:0,analysis:{score:0}};
  const value={timeframe:best.tf,score:Math.round(best.score),profile:best.analysis,learnedStrategy:best.learnedStrategy||null,learnedConfidence:best.learnedConfidence||0,ranked:learnedRows.map(x=>({timeframe:x.tf,score:Math.round(x.score),baseScore:Math.round(x.score-(x.learnedBoost||0)),learnedBoost:x.learnedBoost||0,learnedConfidence:x.learnedConfidence||0,learnedStrategy:x.learnedStrategy||null,analysis:x.analysis}))};
  ADAPTIVE_TF_CACHE.set(key,{at:Date.now(),value});if(ADAPTIVE_TF_CACHE.size>500){const first=ADAPTIVE_TF_CACHE.keys().next().value;ADAPTIVE_TF_CACHE.delete(first);}return value;
}
function adaptiveConfirmationTimeframes(tf){
  const chain=['15m','30m','1h','2h','4h','6h','12h','1d','3d'];const i=Math.max(0,chain.indexOf(tf));
  return [...new Set([chain[Math.max(0,i-2)],chain[Math.max(0,i-1)],chain[Math.min(chain.length-1,i+1)],chain[Math.min(chain.length-1,i+2)]])].filter(x=>x!==tf).slice(0,4);
}
async function historicalCandles(pair,tf,days=365){
  const symbol=pairParts(pair).symbol, end=Date.now(), start=end-days*86400000, out=[];let cursor=start,last='';
  const barMs=intervalMs(tf), chunkBars=Math.max(200,Math.min(900,Math.floor(1000))), step=Math.max(1,barMs*chunkBars); // maximize Binance page efficiency while staying below the 1000-candle limit.
  while(cursor<end){const chunkEnd=Math.min(end,cursor+step);let got=null;
    try{const r=await apiFetch(`/api/candles?symbol=${encodeURIComponent(symbol)}&interval=${encodeURIComponent(tf)}&startTime=${cursor}&endTime=${chunkEnd}&limit=1000`,{cache:'no-store',retryAttempts:2});const d=await r.json().catch(()=>({}));if(r.ok&&Array.isArray(d.candles))got=d.candles;else last=`Worker HTTP ${r.status}`;}catch(e){last=e.message||last}
    if(!got){for(const host of ['https://data-api.binance.vision','https://api.binance.com']){try{const u=`${host}/api/v3/klines?symbol=${encodeURIComponent(symbol)}&interval=${encodeURIComponent(tf)}&startTime=${cursor}&endTime=${chunkEnd}&limit=1000`;const r=await fetch(u,{cache:'no-store',headers:{accept:'application/json'}});const d=await r.json().catch(()=>null);if(r.ok&&Array.isArray(d)){got=d.map(x=>({openTime:x[0],open:Number(x[1]),high:Number(x[2]),low:Number(x[3]),close:Number(x[4]),volume:Number(x[5]),closeTime:x[6]}));break}last=`${host} HTTP ${r.status}`}catch(e){last=e.message||last}}}
    if(!got||!got.length)break;out.push(...got);const max=Math.max(...got.map(x=>Number(x.openTime||0)));if(max<=cursor)break;cursor=max+1;
    if(got.length<50&&cursor<end)break;
    await new Promise(r=>setTimeout(r,60));
  }
  const seen=new Map();for(const r of out)seen.set(Number(r.openTime),r);const rows=[...seen.values()].sort((a,b)=>a.openTime-b.openTime);if(rows.length<150)throw Error(`Historical data insufficient for ${pair}: ${rows.length} candles (${last||'no data'})`);return rows;
}
function strategyMetricsAggregate(folds){
  const valid=folds.filter(x=>Number.isFinite(x.net));if(!valid.length)return {net:-Infinity,winRate:0,maxDrawdown:100,profitFactor:0,expectancy:-Infinity,trades:0,folds:0,robust:false};
  const nets=valid.map(x=>x.net).sort((a,b)=>a-b), median=nets[Math.floor(nets.length/2)];
  const trades=valid.reduce((s,x)=>s+x.trades,0), wins=valid.reduce((s,x)=>s+x.wins,0);
  const pf=valid.reduce((s,x)=>s+(Number.isFinite(x.profitFactor)?x.profitFactor:0),0)/valid.length;
  const dd=Math.max(...valid.map(x=>x.maxDrawdown));
  const positive=valid.filter(x=>x.net>0).length;
  return {net:valid.reduce((s,x)=>s+x.net,0),medianNet:median,winRate:trades?wins/trades*100:0,maxDrawdown:dd,profitFactor:pf,expectancy:trades?valid.reduce((s,x)=>s+x.net,0)/trades:0,trades,folds:valid.length,positiveFolds:positive,robust:positive>=Math.ceil(valid.length*.67)&&median>=0&&dd<=20};
}
function evaluateStrategyOOS(rows,id,initialCash,indicatorConfig=null){
  const base=JSON.parse(JSON.stringify(settings));
  settings.indicators=indicatorConfig||strategyIndicatorConfig(id,{});
  try{
    const n=rows.length, cuts=[Math.floor(n*.52),Math.floor(n*.70),Math.floor(n*.86)], ends=[cuts[1],cuts[2],Math.floor(n*.98)], folds=[];
    for(let i=0;i<3;i++){
      const start=Math.max(80,cuts[i]-(i?40:80)),end=ends[i];
      const r=evaluateHistoricalStrategy(rows,initialCash,start,end);
      folds.push({fold:i+1,start,end,net:r.net,winRate:r.winRate,maxDrawdown:r.maxDrawdown,profitFactor:r.profitFactor,expectancy:r.expectancy,trades:r.trades.length,wins:r.wins});
    }
    return strategyMetricsAggregate(folds);
  }finally{settings=base;}
}

function chooseLearnedStrategy(results){
  const eligible=results.filter(x=>x.trades>=20&&Number.isFinite(x.oosNet)&&x.oosRobust&&x.holdoutNet>=0&&x.holdoutDD<=20);
  return (eligible.length?eligible:results.filter(x=>x.trades>=20&&Number.isFinite(x.oosNet)).length?results.filter(x=>x.trades>=20&&Number.isFinite(x.oosNet)):results.filter(x=>Number.isFinite(x.net))).sort((a,b)=>{
    const sa=(Number(a.oosMedianNet)||-1e9)*.50+(Number(a.holdoutNet)||-1e9)*.25+(Number(a.oosPF)||0)*20-(Number(a.oosDD)||100)*.8+(Number(a.oosWinRate)||0)*.15;
    const sb=(Number(b.oosMedianNet)||-1e9)*.50+(Number(b.holdoutNet)||-1e9)*.25+(Number(b.oosPF)||0)*20-(Number(b.oosDD)||100)*.8+(Number(b.oosWinRate)||0)*.15;return sb-sa;
  })[0]||null;
}
async function learnAssetStrategies(pair,tf=settings.timeframe||'4h',days=365){
  const key=assetKey(pair,tf), started=Date.now(), box=$('#assetLearningResults');
  if(box){box.hidden=false;box.innerHTML=`<article><span>Learning</span><strong>${pair} · ${tf}</strong><small>تحميل ${days}+ يوم ثم اختبار الاستراتيجيات وإعداداتها زمنيًا OOS…</small></article>`}
  const rows=await historicalCandles(pair,tf,Math.max(365,days)), base=JSON.parse(JSON.stringify(settings)), results=[];
  try{
    const n=rows.length, holdoutStart=Math.floor(n*.86), holdoutEnd=Math.floor(n*.98);
    for(const [id,prof] of Object.entries(STRATEGY_CATALOG)){
      const variants=STRATEGY_PARAMETER_CATALOG[id]||[{name:'Base',patch:{}}];
      const executions=STRATEGY_EXECUTION_CATALOG[id]||[{name:'Default Execution',patch:{tp:settings.tp,sl:settings.sl,atrStopMultiplier:settings.indicators?.atr?.stopMultiplier||2}}];
      for(const variant of variants){
        for(const execution of executions){
        let res=null,oos=null,hold=null;
        try{
          const cfg=strategyIndicatorConfig(id,variant.patch);
          settings.indicators=cfg;
          settings.tp=Number(execution.patch.tp||settings.tp);
          settings.sl=Number(execution.patch.sl||settings.sl);
          settings.indicators.atr.stopMultiplier=Number(execution.patch.atrStopMultiplier||settings.indicators.atr?.stopMultiplier||2);
          res=evaluateHistoricalStrategy(rows,settings.budget||1000,Math.floor(n*.10),n);
          oos=evaluateStrategyOOS(rows,id,settings.budget||1000,cfg);
          hold=evaluateHistoricalStrategy(rows,settings.budget||1000,holdoutStart,holdoutEnd);
        }catch(e){res={trades:[],net:-Infinity,winRate:0,maxDrawdown:100,profitFactor:0,expectancy:-Infinity};oos={net:-Infinity,medianNet:-Infinity,winRate:0,maxDrawdown:100,profitFactor:0,expectancy:-Infinity,trades:0,robust:false};hold={net:-Infinity,maxDrawdown:100};}
        results.push({id,variant:variant.name,label:prof.label,description:prof.description,parameters:variant.patch,executionVariant:execution.name,execution:execution.patch,trades:res.trades?.length||0,net:Number(res.net||0),winRate:Number(res.winRate||0),maxDrawdown:Number(res.maxDrawdown||100),profitFactor:Number(res.profitFactor||0),expectancy:Number(res.expectancy||0),oosNet:Number(oos.net||0),oosMedianNet:Number(oos.medianNet||0),oosWinRate:Number(oos.winRate||0),oosDD:Number(oos.maxDrawdown||100),oosPF:Number(oos.profitFactor||0),oosTrades:Number(oos.trades||0),oosFolds:Number(oos.folds||0),oosPositiveFolds:Number(oos.positiveFolds||0),oosRobust:!!oos.robust,holdoutNet:Number(hold.net||0),holdoutDD:Number(hold.maxDrawdown||100)});
        }
      }
    }
  }finally{settings=base;persist()}
  const winner=chooseLearnedStrategy(results);
  const confidence=winner?clamp(40+(winner.oosRobust?25:0)+(winner.oosPositiveFolds>=2?10:0)+(winner.oosWinRate>=52?8:0)+(winner.holdoutNet>=0?7:0)-(winner.oosDD>15?15:0)+(winner.variant&&winner.variant!=='Balanced Base'?3:0),0,100):0;
  const store=assetLearningStore();store[key]={version:3,pair:normalizePair(pair),timeframe:tf,days,historyCoverageDays:Math.round((rows.at(-1).openTime-rows[0].openTime)/86400000),updatedAt:Date.now(),durationMs:Date.now()-started,winner:winner?.id||null,winnerVariant:winner?.variant||null,winnerParameters:winner?.parameters||{},winnerExecutionVariant:winner?.executionVariant||null,winnerExecution:winner?.execution||null,confidence,validation:{method:'3-fold temporal OOS + final holdout + bounded parameter search',oosRobust:!!winner?.oosRobust,holdoutPassed:!!winner&&winner.holdoutNet>=0&&winner.holdoutDD<=20},results};saveAssetLearning(store);renderAssetLearning(pair,tf,store[key]);return store[key];
}

function evaluateHistoricalStrategy(rows,initialCash,startIdx=0,endIdx=rows.length){
  const f=featureState(rows,0),closes=f.closes;let cash=initialCash,position=null,trades=[],peak=initialCash,maxDrawdown=0;const warm=Math.min(80,Math.max(40,rows.length-1));
  const begin=Math.max(warm,Number(startIdx)||0),finish=Math.min(rows.length,Number(endIdx)||rows.length);
  for(let idx=begin;idx<finish;idx++){const z=signalAt(rows,idx,f),price=closes[idx];if(!position&&z.buy){const amount=Math.min(cash,Math.max(10,settings.dealAmount||100));position={entry:price*(1+(settings.slippage||0)/100),amount,peak:price};cash-=amount;}if(position){position.peak=Math.max(position.peak,price);const ret=(price/position.entry-1)*100,trail=Math.max(Number(settings.sl||2),z.atrPct*(settings.indicators?.atr?.stopMultiplier||2));let reason=null;if(ret>=Number(settings.tp||4.5))reason='tp';else if(ret<=-trail)reason='sl';else if(z.utSignal==='sell')reason='ut';else if(!z.trend&&z.contextScore<50)reason='regime';else if(z.regime==='STRONG_DOWNTREND')reason='downtrend';if(reason||idx===rows.length-1){const exit=price*(1-(settings.slippage||0)/100),pnl=position.amount*(exit/position.entry-1);cash+=position.amount+pnl;trades.push({pnl,ret:pnl/Math.max(1,position.amount)*100,reason});position=null;}}const equity=cash+(position?position.amount*(price/position.entry):0);peak=Math.max(peak,equity);maxDrawdown=Math.max(maxDrawdown,(peak-equity)/Math.max(peak,1)*100)}const wins=trades.filter(t=>t.pnl>0).length,grossWin=trades.filter(t=>t.pnl>0).reduce((s,t)=>s+t.pnl,0),grossLoss=Math.abs(trades.filter(t=>t.pnl<=0).reduce((s,t)=>s+t.pnl,0));return {trades,wins,net:cash-initialCash,winRate:trades.length?wins/trades.length*100:0,maxDrawdown,profitFactor:grossLoss?grossWin/grossLoss:(grossWin?Infinity:0),expectancy:trades.length?(cash-initialCash)/trades.length:0};
}
function renderAssetLearning(pair,tf,state){const box=$('#assetLearningResults');if(!box||!state)return;const sorted=[...(state.results||[])].sort((a,b)=>b.net-a.net);box.hidden=false;box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">PER-ASSET LEARNING</p><h2>${pair} · ${tf}</h2><p class="muted">تعلم من ${state.days} يومًا على الأقل. الفائز: <strong>${STRATEGY_CATALOG[state.winner]?.label||state.winner||'—'}</strong>${state.winnerVariant?` · ${state.winnerVariant}`:''} · ثقة ${Number(state.confidence||0).toFixed(0)}%</p></div><span class="tag">${state.days}D · ${state.results?.length||0} strategies</span></div><div class="performance-results">${sorted.map(x=>`<article><span>${x.label}${x.variant?` · ${x.variant}`:''}</span><strong>${x.net>=0?'+':''}${x.net.toFixed(2)}</strong><small>${x.trades} trades · WR ${x.winRate.toFixed(1)}% · DD ${x.maxDrawdown.toFixed(1)}% · PF ${Number.isFinite(x.profitFactor)?x.profitFactor.toFixed(2):'∞'} · OOS ${x.oosRobust?'ROBUST':'watch'} · Holdout ${x.holdoutNet>=0?'PASS':'FAIL'}</small></article>`).join('')}</div><p class="muted">الاختيار لا يعتمد على صافي الربح داخل العينة فقط: تتم مقارنة الاستراتيجيات عبر 3 اختبارات زمنية OOS ثم Holdout نهائي. لا يحصل الملف التاريخي إلا على وزن محدود، ولا يتحول إلى بوابة مستقلة للصفقة.</p>`}
const ASSET_ADAPTIVE_PROFILE_KEY='lsai-asset-adaptive-profile-v1';
function assetAdaptiveStore(){try{const x=JSON.parse(localStorage.getItem(ASSET_ADAPTIVE_PROFILE_KEY)||'{}');return x&&typeof x==='object'?x:{}}catch{return {}}}
function saveAssetAdaptiveStore(x){try{localStorage.setItem(ASSET_ADAPTIVE_PROFILE_KEY,JSON.stringify(x))}catch{}}
function adaptiveProfileFor(pair){return assetAdaptiveStore()[normalizePair(pair)]||null}
async function learnAssetAdaptiveProfile(pair,ticker={},days=365){
  const choice=await selectAdaptiveTimeframe(pairParts(pair).symbol,ticker);
  const ranked=(choice.ranked||[]).slice(0,3).map(x=>x.timeframe);
  if(!ranked.length)throw Error(`No adaptive timeframe candidate for ${pair}`);
  const profiles=[],store=assetLearningStore();
  for(const tf of ranked){
    const key=assetKey(pair,tf),old=store[key];
    if(old&&old.winner&&Number(old.days||0)>=365&&Number(old.historyCoverageDays||0)>=365&&old.validation?.oosRobust&&Date.now()-Number(old.updatedAt||0)<30*86400000){profiles.push({tf,state:old});continue;}
    try{const state=await learnAssetStrategies(pair,tf,Math.max(365,days));profiles.push({tf,state});}catch(e){addLog(`Adaptive learning skipped ${pair} · ${tf}: ${e.message||e}`)}
    await new Promise(r=>setTimeout(r,120));
  }
  const usable=profiles.filter(x=>x.state?.winner&&Number(x.state.historyCoverageDays||0)>=365&&Number(x.state.confidence||0)>=55);
  const rankedProfiles=usable.map(x=>{const r=(x.state.results||[]).find(y=>y.id===x.state.winner)||{};const quality=clamp(Number(x.state.confidence||0)*.55+(x.state.validation?.oosRobust?20:0)+(x.state.validation?.holdoutPassed?15:0)+clamp(Number(r.oosWinRate||0)-50,-10,10),0,100);const liveScore=Number((choice.ranked||[]).find(y=>y.timeframe===x.tf)?.score||50);return {...x,quality,combined:liveScore*.35+quality*.65};}).sort((a,b)=>b.combined-a.combined);
  const best=rankedProfiles[0];if(!best)throw Error(`No 365-day validated profile available for ${pair}`);
  const out={version:1,pair:normalizePair(pair),selectedTimeframe:best.tf,selectedStrategy:best.state.winner,selectedVariant:best.state.winnerVariant||null,selectedParameters:best.state.winnerParameters||{},confidence:Math.round(best.state.confidence||0),updatedAt:Date.now(),historyCoverageDays:best.state.historyCoverageDays||0,candidates:rankedProfiles.map(x=>({timeframe:x.tf,strategy:x.state.winner,variant:x.state.winnerVariant||null,parameters:x.state.winnerParameters||{},confidence:x.state.confidence,quality:Math.round(x.quality),combined:Math.round(x.combined),oosRobust:!!x.state.validation?.oosRobust,holdoutPassed:!!x.state.validation?.holdoutPassed}))};
  const all=assetAdaptiveStore();all[out.pair]=out;saveAssetAdaptiveStore(all);return out;
}
function learnedStrategyFor(pair,tf=settings.timeframe||'4h'){const s=assetLearningStore()[assetKey(pair,tf)];return s?.winner&&STRATEGY_CATALOG[s.winner]?s:null}
function autoSelectLearnedStrategy(pair,tf=settings.timeframe||'4h'){const s=learnedStrategyFor(pair,tf);if(!s)return null;return {strategy:s.winner,confidence:s.confidence,updatedAt:s.updatedAt,results:s.results}}

function dynamicPositionAmount(m,o){
  const stop=Math.max(0.4,Number(o?.stopPct||settings.sl||2));
  const riskCapital=Math.max(0,Number(settings.budget||0))*Math.max(0.1,Number(settings.risk||2))/100;
  const riskSized=riskCapital/(stop/100);
  const regimeCap=Number(o?.riskMultiplier||m?.regimeInfo?.riskMultiplier||1);
  const volatilityPenalty=clamp(1-(Math.max(0,Number(m?.volatilityPct||0)-4)/20),0.35,1);
  const portfolio=portfolioIntelligence(m).score/100;
  return Math.max(10,Math.min(Number(settings.dealAmount||100),riskSized*regimeCap*volatilityPenalty*clamp(portfolio,0.45,1)));
}
function dynamicPositionCapacity(qualifiedCount=0){
  const remainingExposure=Math.max(0,settings.budget*(settings.maxExposure/100)-currentExposure());
  const byCapital=Math.floor(remainingExposure/Math.max(10,settings.dealAmount));
  const configured=(settings.maxOpenPositions==null||String(settings.maxOpenPositions).toLowerCase()==='auto')?Infinity:Math.max(0,Number(settings.maxOpenPositions)||0);
  return Math.max(0,Math.min(configured,qualifiedCount,byCapital));
}
function autoCandidateLimit(universeCount){
  const n=Math.max(1,Number(universeCount)||0);
  // AUTO is adaptive, not a literal request to download candles for every symbol.
  // It scales with the live universe while staying inside a practical public-API budget.
  return Math.min(200,Math.max(60,Math.ceil(n*0.05)));
}
function autoOpportunityLimit(candidateCount,qualifiedCount){
  const n=Math.max(1,Number(candidateCount)||0);
  const adaptive=Math.min(100,Math.max(10,Math.ceil(n*0.20)));
  return Math.min(qualifiedCount,adaptive);
}
function currentQualifiedOpportunities(){
  const source=settings.autoSelection?(qualifiedOpportunities.length?qualifiedOpportunities:watchPairs()):watchPairs();
  return source.map(pair=>markets.find(m=>m.symbol===pairParts(pair).symbol)).filter(m=>m&&m.price>0).filter(m=>{const o=opportunityScore(m);const ai=aiConsensus(m,o);return engineQualified(m,o);});
}

// v7.20.3 Adaptive ML core: lightweight, dependency-free logistic model.
const ML_SCHEMA='ml-v1';
const FEEDBACK_KEY='lsai-ml-feedback-v1';
function feedbackModel(){try{const x=JSON.parse(localStorage.getItem(FEEDBACK_KEY)||'null');return x&&x.schema===ML_SCHEMA?x:null}catch{return null}}
function saveFeedbackModel(m){localStorage.setItem(FEEDBACK_KEY,JSON.stringify(m))}
function applyFeedbackProbability(base,features){const fm=feedbackModel();if(!fm||fm.samples<20||!features)return {probability:base,confidence:0,status:'NOT_READY'};let z=Number(fm.bias||0);for(let j=0;j<features.length;j++)z+=Number(fm.weights?.[j]||0)*features[j];const fp=mlSigmoid(z)*100;const w=clamp((fm.samples-20)/80,0.1,0.35);return {probability:Math.round((base*(1-w)+fp*w)*10)/10,confidence:Math.round(w*100),status:fm.status||'ACTIVE'};}
function updateFeedbackModel(){const ledger=shadowLedger().filter(x=>x.resolved&&Array.isArray(x.features)&&Number.isFinite(Number(x.realizedPct)));if(ledger.length<20)return {status:'NOT_READY',samples:ledger.length};let fm=feedbackModel()||{schema:ML_SCHEMA,weights:new Array(ML_FEATURE_NAMES.length).fill(0),bias:0,samples:0,updates:0};const recent=ledger.slice(-120), lr=.018;for(const r of recent){const y=Number(r.realizedPct)>0?1:0;let z=fm.bias;for(let j=0;j<r.features.length;j++)z+=Number(fm.weights[j]||0)*r.features[j];const d=mlSigmoid(z)-y;for(let j=0;j<r.features.length;j++)fm.weights[j]=clamp(Number(fm.weights[j]||0)-lr*d*r.features[j],-3,3);fm.bias=clamp(Number(fm.bias||0)-lr*d,-3,3);}fm.samples=ledger.length;fm.updates=Number(fm.updates||0)+1;fm.status=ledger.length>=50?'ACTIVE':'WARMING';fm.updatedAt=Date.now();saveFeedbackModel(fm);return fm;}
const ML_FEATURE_NAMES=['momentum','rsiBias','emaSlope','trendStrength','macdMomentum','volumeRatio','adx','adxDirection','bbPosition','bbWidth','atrPct','rangePosition','ichimokuScore'];
function mlNormalize(v,lo,hi){return clamp((Number(v)-lo)/(hi-lo||1),-3,3);}
function mlFeaturesFromMarket(m){return [
  mlNormalize(m.momentum||0,-12,12), mlNormalize(50-Number(m.rsi||50),-40,40), mlNormalize(m.emaSlope||0,-8,8), mlNormalize(m.trendStrength||0,0,12),
  mlNormalize(m.macdMomentum||0,-3,3), mlNormalize(m.volumeRatio||1,.25,4), mlNormalize(m.adx||0,0,50), Number(m.adxBull)?1:-1,
  mlNormalize(m.bbPosition||50,0,100), mlNormalize(m.bbWidth||0,0,20), mlNormalize(m.atrPct||0,0,10), mlNormalize(m.rangePosition||50,0,100), mlNormalize(m.ichimokuScore||50,0,100)
 ];}
function mlFeatureVector(rows,idx){
  const i=settings.indicators||{}, closes=rows.map(x=>Number(x.close)), c=rows[idx]; if(!c)return null;
  const e=ema(closes,i.ema?.period||20), rr=rsi(closes,i.rsi?.period||14), mac=i.macd?.enabled?macd(closes,i.macd.fast||12,i.macd.slow||26,i.macd.signal||9):null;
  const ad=adxDmi(rows,i.adx?.period||14), bb=bollingerBands(closes,i.bollinger?.period||20,i.bollinger?.multiplier||2), at=atrSeries(rows,i.atr?.period||14), ich=ichimoku(rows,i.ichimoku?.conversion||9,i.ichimoku?.base||26,i.ichimoku?.spanB||52,i.ichimoku?.displacement||26);
  const mom=idx>=12?((closes[idx]/closes[idx-12])-1)*100:0, volBase=rows.slice(Math.max(0,idx-20),idx).reduce((s,x)=>s+Number(x.volume||0),0)/Math.max(1,Math.min(20,idx));
  const macm=mac?.hist?.[idx]!=null?(mac.hist[idx]-(mac.hist[idx-1]||0)):0, range=rangePosition(rows.slice(0,idx+1).slice(-21),20);
  return [mlNormalize(mom,-12,12),mlNormalize(50-(rr[idx]??50),-40,40),mlNormalize(idx&&e[idx]!=null&&e[idx-1]!=null?(e[idx]-e[idx-1])/Math.max(1,closes[idx-1])*100:0,-8,8),mlNormalize(trendStrength(closes.slice(0,idx+1),20),0,12),mlNormalize(macm,-3,3),mlNormalize(volBase?(Number(c.volume||0)/volBase):1,.25,4),mlNormalize(ad?.adx?.[idx]||0,0,50),(ad?.pdi?.[idx]||0)>(ad?.mdi?.[idx]||0)?1:-1,mlNormalize(bb?.position?.[idx]??50,0,100),mlNormalize(bb?.width?.[idx]??0,0,20),mlNormalize(closes[idx]?((at[idx]||0)/closes[idx]*100):0,0,10),mlNormalize(range,0,100),mlNormalize(ich?.score??50,0,100)];
}
function mlSigmoid(z){return 1/(1+Math.exp(-clamp(z,-35,35)));}
function trainML(rows,start=0,endExclusive=rows.length-7){
  const horizon=6,targetMove=.012, X=[],Y=[], end=Math.min(endExclusive,rows.length-horizon);
  for(let i=Math.max(60,start);i<end;i++){const x=mlFeatureVector(rows,i),c=Number(rows[i].close),f=Number(rows[i+horizon].close);if(!x||!c||!f||!Number.isFinite(f/c))continue;X.push(x);Y.push(f>c*(1+targetMove)?1:0);}
  const empty={schema:ML_SCHEMA,weights:new Array(ML_FEATURE_NAMES.length).fill(0),bias:0,samples:X.length,accuracy:null,oosAccuracy:null,precision:null,recall:null,brier:null,baselineAccuracy:null,positiveRate:X.length?Y.reduce((a,b)=>a+b,0)/X.length:null,baseline:X.length?X[0].map((_,j)=>X.reduce((ss,r)=>ss+r[j],0)/X.length):[],trainedAt:Date.now(),weak:true,validationSamples:0};
  if(X.length<40)return empty;
  // Strict temporal split: the model only learns from the older segment. The newer
  // segment is untouched until evaluation, preventing the dashboard from reporting
  // an in-sample number as if it were predictive performance.
  const split=Math.max(25,Math.floor(X.length*.75));
  const Xt=X.slice(0,split),Yt=Y.slice(0,split),Xv=X.slice(split),Yv=Y.slice(split);
  if(Xv.length<10)return empty;
  let w=new Array(ML_FEATURE_NAMES.length).fill(0),b=0,lr=.08;
  for(let epoch=0;epoch<90;epoch++){const gw=new Array(w.length).fill(0);let gb=0;for(let n=0;n<Xt.length;n++){let z=b;for(let j=0;j<w.length;j++)z+=w[j]*Xt[n][j];const pp=mlSigmoid(z),d=pp-Yt[n];for(let j=0;j<w.length;j++)gw[j]+=d*Xt[n][j];gb+=d;}const rate=lr/(1+epoch*.025);for(let j=0;j<w.length;j++)w[j]-=rate*gw[j]/Xt.length;b-=rate*gb/Xt.length;}
  const probs=Xv.map(x=>{let z=b;for(let j=0;j<w.length;j++)z+=w[j]*x[j];return mlSigmoid(z);});
  let correct=0,tp=0,fp=0,fn=0,brier=0;for(let n=0;n<Xv.length;n++){const pred=probs[n]>=.5?1:0,y=Yv[n];correct+=pred===y?1:0;tp+=pred===1&&y===1?1:0;fp+=pred===1&&y===0?1:0;fn+=pred===0&&y===1?1:0;brier+=(probs[n]-y)**2;}
  const oosAccuracy=correct/Xv.length*100,precision=tp/(tp+fp||1)*100,recall=tp/(tp+fn||1)*100,baselineRate=Yv.reduce((a,v)=>a+v,0)/Yv.length,baselineAccuracy=Math.max(baselineRate,1-baselineRate)*100;
  const baseline=[];for(let j=0;j<X.length;j++){} for(let j=0;j<X[0].length;j++)baseline.push(Xt.reduce((ss,r)=>ss+r[j],0)/Xt.length);
  const weak=oosAccuracy<baselineAccuracy+3 || brier>.25 || !Number.isFinite(oosAccuracy);
  return {schema:ML_SCHEMA,weights:w,bias:b,samples:Xt.length,accuracy:oosAccuracy,oosAccuracy,precision,recall,brier:brier/Xv.length,baselineAccuracy,positiveRate:Yt.reduce((a,v)=>a+v,0)/Yt.length,baseline,trainedAt:Date.now(),weak,validationSamples:Xv.length,validationSplit:Math.round((Xv.length/X.length)*100)};
}
function predictML(rows,idx,model){const x=mlFeatureVector(rows,idx);if(!model||!x)return {probability:50,status:'INSUFFICIENT_DATA',features:x};let z=Number(model.bias||0);for(let j=0;j<x.length;j++)z+=Number(model.weights?.[j]||0)*x[j];const p=mlSigmoid(z)*100;const fb=applyFeedbackProbability(p,x);return {probability:fb.probability,status:model.weak?'WEAK_MODEL':(fb.status==='ACTIVE'?'ADAPTIVE':'READY'),features:x,feedbackWeight:fb.confidence};}
function modelDrift(rows,model){
  if(!model||!model.samples||model.samples<25)return {status:'INSUFFICIENT_DATA',score:100};
  const start=Math.max(60,rows.length-50), recent=[];for(let i=start;i<rows.length;i++){const x=mlFeatureVector(rows,i);if(x)recent.push(x);}if(recent.length<15)return {status:'INSUFFICIENT_DATA',score:100};
  let shift=0;for(let j=0;j<ML_FEATURE_NAMES.length;j++){const avg=recent.reduce((s,x)=>s+x[j],0)/recent.length;shift+=Math.abs(avg-(model.baseline?.[j]||0));}const score=clamp(shift/ML_FEATURE_NAMES.length*100,0,100);return {status:score>=55?'HIGH_VARIANCE':score>=35?'WATCH':'STABLE',score:Math.round(score)};
}
function applyValidatedAssetProfile(m){
  if(!m?.candles?.length)return m;
  const profile=adaptiveProfileFor(`${m.base}/${m.quote}`);
  if(!profile||Number(profile.historyCoverageDays||0)<365||!profile.selectedStrategy||!profile.validation?.oosRobust||!profile.validation?.holdoutPassed)return m;
  const cfg=strategyIndicatorConfig(profile.selectedStrategy,profile.selectedParameters||{}),c=m.candles,closes=c.map(x=>Number(x.close));
  const ind=cfg,ev=ind.ema?.enabled?ema(closes,ind.ema.period||20):[],rv=ind.rsi?.enabled?rsi(closes,ind.rsi.period||14):[];
  const ut=ind.utbot?.enabled?utBotSignals(c,ind.utbot.keyValue||1,ind.utbot.atrPeriod||10,ind.utbot.source||'close'):null;
  const fr=ind.fractals?.enabled?fractals(c,ind.fractals.lookback||2):null;
  const mac=ind.macd?.enabled?macd(closes,ind.macd.fast||12,ind.macd.slow||26,ind.macd.signal||9):null;
  const at=atrSeries(c,ind.atr?.period||14),adxv=ind.adx?.enabled?adxDmi(c,ind.adx.period||14):null,bb=ind.bollinger?.enabled?bollingerBands(closes,ind.bollinger.period||20,ind.bollinger.multiplier||2):null,ich=ind.ichimoku?.enabled?ichimokuState(c,ind.ichimoku):null;
  const last=c.at(-1),price=Number(last.close),avgVol=c.slice(-21,-1).reduce((a,x)=>a+Number(x.volume||0),0)/Math.max(1,Math.min(20,c.length-1));
  m.rsi=rv.at(-1)??50;m.trend=ev.at(-1)!=null?price>ev.at(-1):m.trend;m.fractal=!!fr?.down.slice(Math.max(0,fr.down.length-(ind.fractals.lookback||2)-3),-1).some(Boolean);m.ut=ut?.signals.at(-1)||'neutral';m.macd=mac?mac.hist.at(-1)>0:false;m.volume=!ind.volume?.enabled||last.volume>=avgVol*(ind.volume.multiplier||1.2);m.atr=!ind.atr?.enabled||((at.at(-1)||0)/price*100<=5);m.emaSlope=emaSlopePct(closes,ind.ema?.period||20,5);m.adx=adxv?.adx.at(-1)||0;m.adxBull=(adxv?.pdi.at(-1)||0)>(adxv?.mdi.at(-1)||0);m.bbPosition=bb?.position.at(-1)??50;m.bbWidth=bb?.width.at(-1)??0;m.atrPct=price?((at.at(-1)||0)/price*100):0;m.ichimokuScore=ich?.score??50;m.ichimokuBull=!!ich?.bull;m.ichimokuBear=!!ich?.bear;
  m.learnedProfileApplied=true;m.learnedStrategy=profile.selectedStrategy;m.learnedVariant=profile.selectedVariant||null;m.learnedParameters=profile.selectedParameters||{};m.learnedExecution=profile.selectedExecution||null;m.learnedProfileConfidence=Number(profile.confidence||0);return m;
}
function adaptiveExecutionForMarket(m){
  const p=adaptiveProfileFor(`${m?.base||''}/${m?.quote||''}`);const e=p?.selectedExecution;return p&&p.validation?.oosRobust&&p.validation?.holdoutPassed&&Number(p.historyCoverageDays||0)>=365&&e?{tp:Number(e.tp||settings.tp),sl:Number(e.sl||settings.sl),atrStopMultiplier:Number(e.atrStopMultiplier||settings.indicators?.atr?.stopMultiplier||2)}:{tp:Number(settings.tp),sl:Number(settings.sl),atrStopMultiplier:Number(settings.indicators?.atr?.stopMultiplier||2)};
}
function adaptiveMLForMarket(m){
  if(!m?.candles||m.candles.length<90)return {probability:50,status:'INSUFFICIENT_DATA',accuracy:null,drift:{status:'INSUFFICIENT_DATA',score:100}};
  const model=trainML(m.candles,0,m.candles.length-7), pred=predictML(m.candles,m.candles.length-1,model), drift=modelDrift(m.candles,model);
  return {probability:pred.probability,status:drift.status==='HIGH_VARIANCE'?'DRIFTED':(model.weak?'WEAK_MODEL':pred.status),accuracy:model.accuracy,oosAccuracy:model.oosAccuracy,precision:model.precision,recall:model.recall,brier:model.brier,baselineAccuracy:model.baselineAccuracy,samples:model.samples,validationSamples:model.validationSamples,drift,features:pred.features,feedbackWeight:pred.feedbackWeight||0};
}
function mlGateScore(m){const p=Number(m.mlProbability??50),status=String(m.mlStatus||'INSUFFICIENT_DATA');if(status==='DRIFTED'||status==='WEAK_MODEL'||status==='INSUFFICIENT_DATA')return 50;const oos=Number(m.mlOosAccuracy),base=Number(m.mlBaselineAccuracy);if(!Number.isFinite(oos)||!Number.isFinite(base)||oos<base+3||Number(m.mlBrier)>.25)return 50;return clamp(p,0,100);}

/* v7.39.0 AGI DECISION SUPERVISOR — parallel with the core engine.
   This is a bounded local reasoning layer, not a claim of scientific AGI.
   It can synthesize evidence and learn quickly, but never bypasses hard safety gates. */
const AGI_VERSION='lsai-agi-supervisor-v1';
const AGI_DEFAULT={enabled:true,learningRate:0.08,maxInfluence:0.12,minEvidence:8,conflictThreshold:18,strictSafety:true};
let agiState=(()=>{try{return {...AGI_DEFAULT,...JSON.parse(localStorage.getItem(AGI_VERSION)||'{}')}}catch{return {...AGI_DEFAULT}}})();
function agiLedger(){try{const x=JSON.parse(localStorage.getItem(`${AGI_VERSION}-ledger`)||'[]');return Array.isArray(x)?x:[]}catch{return []}}
function saveAgiLedger(x){try{localStorage.setItem(`${AGI_VERSION}-ledger`,JSON.stringify(x.slice(-500)))}catch{}}
function agiModel(){try{return {...{samples:0,wins:0,losses:0,avgReturn:0,weights:{trend:.21,momentum:.15,mtf:.14,risk:.14,rr:.09,regime:.07,ml:.06,tv:.05,ctrader:.05,validation:.04}},...JSON.parse(localStorage.getItem(`${AGI_VERSION}-model`)||'{}')}}catch{return {samples:0,wins:0,losses:0,avgReturn:0,weights:{trend:.21,momentum:.15,mtf:.14,risk:.14,rr:.09,regime:.07,ml:.06,tv:.05,ctrader:.05,validation:.04}}}}
function saveAgiModel(x){try{localStorage.setItem(`${AGI_VERSION}-model`,JSON.stringify(x))}catch{}}
function agiExternalEvidence(symbol){
  const tv=latestExternalTV(symbol);
  const tvScore=tv?Number(externalTVScore({symbol})||tv.score||50):50;
  const ctRows=cTraderChallengers.filter(x=>normalizeExternalSymbol(x.symbol)===normalizeExternalSymbol(symbol));
  const ct=ctRows.length?Math.max(...ctRows.map(challengerScore)):50;
  return {tv:clamp(tvScore,0,100),ctrader:clamp(ct,0,100)};
}
function agiValidationEvidence(){
  try{
    const st=backgroundStamp();
    const keys=['backtest','walkForward','walkBackward','stress','monteCarlo','readiness','architecture'];
    const rows=keys.map(k=>st[k]?.status).filter(Boolean);
    if(!rows.length)return 50;
    const pass=rows.filter(x=>x==='PASSED').length;
    return clamp(50+pass/rows.length*50,0,100);
  }catch{return 50}
}
const EVIDENCE_INTEL_KEY='lsai-evidence-intelligence-v2';
const EVIDENCE_INTEL_DEFAULT={version:2,sources:{},markets:{},contexts:{},updatedAt:0};
function evidenceIntel(){try{return {...EVIDENCE_INTEL_DEFAULT,...JSON.parse(localStorage.getItem(EVIDENCE_INTEL_KEY)||'{}')}}catch{return {...EVIDENCE_INTEL_DEFAULT}}}
function saveEvidenceIntel(x){try{x.updatedAt=Date.now();localStorage.setItem(EVIDENCE_INTEL_KEY,JSON.stringify(x))}catch{}}
function evidenceSourceStats(source){const st=evidenceIntel(),x=st.sources?.[source]||{};return {seen:Number(x.seen||0),resolved:Number(x.resolved||0),wins:Number(x.wins||0),losses:Number(x.losses||0),accuracy:Number(x.accuracy??50)}}
function evidenceSourceReliability(source){const x=evidenceSourceStats(source);if(x.resolved<8)return 1;const acc=clamp(x.accuracy,0,100);return clamp(.75+(acc/100)*.5,.75,1.25)}
function evidenceDirection(row){const a=String(row?.action||row?.signal||row?.direction||'').toLowerCase();if(['buy','long','bull','bullish'].includes(a))return 1;if(['sell','short','bear','bearish'].includes(a))return -1;return 0}
function evidenceConflictForMarket(m,o){
  const core=Number(o?.trendStrength||0)>=2||Number(o?.momentum||0)>=2?1:(Number(o?.trendStrength||0)<=-2||Number(o?.momentum||0)<=-2?-1:0);
  const tv=latestExternalTV(m?.symbol), td=evidenceDirection(tv); let conflict=0, agreements=0;
  if(core&&td){if(core===td)agreements++;else conflict+=45;}
  const ct=cTraderChallengers.filter(x=>normalizeExternalSymbol(x.symbol)===normalizeExternalSymbol(m?.symbol)).sort((a,b)=>challengerScore(b)-challengerScore(a))[0];
  const cd=evidenceDirection(ct); if(core&&cd){if(core===cd)agreements++;else conflict+=35;}
  return {score:clamp(conflict,0,100),agreements,coreDirection:core,tvDirection:td,ctraderDirection:cd};
}
function evidenceContextKey(symbol,timeframe,strategy){
  const sym=normalizeExternalSymbol(symbol||'UNKNOWN')||'UNKNOWN';
  const tf=String(timeframe||'AUTO').toLowerCase();
  const st=String(strategy||'ALL').trim().toUpperCase().replace(/[^A-Z0-9_-]/g,'_').slice(0,40)||'ALL';
  return `${sym}|${tf}|${st}`;
}
function recordEvidenceOutcome(source,win,context={}){
  const st=evidenceIntel();
  const x=st.sources[source]||{};x.seen=Number(x.seen||0)+1;x.resolved=Number(x.resolved||0)+1;x.wins=Number(x.wins||0)+(win?1:0);x.losses=Number(x.losses||0)+(win?0:1);x.accuracy=x.resolved?x.wins/x.resolved*100:50;st.sources[source]=x;
  const key=evidenceContextKey(context.symbol,context.timeframe,context.strategy), c=st.contexts[key]||{source,symbol:normalizeExternalSymbol(context.symbol||'UNKNOWN'),timeframe:String(context.timeframe||'AUTO'),strategy:String(context.strategy||'ALL'),seen:0,resolved:0,wins:0,losses:0,accuracy:50};
  c.seen++;c.resolved++;c.wins+=win?1:0;c.losses+=win?0:1;c.accuracy=c.resolved?c.wins/c.resolved*100:50;c.updatedAt=Date.now();st.contexts[key]=c;
  saveEvidenceIntel(st);
}
function evidenceContextReliability(source,context={}){
  const st=evidenceIntel(), exact=st.contexts?.[evidenceContextKey(context.symbol,context.timeframe,context.strategy)];
  if(!exact||exact.resolved<5)return evidenceSourceReliability(source);
  const acc=clamp(Number(exact.accuracy??50),0,100);return clamp(.78+(acc/100)*.44,.78,1.22);
}
function evidenceContextStatsForMarket(m){
  const st=evidenceIntel(), sym=normalizeExternalSymbol(m?.symbol||'');
  return Object.values(st.contexts||{}).filter(x=>x.symbol===sym).sort((a,b)=>Number(b.resolved||0)-Number(a.resolved||0)).slice(0,8).map(x=>({...x,reliability:evidenceContextReliability(x.source,x)}));
}
function adaptiveWeightStore(){
  const key='lsai-adaptive-source-weighting-v1';
  const base={version:1,learningRate:.08,minWeight:.55,maxWeight:1.45,minEvidence:5,sources:{core:1,tradingview:1,ctrader:1,validation:1,ml:1},contexts:{},updatedAt:0};
  try{return {...base,...JSON.parse(localStorage.getItem(key)||'{}')}}catch{return {...base}}
}
function saveAdaptiveWeightStore(x){try{x.updatedAt=Date.now();localStorage.setItem('lsai-adaptive-source-weighting-v1',JSON.stringify(x))}catch{}}
function adaptiveWeightSourceName(source){const s=String(source||'').toLowerCase();if(s.includes('tradingview'))return 'tradingview';if(s.includes('ctrader'))return 'ctrader';if(s.includes('validation'))return 'validation';if(s.includes('ml'))return 'ml';if(s==='paper'||s==='shadow'||s.includes('core'))return 'core';return null}
function adaptiveWeightContextKey(entry={}){
  const symbol=normalizeExternalSymbol(entry.symbol||entry.ticker||entry.pair)||'UNKNOWN';
  const tf=String(entry.timeframe||'AUTO').toLowerCase();
  const strategy=String(entry.strategy||entry.assetStrategy||'ALL').trim().toUpperCase().replace(/[^A-Z0-9_-]/g,'_').slice(0,40)||'ALL';
  const regime=String(entry.regime||entry.entryRegime||entry.marketRegime||'ALL').trim().toUpperCase().replace(/[^A-Z0-9_-]/g,'_').slice(0,30)||'ALL';
  return `${symbol}|${tf}|${strategy}|${regime}`;
}
function adaptiveWeightCandidates(entry={}){
  const exact=adaptiveWeightContextKey(entry), parts=exact.split('|');
  const [sym,tf,strat,regime]=parts;
  return [exact,`${sym}|${tf}|${strat}|ALL`,`${sym}|${tf}|ALL|${regime}`,`${sym}|ALL|${strat}|ALL`,'GLOBAL'];
}
function adaptiveSourceWeight(source,context={}){
  const st=adaptiveWeightStore(), name=adaptiveWeightSourceName(source)||String(source||'').toLowerCase(), base=Number(st.sources?.[name]??1);
  for(const key of adaptiveWeightCandidates(context)){
    const c=st.contexts?.[key];
    if(c?.weights?.[name]&&Number(c.resolved||0)>=Number(st.minEvidence||5))return clamp(Number(c.weights[name]),Number(st.minWeight||.55),Number(st.maxWeight||1.45));
  }
  return clamp(base,Number(st.minWeight||.55),Number(st.maxWeight||1.45));
}
function adaptiveWeightSnapshotForMarket(m,o={}){
  const context={symbol:m?.symbol,timeframe:m?.timeframe,strategy:o?.assetStrategy||o?.strategy||'ALL',regime:m?.regime||m?.marketRegime||o?.regime||'ALL'};
  const st=adaptiveWeightStore(), names=['core','tradingview','ctrader','validation','ml'];
  return {contextKey:adaptiveWeightContextKey(context),regime:context.regime,weights:Object.fromEntries(names.map(n=>[n,adaptiveSourceWeight(n,context)])),store:st};
}
function updateAdaptiveSourceWeightsFromOutcome(entry){
  const st=adaptiveWeightStore(), name=adaptiveWeightSourceName(entry?.source); if(!name)return;
  const ret=Number(entry.realizedPct); if(!Number.isFinite(ret))return;
  const evidence=entry.evidence||{}, target=ret>0?1:0, lr=clamp(Number(st.learningRate||.08)*(entry.proxy?.true?.35:1),.01,.12);
  const keys=adaptiveWeightCandidates(entry), exact=keys[0];
  const ensure=k=>{if(!st.contexts[k])st.contexts[k]={weights:{...st.sources},resolved:0,wins:0,updatedAt:0};return st.contexts[k]};
  const c=ensure(exact); c.resolved=Number(c.resolved||0)+1;c.wins=Number(c.wins||0)+(target?1:0);c.updatedAt=Date.now();
  Object.keys(c.weights).forEach(k=>{
    if(k!==name && !Number.isFinite(Number(evidence[k])))return;
    if(!Number.isFinite(Number(evidence[k])))return;
    const prediction=clamp(Number(evidence[k])/100,0,1), quality=1-Math.abs(target-prediction), old=Number(c.weights[k]||1);
    c.weights[k]=clamp(old+lr*(quality-.5),Number(st.minWeight||.55),Number(st.maxWeight||1.45));
  });
  // Slow global adaptation from the same labeled observation; context-specific weights always take precedence.
  st.sources[name]=clamp(Number(st.sources[name]||1)+lr*((target-.5)*.35),Number(st.minWeight||.55),Number(st.maxWeight||1.45));
  saveAdaptiveWeightStore(st);
}
function adaptiveSourceWeightingSummary(){
  const st=adaptiveWeightStore(), contexts=Object.entries(st.contexts||{}).sort((a,b)=>Number(b[1]?.resolved||0)-Number(a[1]?.resolved||0)).slice(0,12);
  return {st,contexts,global:Object.entries(st.sources||{}).map(([source,weight])=>({source,weight:Number(weight||1)}))};
}
function renderAdaptiveSourceWeightingPanel(){
  const host=$('#bgAdaptiveWeightMount .background-mount'); if(!host)return;
  let box=$('#adaptiveSourceWeightingPanel'); if(!box){box=document.createElement('section');box.id='adaptiveSourceWeightingPanel';box.className='panel adaptive-weight-panel';host.appendChild(box);}
  const x=adaptiveSourceWeightingSummary(), top=x.contexts[0]?.[1], names={core:'LOODY’S Core',tradingview:'TradingView',ctrader:'cTrader',validation:'Validation',ml:'ML'};
  const global=x.global.map(r=>`<article><span>${escapeHTML(names[r.source]||r.source)}</span><strong>${r.weight.toFixed(2)}×</strong><small>global adaptive weight</small></article>`).join('');
  const rows=x.contexts.map(([k,c])=>{const best=Object.entries(c.weights||{}).sort((a,b)=>Number(b[1])-Number(a[1]))[0];return `<tr><td>${escapeHTML(k)}</td><td>${Number(c.resolved||0)}</td><td>${escapeHTML(names[best?.[0]]||best?.[0]||'—')}</td><td>${Number(best?.[1]||1).toFixed(2)}×</td><td>${((Number(c.wins||0)/Math.max(1,Number(c.resolved||0)))*100).toFixed(1)}%</td></tr>`}).join('');
  box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">ADAPTIVE SOURCE WEIGHTING</p><h2>أفضل مصدر لكل سياق</h2><p class="muted">الأوزان تتعلم تدريجيًا من Outcomes الصريحة حسب العملة + الإطار الزمني + الاستراتيجية + حالة السوق. الأوزان استشارية ولا تتجاوز بوابات السلامة.</p></div><span class="tag">AUTO · ${x.contexts.length} contexts</span></div><div class="performance-results">${global}</div><div class="validation-row"><strong>Learning policy</strong><span>Bounded 0.55×–1.45× · minimum 5 labeled outcomes per exact context · proxy cTrader evidence learns at reduced rate.</span></div><div class="table-wrap"><table><thead><tr><th>Context</th><th>Resolved</th><th>Best source</th><th>Weight</th><th>Win%</th></tr></thead><tbody>${rows||'<tr><td colspan="5">لا توجد Outcomes كافية بعد؛ الأوزان تبدأ محايدة 1.00×.</td></tr>'}</tbody></table></div>${top?`<p class="meta">آخر سياق متعلم: ${escapeHTML(x.contexts[0][0])}</p>`:''}`;
}
/* v7.47.0 CONTEXT FUSION ENGINE — chooses the strongest evidence combination per asset/context.
   Fusion is advisory/ranking intelligence only. Core safety gates remain authoritative. */

/* v7.52.0 — Fibonacci + Edge-style Structure + Context Policy Learning.
   These are generic market-structure concepts, not a copy of any proprietary indicator.
   They are advisory features; hard safety gates remain authoritative. */
const CONTEXT_POLICY_VERSION='lsai-context-policy-learning-v1';
const CONTEXT_POLICY_DEFAULT={enabled:true,learningRate:.055,minResolved:6,maxInfluence:.08,minWeight:.55,maxWeight:1.45,topK:3};
function contextPolicyStore(){try{return {...CONTEXT_POLICY_DEFAULT,...JSON.parse(localStorage.getItem(CONTEXT_POLICY_VERSION)||'{}')}}catch{return {...CONTEXT_POLICY_DEFAULT}}}
function saveContextPolicyStore(x){try{x.updatedAt=Date.now();localStorage.setItem(CONTEXT_POLICY_VERSION,JSON.stringify(x))}catch{}}
function contextPolicyKey(entry={}){return adaptiveWeightContextKey(entry)}
function contextPolicy(){return contextPolicyStore()}
function contextPolicySourceSet(entry={}){const src=entry.selectedSources||entry.contextFusionSources||[];const clean=[...new Set(src.map(adaptiveWeightSourceName).filter(Boolean))].sort();return clean.length?clean:['core']}
function contextPolicyComboKey(sources){return [...new Set(sources)].sort().join('+')||'core'}
function updateContextPolicyFromOutcome(entry){
  const ret=Number(entry?.realizedPct); if(!Number.isFinite(ret))return;
  const st=contextPolicyStore(), key=contextPolicyKey(entry), combo=contextPolicyComboKey(contextPolicySourceSet(entry));
  const ensure=k=>{if(!st.contexts)st.contexts={};if(!st.contexts[k])st.contexts[k]={resolved:0,wins:0,combos:{},updatedAt:0};return st.contexts[k]};
  const c=ensure(key), win=ret>0?1:0, lr=clamp(Number(st.learningRate||.055)*(entry.proxy?.true?.35:1),.01,.09);
  c.resolved=Number(c.resolved||0)+1;c.wins=Number(c.wins||0)+win;c.updatedAt=Date.now();
  const q=c.combos[combo]||{resolved:0,wins:0,avgReturn:0,weight:1};q.resolved=Number(q.resolved||0)+1;q.wins=Number(q.wins||0)+win;q.avgReturn=((Number(q.avgReturn||0)*(q.resolved-1))+ret)/q.resolved;
  const quality=win?clamp(ret/5,.55,1):clamp(1+ret/5,.25,.45);q.weight=clamp(Number(q.weight||1)+lr*(quality-.5),Number(st.minWeight||.55),Number(st.maxWeight||1.45));q.updatedAt=Date.now();c.combos[combo]=q;saveContextPolicyStore(st);
}
function contextPolicySelection(m,o,src){
  const st=contextPolicyStore(), key=contextPolicyKey({symbol:m?.symbol,timeframe:m?.timeframe,strategy:o?.assetStrategy||o?.strategy,regime:m?.regime||m?.marketRegime});
  const c=st.contexts?.[key], rows=Object.entries(c?.combos||{}).filter(([,v])=>Number(v?.resolved||0)>=Number(st.minResolved||6)).map(([combo,v])=>({combo,...v,winRate:Number(v.resolved)?Number(v.wins||0)/Number(v.resolved)*100:0})).sort((a,b)=>(b.weight||1)-(a.weight||1));
  const base=contextPolicyComboKey(adaptiveSourceSelection(m,o,src).selected), chosen=rows[0]?.combo||base;
  const selected=chosen.split('+').filter(Boolean); if(!selected.includes('core'))selected.unshift('core');
  return {key,learned:!!rows[0],combo:chosen,selected:selected.slice(0,Math.max(1,Number(st.topK||3))),rows,confidence:rows[0]?clamp((Number(rows[0].resolved||0)/20)*100,0,100):0};
}
function renderContextPolicyLearningPanel(){
  const host=$('#bgAdaptiveWeightMount .background-mount');if(!host)return;let box=$('#contextPolicyLearningPanel');if(!box){box=document.createElement('section');box.id='contextPolicyLearningPanel';box.className='panel context-policy-panel';host.appendChild(box)}
  const st=contextPolicyStore(), contexts=Object.entries(st.contexts||{}).sort((a,b)=>Number(b[1]?.resolved||0)-Number(a[1]?.resolved||0)).slice(0,12), names={core:'LOODY’S Core',tradingview:'TradingView',ctrader:'cTrader',validation:'Validation',ml:'ML'};
  const rows=contexts.map(([k,c])=>{const best=Object.entries(c.combos||{}).sort((a,b)=>Number(b[1]?.weight||1)-Number(a[1]?.weight||1))[0];return `<tr><td>${escapeHTML(k)}</td><td>${Number(c.resolved||0)}</td><td>${escapeHTML(best?.[0]||'core')}</td><td>${Number(best?.[1]?.weight||1).toFixed(2)}×</td><td>${best?.[1]?.resolved?((Number(best[1].wins||0)/Number(best[1].resolved))*100).toFixed(1):'—'}%</td></tr>`}).join('');
  box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">CONTEXT POLICY LEARNING</p><h2>سياسة المصادر حسب السياق</h2><p class="muted">يتعلم النظام أي مجموعة مصادر تعمل أفضل لكل عملة + TF + استراتيجية + Regime، ثم يختارها تدريجيًا. Core يبقى إلزاميًا ولا يمكن للتعلم تجاوز بوابات السلامة.</p></div><span class="tag">${st.enabled?'AUTO':'OFF'}</span></div><div class="validation-row"><strong>Policy</strong><span>Learning ${(Number(st.learningRate||.055)*100).toFixed(1)}% · minimum ${Number(st.minResolved||6)} resolved · bounded influence ±${Number(st.maxInfluence||.08)*100}%</span></div><div class="table-wrap"><table><thead><tr><th>Context</th><th>Resolved</th><th>Best source set</th><th>Weight</th><th>Win%</th></tr></thead><tbody>${rows||'<tr><td colspan="5">لا توجد نتائج كافية بعد لبناء سياسة سياقية.</td></tr>'}</tbody></table></div>`;
}


function renderStructureFibonacciPanel(){
  const host=$('#bgStructureMount .background-mount');if(!host)return;let box=$('#structureFibonacciPanel');if(!box){box=document.createElement('section');box.id='structureFibonacciPanel';box.className='panel structure-fibonacci-panel';host.appendChild(box)}
  const m=lastRankedOpportunities[0], fs=m?fibonacciStructureContext(m.candles||[],60):null;
  if(!m||!fs){box.innerHTML='<div class="panel-head"><div><p class="eyebrow">FIBONACCI + MARKET STRUCTURE</p><h2>Fibonacci &amp; Structure Lab</h2></div><span class="tag">WAITING</span></div><p class="muted">بعد أول Scan سيقيس المحرك مناطق Fibonacci وBOS/FVG/Order Block على الأصل والإطار المختار.</p>';return;}
  const pct=fs.fibLevel?`${(fs.fibLevel*100).toFixed(1)}%`:'—';
  box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">FIBONACCI + MARKET STRUCTURE</p><h2>تحليل بنيوي قابل للتعلم</h2><p class="muted">${escapeHTML(m.symbol)} · ${escapeHTML(m.timeframe||'AUTO')} · Fibonacci + Swing Structure + BOS/FVG/Order Block.</p></div><span class="tag">ADVISORY</span></div><div class="performance-results"><article><span>Fibonacci score</span><strong>${fs.fibScore}/100</strong><small>nearest ${pct} · position ${fs.fibPosition}%</small></article><article><span>Structure score</span><strong>${fs.structureScore}/100</strong><small>${fs.bos||'No BOS'} · direction ${fs.structureDirection>0?'BULLISH':fs.structureDirection<0?'BEARISH':'NEUTRAL'}</small></article><article><span>FVG</span><strong>${fs.fvg||'NONE'}</strong><small>latest structural gap</small></article><article><span>Order Block</span><strong>${fs.orderBlock?.type||'NONE'}</strong><small>contextual zone only</small></article><article><span>Combined</span><strong>${fs.combinedScore}/100</strong><small>small bounded ranking influence</small></article></div><div class="validation-row"><strong>Policy</strong><span>لا توجد إشارة دخول من Fibonacci أو Structure وحدهما. يتم إثبات الفعالية من Outcomes لكل سياق.</span></div>`;
}
function fibonacciStructureContext(candles,lookback=60){
  const c=(candles||[]).slice(-Math.max(20,Number(lookback)||60)); if(c.length<12)return {fibScore:50,fibPosition:50,fibLevel:null,structureScore:50,structureDirection:0,bos:null,choch:null,fvg:null,orderBlock:null,swingHigh:null,swingLow:null};
  const highs=c.map(x=>Number(x.high)), lows=c.map(x=>Number(x.low)), closes=c.map(x=>Number(x.close)), last=closes.at(-1), hi=Math.max(...highs), lo=Math.min(...lows), range=Math.max(hi-lo,Number.EPSILON);
  const pos=clamp((last-lo)/range*100,0,100), levels=[{r:.236,v:hi-range*.236},{r:.382,v:hi-range*.382},{r:.5,v:hi-range*.5},{r:.618,v:hi-range*.618},{r:.786,v:hi-range*.786}];
  let nearest=levels[0],dist=Infinity;for(const x of levels){const d=Math.abs(last-x.v)/range;if(d<dist){dist=d;nearest=x}}
  const fibProximity=clamp(1-dist/.055,0,1), fibZone=nearest.r===.382||nearest.r===.5||nearest.r===.618, fibScore=clamp(Math.round(50+fibProximity*35+(fibZone?10:0)+(pos>50?5:-5)),0,100);
  let swingHigh=-1,swingLow=-1;for(let i=2;i<c.length-2;i++){if(highs[i]>highs[i-1]&&highs[i]>highs[i-2]&&highs[i]>=highs[i+1]&&highs[i]>=highs[i+2])swingHigh=i;if(lows[i]<lows[i-1]&&lows[i]<lows[i-2]&&lows[i]<=lows[i+1]&&lows[i]<=lows[i+2])swingLow=i;}
  const sh=swingHigh>=0?highs[swingHigh]:hi, sl=swingLow>=0?lows[swingLow]:lo;
  const priorHigh=swingHigh>=0?sh:null, priorLow=swingLow>=0?sl:null, bos=priorHigh!=null&&last>priorHigh*1.001?'BULLISH':priorLow!=null&&last<priorLow*.999?'BEARISH':null;
  const mid=(sh+sl)/2, structureDirection=last>mid?1:last<mid?-1:0, structureScore=clamp(Math.round(50+(bos==='BULLISH'?22:bos==='BEARISH'?-22:0)+structureDirection*10),0,100);
  const n=c.length-1, bullishFvg=n>=2&&Number(c[n].low)>Number(c[n-2].high), bearishFvg=n>=2&&Number(c[n].high)<Number(c[n-2].low);
  let ob=null;if(bos==='BULLISH'){for(let i=n-1;i>=Math.max(0,n-8);i--)if(c[i].close<c[i].open){ob={type:'BULLISH',high:c[i].high,low:c[i].low,index:i};break}}else if(bos==='BEARISH'){for(let i=n-1;i>=Math.max(0,n-8);i--)if(c[i].close>c[i].open){ob={type:'BEARISH',high:c[i].high,low:c[i].low,index:i};break}}
  const structureConfluence=(bos?20:0)+(bullishFvg||bearishFvg?10:0)+(ob?10:0);const combined=clamp(Math.round((fibScore*.48+structureScore*.42)+structureConfluence*.5),0,100);
  return {fibScore,fibPosition:Math.round(pos),fibLevel:nearest.r,fibPrice:nearest.v,structureScore,structureDirection,bos,choch:null,fvg:bullishFvg?'BULLISH':bearishFvg?'BEARISH':null,orderBlock:ob,swingHigh:sh,swingLow:sl,combinedScore:combined};
}
function updateContextPolicyEntry(entry){try{updateContextPolicyFromOutcome(entry)}catch{}}

/* v7.52.0 — Strategy Policy Learning.
   Learns which validated strategy/variant/execution + Fibonacci/Structure context
   works best with the selected evidence set for each symbol/TF/strategy/regime.
   It is advisory/ranking only; Core safety gates remain authoritative. */
const STRATEGY_POLICY_VERSION='lsai-strategy-policy-learning-v1';
const STRATEGY_POLICY_DEFAULT={enabled:true,learningRate:.045,minResolved:8,maxInfluence:.07,minWeight:.70,maxWeight:1.30,topK:3};
function strategyPolicyStore(){try{return {...STRATEGY_POLICY_DEFAULT,...JSON.parse(localStorage.getItem(STRATEGY_POLICY_VERSION)||'{}')}}catch{return {...STRATEGY_POLICY_DEFAULT}}}
function saveStrategyPolicyStore(x){try{x.updatedAt=Date.now();localStorage.setItem(STRATEGY_POLICY_VERSION,JSON.stringify(x))}catch{}}
function strategyPolicyContextKey(entry={}){return `${normalizePair(entry.symbol||entry.pair||'UNKNOWN')}|${entry.timeframe||'AUTO'}|${entry.regime||entry.marketRegime||'UNKNOWN'}`}
function strategyPolicyFeatureBucket(entry={}){
  const f=Number(entry.fibonacciScore??50), st=Number(entry.structureScore??50), c=Number(entry.structureCombinedScore??entry.structureCombined??50);
  return `${f>=65?'FIB+':f<=40?'FIB-':'FIB0'}_${st>=65?'STR+':st<=40?'STR-':'STR0'}_${c>=68?'CONF+':c<=42?'CONF-':'CONF0'}`;
}
function strategyPolicySignature(entry={}){
  const strategy=entry.strategy||entry.assetStrategy||'BALANCED', variant=entry.variant||entry.assetStrategyVariant||'BASE', execution=entry.executionVariant||entry.assetExecutionVariant||'DEFAULT';
  const sources=contextPolicyComboKey(entry.selectedSources||entry.contextPolicySelected||entry.contextFusionSources||['core']);
  return `${strategy}::${variant}::${execution}::${strategyPolicyFeatureBucket(entry)}::${sources}`;
}
function updateStrategyPolicyFromOutcome(entry){
  const ret=Number(entry?.realizedPct); if(!Number.isFinite(ret))return;
  const strategy=entry.strategy||entry.assetStrategy; if(!strategy)return;
  const st=strategyPolicyStore(), key=strategyPolicyContextKey(entry), sig=strategyPolicySignature(entry);
  st.contexts=st.contexts||{}; const c=st.contexts[key]||{resolved:0,wins:0,candidates:{},updatedAt:0};
  c.resolved=Number(c.resolved||0)+1; if(ret>0)c.wins=Number(c.wins||0)+1;
  const q=c.candidates[sig]||{resolved:0,wins:0,avgReturn:0,weight:1,strategy,variant:entry.variant||entry.assetStrategyVariant||null,execution:entry.executionVariant||entry.assetExecutionVariant||null,featureBucket:strategyPolicyFeatureBucket(entry),sources:contextPolicyComboKey(entry.selectedSources||entry.contextPolicySelected||entry.contextFusionSources||['core'])};
  q.resolved=Number(q.resolved||0)+1; if(ret>0)q.wins=Number(q.wins||0)+1; q.avgReturn=((Number(q.avgReturn||0)*(q.resolved-1))+ret)/q.resolved;
  const lr=clamp(Number(st.learningRate||.045)*(entry.proxy?.true?.35:1),.008,.07), target=ret>0?1:0, normalized=clamp(.5+ret/10,.1,.9);
  q.weight=clamp(Number(q.weight||1)+lr*((target*.7+normalized*.3)-.5),Number(st.minWeight||.70),Number(st.maxWeight||1.30)); q.updatedAt=Date.now(); c.candidates[sig]=q;c.updatedAt=Date.now();st.contexts[key]=c;
  saveStrategyPolicyStore(st);
}
function strategyPolicyPrior(strategyRow={}){
  const oos=Number(strategyRow.oosWinRate||0), pf=Number(strategyRow.oosPF||0), dd=Number(strategyRow.oosDD||100), hold=Number(strategyRow.holdoutNet||0);
  return clamp(45+(strategyRow.oosRobust?22:0)+(strategyRow.oosPositiveFolds>=2?8:0)+clamp(oos-50,-10,10)+clamp((pf-1)*8,-8,12)+(hold>=0?7:-7)-(dd>15?10:0),0,100);
}
function strategyPolicySelection(m,o){
  const st=strategyPolicyStore(), key=strategyPolicyContextKey({symbol:m?.symbol,timeframe:m?.timeframe,strategy:o?.assetStrategy||'AUTO',regime:m?.regime||m?.marketRegime});
  const exact=st.contexts?.[key];
  const pair=`${m?.base||''}/${m?.quote||''}`, tf=m?.timeframe||settings.timeframe||'4h', learned=learnedStrategyFor(pair,tf), rows=learned?.results||[];
  const sourceSet=contextPolicyComboKey(o?.contextPolicySelected||o?.contextFusionSources||['core']), fb=strategyPolicyFeatureBucket({...m,...o});
  const candidates=(rows.length?rows:[{id:learned?.winner||'BALANCED',variant:learned?.winnerVariant||'Base',executionVariant:null,oosRobust:false,oosWinRate:50,oosPF:1,oosDD:20,holdoutNet:0}]).map(r=>{
    const prefix=`${r.id}::${r.variant||'BASE'}`, matching=Object.entries(exact?.candidates||{}).filter(([sig])=>sig.startsWith(prefix+'::') && sig.includes(`::${fb}::`));
    const evidence=matching.sort((a,b)=>Number(b[1]?.weight||1)-Number(a[1]?.weight||1))[0]?.[1];
    const prior=strategyPolicyPrior(r), live=evidence&&Number(evidence.resolved||0)>=Number(st.minResolved||8)?(Number(evidence.weight||1)*100):prior;
    const sourceBonus=sourceSet!=='core'&&evidence?.sources===sourceSet?3:0;
    return {...r,policyScore:clamp(live+sourceBonus,0,100),resolved:Number(evidence?.resolved||0),policyWeight:Number(evidence?.weight||1),policySignature:matching[0]?.[0]||null};
  }).sort((a,b)=>b.policyScore-a.policyScore);
  const best=candidates[0]; const confidence=best?.resolved?clamp(best.resolved/20*100,0,100):clamp((best?.oosRobust?55:35),0,100);
  const learnedEnough=!!best&&best.resolved>=Number(st.minResolved||8)&&confidence>=45;
  return {key,selectedStrategy:best?.id||learned?.winner||'BALANCED',selectedVariant:best?.variant||learned?.winnerVariant||null,selectedParameters:best?.parameters||learned?.winnerParameters||{},selectedExecution:best?.executionVariant||learned?.winnerExecutionVariant||null,selectedExecutionPatch:best?.execution||learned?.winnerExecution||null,selectedScore:best?.policyScore||50,confidence,learned:learnedEnough,featureBucket:fb,sourceSet,candidates:candidates.slice(0,Math.max(1,Number(st.topK||3)))};
}
function renderStrategyPolicyPanel(){
  const host=$('#bgLearningMount .background-mount');if(!host)return;let box=$('#strategyPolicyLearningPanel');if(!box){box=document.createElement('section');box.id='strategyPolicyLearningPanel';box.className='panel strategy-policy-panel';host.appendChild(box)}
  const st=strategyPolicyStore(), contexts=Object.entries(st.contexts||{}).sort((a,b)=>Number(b[1]?.resolved||0)-Number(a[1]?.resolved||0)).slice(0,12);
  const rows=contexts.map(([k,c])=>{const best=Object.entries(c.candidates||{}).sort((a,b)=>Number(b[1]?.weight||1)-Number(a[1]?.weight||1))[0];return `<tr><td>${escapeHTML(k)}</td><td>${c.resolved||0}</td><td>${escapeHTML(best?.[1]?.strategy||'—')}</td><td>${escapeHTML(best?.[1]?.variant||'—')}</td><td>${best?.[1]?.resolved?((Number(best[1].wins||0)/Number(best[1].resolved))*100).toFixed(1):'—'}%</td><td>${Number(best?.[1]?.weight||1).toFixed(2)}×</td></tr>`}).join('');
  box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">STRATEGY POLICY LEARNING</p><h2>سياسة الاستراتيجية التكيفية</h2><p class="muted">يتعلم النظام أفضل استراتيجية + إعدادات + تنفيذ مع Fibonacci/Structure ومجموعة الأدلة لكل سياق، ويستخدم النتائج التاريخية كـprior قبل ظهور Outcomes كافية.</p></div><span class="tag">${st.enabled?'AUTO':'OFF'}</span></div><div class="validation-row"><strong>Safety</strong><span>التأثير محدود ±${Number(st.maxInfluence||.07)*100}% · حد التعلم ${Number(st.minResolved||8)} نتائج · Core gates لا تتغير.</span></div><div class="table-wrap"><table><thead><tr><th>Context</th><th>Resolved</th><th>Strategy</th><th>Variant</th><th>Win%</th><th>Weight</th></tr></thead><tbody>${rows||'<tr><td colspan="6">لا توجد سياسة متعلمة كفاية بعد.</td></tr>'}</tbody></table></div>`;
}


/* v7.54.0 — Policy Validation Arena.
   Compares incumbent vs challenger policies using validated historical priors,
   OOS/holdout evidence and resolved Shadow/Paper outcomes. Promotion is gated,
   bounded and never bypasses Core safety rules. */
const POLICY_ARENA_VERSION='lsai-policy-validation-arena-v1';
const POLICY_ARENA_DEFAULT={enabled:true,minResolved:12,minOosScore:58,minHoldoutScore:55,minMargin:3,maxInfluence:.05,champion:'INCUMBENT'};
function policyArenaStore(){try{return {...POLICY_ARENA_DEFAULT,...JSON.parse(localStorage.getItem(POLICY_ARENA_VERSION)||'{}')}}catch{return {...POLICY_ARENA_DEFAULT}}}
function savePolicyArenaStore(x){try{x.updatedAt=Date.now();localStorage.setItem(POLICY_ARENA_VERSION,JSON.stringify(x))}catch{}}
function policyArenaResolvedForContext(key){
  const st=strategyPolicyStore(), c=st.contexts?.[key]; if(!c)return {resolved:0,wins:0,avgReturn:0};
  return {resolved:Number(c.resolved||0),wins:Number(c.wins||0),avgReturn:Object.values(c.candidates||{}).reduce((a,q)=>a+Number(q.avgReturn||0)*Number(q.resolved||0),0)/Math.max(1,Object.values(c.candidates||{}).reduce((a,q)=>a+Number(q.resolved||0),0))};
}
function policyArenaHistoricalScore(row={}){
  const prior=strategyPolicyPrior(row);
  const oos=Number(row.oosWinRate||0), pf=Number(row.oosPF||0), dd=Number(row.oosDD||100), hold=Number(row.holdoutNet||0);
  return clamp(prior+(oos>=52?4:0)+(pf>=1.15?4:0)+(hold>0?4:-4)-(dd>12?4:0),0,100);
}
function policyArenaCandidates(m){
  const pair=`${m?.base||''}/${m?.quote||''}`,tf=m?.timeframe||settings.timeframe||'4h', learned=learnedStrategyFor(pair,tf), rows=Array.isArray(learned?.results)?learned.results:[];
  const base=rows.length?rows:[{id:learned?.winner||'BALANCED',variant:learned?.winnerVariant||'Base',oosRobust:false,oosWinRate:50,oosPF:1,oosDD:20,holdoutNet:0}];
  const ranked=base.map(r=>({...r,historicalScore:policyArenaHistoricalScore(r)})).sort((a,b)=>b.historicalScore-a.historicalScore);
  return ranked.slice(0,4);
}
function policyArenaEvaluateMarket(m){
  const st=policyArenaStore(), key=strategyPolicyContextKey({symbol:m?.symbol,timeframe:m?.timeframe,regime:m?.regime}), outcome=policyArenaResolvedForContext(key), cand=policyArenaCandidates(m);
  const incumbent=cand[0]||{id:'BALANCED',variant:'BASE',historicalScore:50}, challenger=cand.find(x=>`${x.id}::${x.variant||'BASE'}`!==`${incumbent.id}::${incumbent.variant||'BASE'}`)||incumbent;
  const incumbentLive=Number(incumbent.historicalScore||50), challengerLive=Number(challenger.historicalScore||50);
  const liveAdj=outcome.resolved>=Number(st.minResolved||12)?clamp((outcome.avgReturn||0)*2,-8,8):0;
  const incumbentScore=clamp(incumbentLive+liveAdj,0,100), challengerScore=clamp(challengerLive+liveAdj,0,100), margin=challengerScore-incumbentScore;
  const eligible=outcome.resolved>=Number(st.minResolved||12)&&challengerScore>=Number(st.minOosScore||58)&&Number(challenger.holdoutNet||0)>=0&&margin>=Number(st.minMargin||3);
  return {key,resolved:outcome.resolved,incumbent:{strategy:incumbent.id,variant:incumbent.variant||null,score:incumbentScore},challenger:{strategy:challenger.id,variant:challenger.variant||null,score:challengerScore},margin,eligible};
}
function policyArenaRun(){
  const st=policyArenaStore(), contexts=Object.keys(strategyPolicyStore().contexts||{}), rows=[];
  contexts.slice(0,80).forEach(key=>{
    const [symbol,tf,regime]=key.split('|'); const [base,quote]=(symbol||'').split('/');
    if(!base||!quote)return; const m={symbol,base,quote,timeframe:tf,regime}; try{rows.push(policyArenaEvaluateMarket(m))}catch{}
  });
  const eligible=rows.filter(x=>x.eligible), promoted=eligible.length>0?eligible.reduce((a,b)=>b.margin>a.margin?b:a,null):null;
  st.lastRun={at:Date.now(),contexts:rows.length,eligible:eligible.length,promoted:promoted?{key:promoted.key,challenger:promoted.challenger,margin:promoted.margin}:null,rows:rows.slice(0,80)};
  if(promoted){st.champion='CHALLENGER';st.lastPromotion=promoted}else st.champion='INCUMBENT';
  savePolicyArenaStore(st); return st.lastRun;
}
function renderPolicyValidationArena(){
  const host=$('#bgArenaMount .background-mount'); if(!host)return; let box=$('#policyValidationArenaPanel');
  if(!box){box=document.createElement('section');box.id='policyValidationArenaPanel';box.className='panel policy-arena-panel';host.appendChild(box)}
  const st=policyArenaStore(), r=st.lastRun||{contexts:0,eligible:0}, rows=Array.isArray(r.rows)?r.rows.slice(0,10):[];
  box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">POLICY VALIDATION ARENA</p><h2>ساحة اختبار السياسات</h2><p class="muted">منافسة السياسة الحالية ضد Challenger باستخدام النتائج التاريخية وOOS وHoldout ونتائج Shadow/Paper. لا توجد ترقية تلقائية تتجاوز بوابات Core.</p></div><span class="tag">${escapeHTML(st.champion||'INCUMBENT')}</span></div><div class="validation-row"><strong>آخر اختبار</strong><span>${r.at?new Date(r.at).toLocaleString():'لم يُشغّل بعد'} · Contexts ${r.contexts||0} · مؤهلون للترقية ${r.eligible||0}</span></div><div class="table-wrap"><table><thead><tr><th>Context</th><th>Resolved</th><th>Incumbent</th><th>Challenger</th><th>Margin</th><th>Status</th></tr></thead><tbody>${rows.map(x=>`<tr><td>${escapeHTML(x.key)}</td><td>${x.resolved}</td><td>${escapeHTML(x.incumbent.strategy)} ${Number(x.incumbent.score).toFixed(1)}</td><td>${escapeHTML(x.challenger.strategy)} ${Number(x.challenger.score).toFixed(1)}</td><td>${Number(x.margin).toFixed(1)}</td><td>${x.eligible?'PROMOTE CANDIDATE':'HOLD'}</td></tr>`).join('')||'<tr><td colspan="6">لا توجد سياقات كافية بعد.</td></tr>'}</tbody></table></div>`;
}

const ADAPTIVE_SELECTION_VERSION='lsai-adaptive-source-selection-v1';
const ADAPTIVE_SELECTION_DEFAULT={enabled:true,topK:3,minReliability:.82,freshnessFloor:.55,conflictPenalty:.20};
function adaptiveSelectionState(){try{return {...ADAPTIVE_SELECTION_DEFAULT,...JSON.parse(localStorage.getItem(ADAPTIVE_SELECTION_VERSION)||'{}')}}catch{return {...ADAPTIVE_SELECTION_DEFAULT}}}
function adaptiveSourceFreshness(name,m){
  const now=Date.now(); let at=0;
  if(name==='tradingview'){at=Number(latestExternalTV(m?.symbol)?.at||0)}
  else if(name==='ctrader'){
    const row=cTraderChallengers.filter(x=>normalizeExternalSymbol(x.symbol)===normalizeExternalSymbol(m?.symbol)).sort((a,b)=>Number(b.at||0)-Number(a.at||0))[0]; at=Number(row?.at||0);
  } else if(name==='validation'){
    const st=backgroundStamp(); at=Math.max(...['backtest','walkForward','walkBackward','stress','monteCarlo','readiness','architecture'].map(k=>Number(st[k]?.at||0)),0);
  } else return 1;
  if(!at)return 0;
  const ageH=Math.max(0,(now-at)/3600000); return clamp(Math.exp(-ageH/24),0,1);
}
function adaptiveSourceSelection(m,o,src){
  const cfg=adaptiveSelectionState(), rows=Object.entries(src).filter(([name,v])=>name==='core'||v.available!==false).map(([name,v])=>{
    const freshness=adaptiveSourceFreshness(name,m);
    const strength=clamp(Math.abs(Number(v.score||50)-50)/50,0,1);
    const reliability=Number(v.reliability||1), weight=Number(v.adaptiveWeight||1);
    const utility=reliability*weight*(0.65+0.35*Math.max(Number(cfg.freshnessFloor||.55),freshness))*(0.55+0.45*strength);
    return {name,score:Number(v.score||50),direction:Number(v.direction||0),reliability,adaptiveWeight:weight,freshness:Math.round(freshness*100),strength:Math.round(strength*100),utility};
  }).sort((a,b)=>b.utility-a.utility);
  const eligible=rows.filter(x=>x.reliability>=Number(cfg.minReliability||.82));
  let selected=eligible.slice(0,Math.max(1,Number(cfg.topK||3))).map(x=>x.name);
  if(!selected.includes('core'))selected=['core',...selected].slice(0,Math.max(1,Number(cfg.topK||3)));
  const policySt=contextPolicyStore(), pkey=contextPolicyKey({symbol:m?.symbol,timeframe:m?.timeframe,strategy:o?.assetStrategy||o?.strategy,regime:m?.regime||m?.marketRegime}), pc=policySt.contexts?.[pkey];
  const bestCombo=Object.entries(pc?.combos||{}).filter(([,v])=>Number(v?.resolved||0)>=Number(policySt.minResolved||6)).sort((a,b)=>Number(b[1]?.weight||1)-Number(a[1]?.weight||1))[0];
  if(bestCombo){const learned=bestCombo[0].split('+').filter(Boolean);selected=[...new Set(['core',...learned])].filter(x=>rows.some(r=>r.name===x)).slice(0,Math.max(1,Number(cfg.topK||3)));}
  return {rows,selected,top:eligible[0]||rows[0]||null,enabled:!!cfg.enabled,policyApplied:!!bestCombo,policyCombo:bestCombo?.[0]||null};
}
function renderAdaptiveSourceSelectionPanel(){
  const host=$('#bgAdaptiveWeightMount .background-mount'); if(!host)return;
  let box=$('#adaptiveSourceSelectionPanel'); if(!box){box=document.createElement('section');box.id='adaptiveSourceSelectionPanel';box.className='panel adaptive-selection-panel';host.appendChild(box);}
  const m=lastRankedOpportunities[0], o=m?opportunityScore(m):null;
  if(!m||!o){box.innerHTML='<div class="panel-head"><div><p class="eyebrow">ADAPTIVE SOURCE SELECTION</p><h2>اختيار المصدر حسب السياق</h2></div><span class="tag">LEARNING</span></div><p class="muted">بعد أول Scan سيحدد المحرك أفضل الأدلة المتاحة لكل عملة وإطار زمني واستراتيجية وحالة سوق.</p>';return;}
  const src=fusionSourceEvidence(m,o), sel=adaptiveSourceSelection(m,o,src), names={core:'LOODY’S Core',tradingview:'TradingView',ctrader:'cTrader',validation:'Validation',ml:'ML'};
  const rows=sel.rows.map(x=>`<tr><td>${escapeHTML(names[x.name]||x.name)}</td><td>${x.score}</td><td>${x.reliability.toFixed(2)}</td><td>${x.adaptiveWeight.toFixed(2)}</td><td>${x.freshness}%</td><td>${x.strength}%</td><td>${sel.selected.includes(x.name)?'<strong>SELECTED</strong>':'—'}</td></tr>`).join('');
  box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">ADAPTIVE SOURCE SELECTION</p><h2>اختيار المصدر الأفضل تلقائيًا</h2><p class="muted">السياق: ${escapeHTML(m.symbol)} · ${escapeHTML(m.timeframe||'AUTO')} · ${escapeHTML(o.assetStrategy||o.strategy||'ALL')} · ${escapeHTML(m.regime||'UNKNOWN')}</p></div><span class="tag">${sel.enabled?'AUTO':'OFF'}</span></div><div class="performance-results"><article><span>Primary source</span><strong>${escapeHTML(names[sel.top?.name]||sel.top?.name||'—')}</strong><small>أعلى Utility حاليًا</small></article><article><span>Selected sources</span><strong>${sel.selected.length}</strong><small>${sel.selected.map(x=>names[x]||x).join(' · ')}</small></article><article><span>Context</span><strong>${escapeHTML(m.regime||'UNKNOWN')}</strong><small>عملة + TF + Strategy + Regime</small></article></div><div class="table-wrap"><table><thead><tr><th>Source</th><th>Score</th><th>Reliability</th><th>Adaptive W</th><th>Freshness</th><th>Signal strength</th><th>Policy</th></tr></thead><tbody>${rows}</tbody></table></div><p class="meta">الاختيار advisory فقط. لا يستطيع TradingView أو cTrader أو ML تجاوز بوابات Score/Data/Confidence/Risk/R:R/Uncertainty.</p>`;
}
const CONTEXT_FUSION_VERSION='lsai-context-fusion-v1';
const CONTEXT_FUSION_DEFAULT={enabled:true,minSourceReliability:.82,maxInfluence:.10,minAgreement:2,conflictPenalty:.16};
function contextFusionState(){try{return {...CONTEXT_FUSION_DEFAULT,...JSON.parse(localStorage.getItem(CONTEXT_FUSION_VERSION)||'{}')}}catch{return {...CONTEXT_FUSION_DEFAULT}}}
function fusionSourceEvidence(m,o){
  const sym=m?.symbol||o?.symbol, strategy=o?.assetStrategy||o?.strategy||'ALL', tf=m?.timeframe||'AUTO';
  const ext=agiExternalEvidence(sym); const tv=latestExternalTV(sym); const ct=cTraderChallengers.filter(x=>normalizeExternalSymbol(x.symbol)===normalizeExternalSymbol(sym)).sort((a,b)=>challengerScore(b)-challengerScore(a))[0];
  const vals={
    core:{score:clamp(Number(o?.score??50),0,100),direction:Number(o?.trendStrength||0)>=2||Number(o?.momentum||0)>=2?1:(Number(o?.trendStrength||0)<=-2||Number(o?.momentum||0)<=-2?-1:0),reliability:1,adaptiveWeight:adaptiveSourceWeight('core',{symbol:sym,timeframe:tf,strategy,regime:m?.regime||m?.marketRegime})},
    tradingview:{score:ext.tv,direction:evidenceDirection(tv),reliability:evidenceContextReliability('TradingView',{symbol:sym,timeframe:tf,strategy,regime:m?.regime||m?.marketRegime}),adaptiveWeight:adaptiveSourceWeight('tradingview',{symbol:sym,timeframe:tf,strategy,regime:m?.regime||m?.marketRegime}),available:!!tv},
    ctrader:{score:ext.ctrader,direction:evidenceDirection(ct),reliability:evidenceContextReliability('cTrader',{symbol:sym,timeframe:tf,strategy,regime:m?.regime||m?.marketRegime}),adaptiveWeight:adaptiveSourceWeight('ctrader',{symbol:sym,timeframe:tf,strategy,regime:m?.regime||m?.marketRegime}),available:!!ct},
    validation:{score:agiValidationEvidence(),direction:0,reliability:evidenceSourceReliability('Validation'),adaptiveWeight:adaptiveSourceWeight('validation',{symbol:sym,timeframe:tf,strategy,regime:m?.regime||m?.marketRegime}),available:true},
    ml:{score:clamp(Number(o?.mlProbability??50),0,100),direction:Number(o?.mlProbability??50)>=58?1:Number(o?.mlProbability??50)<=42?-1:0,reliability:evidenceSourceReliability('ML'),adaptiveWeight:adaptiveSourceWeight('ml',{symbol:sym,timeframe:tf,strategy,regime:m?.regime||m?.marketRegime}),available:true}
  };
  return vals;
}
function contextFusion(m,o){
  const cfg=contextFusionState(), src=fusionSourceEvidence(m,o), selection=adaptiveSourceSelection(m,o,src);
  const available=Object.entries(src).filter(([k,v])=>selection.selected.includes(k));
  const weighted=available.reduce((a,[k,v])=>{const r=Number(v.reliability||1)*Number(v.adaptiveWeight||1);return a+Number(v.score||50)*r},0)/Math.max(1,available.reduce((a,[k,v])=>a+Number(v.reliability||1)*Number(v.adaptiveWeight||1),0));
  const directional=available.filter(([k,v])=>v.direction!==0);
  const pos=directional.filter(([k,v])=>v.direction>0).reduce((a,[k,v])=>a+Number(v.reliability||1)*Number(v.adaptiveWeight||1),0), neg=directional.filter(([k,v])=>v.direction<0).reduce((a,[k,v])=>a+Number(v.reliability||1)*Number(v.adaptiveWeight||1),0);
  const agreement=Math.min(pos,neg)>0?Math.min(pos,neg)/(pos+neg)*100:100;
  const dominant=pos===neg?0:(pos>neg?1:-1); const conflict=pos&&neg?clamp(Math.round(100-agreement),0,100):0;
  const ranked=selection.rows.map(x=>({...x,weighted:Number(x.score||50)*Number(x.reliability||1)*Number(x.adaptiveWeight||1)})).sort((a,b)=>b.weighted-a.weighted);
  const strong=ranked.filter(x=>selection.selected.includes(x.name));
  const sourceCount=strong.length;
  const fusionScore=clamp(Math.round(weighted-conflict*Number(cfg.conflictPenalty||.16)),0,100);
  const confidence=clamp(Math.round(50+(fusionScore-50)*.72+(sourceCount>=Number(cfg.minAgreement||2)?8:0)-conflict*.12),0,100);
  return {score:fusionScore,confidence,agreement:Math.round(agreement),conflict,dominant,selected:selection.selected,sourceCount,sources:ranked,context:evidenceContextKey(m?.symbol,m?.timeframe,o?.assetStrategy||o?.strategy),enabled:!!cfg.enabled,primarySource:selection.top?.name||'core'};
}
function applyContextFusionToOpportunity(m,o){
  const f=contextFusion(m,o); if(!f.enabled)return f;
  const boost=f.sourceCount>=2&&f.conflict<35?clamp((f.score-50)*Number(contextFusionState().maxInfluence||.10),-2,5):0;
  return {...f,rankBoost:boost};
}

function evidenceIntelligenceSnapshot(){
  const names=['TradingView','cTrader','LOODY’S Core','Validation','ML'];
  return names.map(source=>{const x=evidenceSourceStats(source);return {source,...x,reliability:evidenceSourceReliability(source)}});
}
function updateEvidenceIntelligenceFromOutcome(entry){
  const source=String(entry?.source||'').toLowerCase();
  if(source.includes('tradingview'))recordEvidenceOutcome('TradingView',Number(entry.realizedPct)>0,entry);
  else if(source.includes('ctrader'))recordEvidenceOutcome('cTrader',Number(entry.realizedPct)>0,entry);
  else if(source==='paper'||source==='shadow'||source.includes('core'))recordEvidenceOutcome('LOODY’S Core',Number(entry.realizedPct)>0,entry);
  else if(source.includes('validation'))recordEvidenceOutcome('Validation',Number(entry.realizedPct)>0,entry);
  else if(source.includes('ml'))recordEvidenceOutcome('ML',Number(entry.realizedPct)>0,entry);
}
function agiEvidence(m,o){
  const trend=clamp((Number(o.trendStrength||0)+12)/24*100,0,100), mom=clamp((Number(o.momentum||0)+12)/24*100,0,100);
  const ext=agiExternalEvidence(m?.symbol||o?.symbol), conflict=evidenceConflictForMarket(m,o), fusion=contextFusion(m,o);
  const mem=agiKnowledgeContextScore(m,o); const vals={trend,momentum:mom,mtf:Number(o.mtfScore||50),risk:Number(o.riskScore||50),rr:clamp(Number(o.rewardRisk||1)/2*100,0,100),regime:Number(o.regimeFit||50),ml:Number(o.mlProbability||50),tv:ext.tv,ctrader:ext.ctrader,validation:agiValidationEvidence(),fusion:fusion.score,memory:mem.score,memorySamples:mem.samples,evidenceConflict:Math.max(conflict.score,fusion.conflict)};
  return vals;
}
/* v7.65 AGI RESEARCH — Hypothesis generation, falsification, and experiment routing */
const AGI_V2_VERSION='lsai-agi-supervisor-v2';
const AGI_V2_DEFAULT={enabled:true,minAgentAgreement:3,maxInfluence:0.12,learningRate:0.045,minResolved:12,confidenceCap:92,strictSafety:true};
function agiV2Store(){try{return {...AGI_V2_DEFAULT,...JSON.parse(localStorage.getItem(AGI_V2_VERSION)||'{}')}}catch{return {...AGI_V2_DEFAULT}}}
function agiV2Memory(){try{const x=JSON.parse(localStorage.getItem(AGI_V2_VERSION+'-memory')||'[]');return Array.isArray(x)?x:[]}catch{return []}}
function saveAgiV2Memory(x){try{localStorage.setItem(AGI_V2_VERSION+'-memory',JSON.stringify(x.slice(-400)))}catch{}}
function agiV2ContextKey(m,o){return [m?.symbol||`${m?.base||''}/${m?.quote||''}`,m?.timeframe||'AUTO',o?.assetStrategy||o?.strategy||'BALANCED',m?.regime||m?.marketRegime||'UNKNOWN'].join('|')}
function agiV2ContextStats(m,o){const key=agiV2ContextKey(m,o), rows=agiV2Memory().filter(x=>x.context===key&&Number.isFinite(Number(x.realizedPct)));if(!rows.length)return {samples:0,winRate:50,avgReturn:0,calibration:50};const wins=rows.filter(x=>Number(x.realizedPct)>0).length,avg=rows.reduce((a,x)=>a+Number(x.realizedPct||0),0)/rows.length;return {samples:rows.length,winRate:wins/rows.length*100,avgReturn:avg,calibration:clamp(100-Math.abs(wins/rows.length-.5)*100,0,100)}}
function agiV2Agents(m,o,baseDecision){
  const e=agiEvidence(m,o), regime=String(m?.regime||m?.marketRegime||'UNKNOWN');
  const context=agiV2ContextStats(m,o);
  const trend=clamp((Number(o.trendStrength||0)+12)/24*100,0,100), mom=clamp((Number(o.momentum||0)+12)/24*100,0,100);
  const agents=[
    {name:'TECHNICAL',score:clamp(e.trend*.38+e.momentum*.30+e.mtf*.20+e.fusion*.12,0,100),direction:(trend>=55?1:-1)+(mom>=55?1:-1)},
    {name:'REGIME',score:clamp(e.regime*.55+e.mtf*.25+e.fusion*.20,0,100),direction:['TREND_UP','EARLY_UP'].includes(regime)?1:['TREND_DOWN','PANIC'].includes(regime)?-1:0},
    {name:'RISK',score:clamp(e.risk*.58+e.rr*.30+(100-(e.evidenceConflict||0))*.12,0,100),direction:e.risk>=68&&e.rr>=72?1:0},
    {name:'EVIDENCE',score:clamp(e.fusion*.48+(100-(e.evidenceConflict||0))*.25+e.validation*.17+e.memory*.10,0,100),direction:e.fusion>=58?1:0},
    {name:'VALIDATION',score:clamp(e.validation*.62+e.ml*.18+e.mtf*.20,0,100),direction:e.validation>=60?1:0}
  ];
  if(context.samples>=Number(agiV2Store().minResolved||12)){
    agents.push({name:'CONTEXT_MEMORY',score:clamp(context.winRate*.60+context.calibration*.20+(context.avgReturn>0?20:0),0,100),direction:context.winRate>=55?1:context.winRate<=45?-1:0});
  }
  return agents;
}
function agiV2Counterfactual(m,o,agents){
  const positive=agents.filter(a=>a.direction>0).length, negative=agents.filter(a=>a.direction<0).length;
  const conflict=Math.min(100,Math.abs(positive-negative)*18 + (positive&&negative?22:0));
  const best=Math.max(...agents.map(a=>Number(a.score||0)),50), worst=Math.min(...agents.map(a=>Number(a.score||0)),50);
  const fragility=clamp((best-worst)*.7+conflict*.3,0,100);
  return {positive,negative,conflict,fragility,stable:fragility<34&&positive>=Number(agiV2Store().minAgentAgreement||3)};
}
function agiSupervisorV2(m,o,baseDecision){
  const cfg=agiV2Store();if(!cfg.enabled)return agiSupervisor(m,o,baseDecision);
  const e=agiEvidence(m,o), agents=agiV2Agents(m,o,baseDecision), cf=agiV2Counterfactual(m,o,agents), ctx=agiV2ContextStats(m,o);
  const weighted=agents.reduce((a,x)=>a+Number(x.score||50),0)/Math.max(1,agents.length);
  const coreConf=Number(baseDecision?.confidence||50), safety=Number(o.dataQuality||0)>=85&&coreConf>=75&&Number(o.riskScore||0)>=68&&Number(o.rewardRisk||0)>=1.45&&Number(o.uncertainty||100)<=42&&!o.abstain;
  const disagreement=Math.abs(weighted-coreConf), uncertainty=clamp(Math.round((100-weighted)*.45+cf.fragility*.40+disagreement*.35+(ctx.samples<Number(cfg.minResolved||12)?8:0)),0,100);
  let action='WAIT',reason='AGI agents have not reached sufficient consensus.';
  if(!safety&&cfg.strictSafety){action='NO_TRADE';reason='Safety gate failed; AGI cannot override the core engine.'}
  else if(cf.stable&&weighted>=78&&coreConf>=75&&cf.negative===0){action='CONFIRM';reason='Independent AGI agents converge with low counterfactual fragility.'}
  else if(weighted>=68&&cf.positive>=Number(cfg.minAgentAgreement||3)&&cf.negative<=1){action='SUPPORT';reason='Most AGI agents support the setup; core gates remain authoritative.'}
  else if(cf.conflict>=35||cf.negative>=2){action='CONFLICT';reason='Material disagreement between AGI agents; prefer abstention.'}
  const score=clamp(Math.round(weighted-cf.fragility*.18-(e.evidenceConflict||0)*.08),0,100);
  const confidence=clamp(Math.round(100-uncertainty),0,Number(cfg.confidenceCap||92));
  const boost=action==='CONFIRM'?Math.min(Number(cfg.maxInfluence||.12)*100,8):action==='SUPPORT'?4:0;
  return {enabled:true,score,confidence,action,reason,conflict:Math.max(cf.conflict,disagreement),uncertainty,evidence:e,finalBoost:boost,agents,counterfactual:cf,context:ctx,learning:`${ctx.samples} context samples`,version:AGI_V2_VERSION};
}
function agiV2RecordOutcome(entry){
  if(!entry||!Number.isFinite(Number(entry.realizedPct)))return;
  const context=entry.context||[entry.symbol||'UNKNOWN',entry.timeframe||'AUTO',entry.strategy||'BALANCED',entry.regime||'UNKNOWN'].join('|');
  const mem=agiV2Memory();mem.push({at:Date.now(),context,realizedPct:Number(entry.realizedPct),source:entry.source||'core',proxy:!!entry.proxy});saveAgiV2Memory(mem);
}
function agiSupervisor(m,o,baseDecision){
  if(!agiState.enabled)return {enabled:false,score:50,confidence:50,action:'PASS_THROUGH',reason:'AGI disabled',conflict:0,learning:'OFF'};
  const e=agiEvidence(m,o), model=agiModel(), w=model.weights||{};
  const rel={tv:evidenceContextReliability('TradingView',{symbol:m?.symbol,timeframe:m?.timeframe,strategy:o?.assetStrategy||o?.strategy}),ctrader:evidenceContextReliability('cTrader',{symbol:m?.symbol,timeframe:m?.timeframe,strategy:o?.assetStrategy||o?.strategy}),validation:evidenceSourceReliability('Validation')};
  const raw=Object.keys(e).reduce((a,k)=>{const mult=rel[k]||1;return a+Number(e[k]||50)*Number(w[k]||0)*mult},0);
  const conflictPenalty=Number(e.evidenceConflict||0)*.10;
  const directionSignals=[e.trend,e.momentum,e.mtf,e.regime,e.ml].filter(v=>v>=58).length;
  const riskPenalty=e.risk<55?10:0, rrPenalty=e.rr<55?8:0;
  const score=clamp(Math.round(raw-riskPenalty-rrPenalty-conflictPenalty),0,100);
  const conflict=Math.abs(score-Number(baseDecision?.confidence||50));
  const hardSafe=Number(o.dataQuality||0)>=85&&Number(o.decisionConfidence||baseDecision?.confidence||0)>=75&&Number(o.riskScore||0)>=68&&Number(o.rewardRisk||0)>=1.45&&Number(o.uncertainty||100)<=42&&!o.abstain;
  let action='WAIT',reason='Insufficient aligned evidence';
  if(!hardSafe&&agiState.strictSafety){action='NO_TRADE';reason='Hard safety gate failed; AGI cannot override it.'}
  else if(score>=78&&directionSignals>=3&&Number(baseDecision?.confidence||0)>=75){action='CONFIRM';reason='Independent evidence is aligned with the core decision.'}
  else if(score>=68&&directionSignals>=3){action='SUPPORT';reason='AGI supports the setup but keeps the core gates authoritative.'}
  else if(conflict>=Number(agiState.conflictThreshold||18)){action='CONFLICT';reason='AGI and core engine materially disagree; abstention preferred.'}
  const uncertainty=clamp(Math.round((100-score)*.55+Math.max(0,conflict-10)*.9+(directionSignals<3?10:0)),0,100);
  const finalBoost=action==='CONFIRM'?Math.min(Number(agiState.maxInfluence||.12)*100,8):action==='SUPPORT'?4:0;
  return {enabled:true,score,confidence:clamp(Math.round(100-uncertainty),0,100),action,reason,conflict,uncertainty,evidence:e,finalBoost,learning:`${model.samples||0} samples`};
}
function agiLearnFromExternalSources(){
  let learned=0;
  // TradingView is used as contextual evidence until an outcome is available; it is never treated as a labeled win/loss by itself.
  const tvRows=tradingViewEvidence.filter(x=>!x.agiLearned).slice(-100);
  for(const x of tvRows){
    if(Number.isFinite(Number(x.realizedPct))){agiRecordResolved({id:x.id,symbol:x.symbol,timeframe:x.timeframe,strategy:x.strategy||x.name,realizedPct:Number(x.realizedPct),evidence:{tv:Number(x.score||50)},source:'TradingView outcome'});x.agiLearned=true;learned++;}
  }
  // cTrader performance is supervised evidence: profitable strategy statistics increase evidence confidence, poor ones reduce it.
  const ctRows=cTraderChallengers.filter(x=>!x.agiLearned).slice(-100);
  for(const x of ctRows){
    const quality=challengerScore(x), ret=Number(x.expectancy||0);
    if(Number.isFinite(ret)&&x.trades>=20){
      const pseudoReturn=clamp((quality-50)/10,-5,5);
      agiRecordResolved({id:x.id,symbol:x.symbol,timeframe:x.timeframe,strategy:x.strategy,realizedPct:pseudoReturn,evidence:{ctrader:quality,validation:quality},source:'cTrader strategy evidence',proxy:true});x.agiLearned=true;learned++;
    }
  }
  persistExternalResearch();
  return learned;
}
function agiRecordResolved(entry){
  if(!entry||!Number.isFinite(Number(entry.realizedPct)))return;
  agiV2RecordOutcome(entry);
  const model=agiModel(), ret=Number(entry.realizedPct), win=ret>0; model.samples=(model.samples||0)+1; if(win)model.wins=(model.wins||0)+1;else model.losses=(model.losses||0)+1;
  model.avgReturn=((Number(model.avgReturn||0)*(model.samples-1))+ret)/model.samples;
  const lr=clamp(Number(agiState.learningRate||.08),.01,.2), e=entry.evidence||{};
  Object.keys(model.weights||{}).forEach(k=>{if(!Number.isFinite(Number(e[k])))return; const target=win?1:0, x=clamp(Number(e[k])/100,0,1), old=Number(model.weights[k]||0); model.weights[k]=clamp(old+lr*(target-x)*.05,-.2,.5)});
  const sum=Object.values(model.weights).reduce((a,v)=>a+Math.max(0,Number(v)||0),0)||1;Object.keys(model.weights).forEach(k=>model.weights[k]=Math.max(0,Number(model.weights[k]||0))/sum);
  saveAgiModel(model);
  updateAdaptiveSourceWeightsFromOutcome(entry);
  updateContextPolicyEntry(entry);
  try{updateStrategyPolicyFromOutcome(entry)}catch{}
  const ledger=agiLedger();ledger.push({...entry,resolvedAt:Date.now()});saveAgiLedger(ledger);updateEvidenceIntelligenceFromOutcome(entry);
}
function renderAGIPanel(){
  let box=$('#agiSupervisorPanel'); if(!box){const host=$('#bgDecisionMount .background-mount');if(!host)return;box=document.createElement('section');box.id='agiSupervisorPanel';box.className='panel agi-supervisor-panel';host.prepend(box);}
  const m=agiModel(), l=agiLedger(), wr=m.samples?m.wins/m.samples*100:0;
  box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">LOODY’S AGI DECISION SUPERVISOR</p><h2>AGI + Core Engine — Parallel Reasoning</h2><p class="muted">طبقة إشراف مستقلة تجمع الأدلة بسرعة وتتعلم من النتائج، مع منعها من تجاوز بوابات السلامة.</p></div><span class="tag">${agiState.enabled?'ACTIVE':'PAUSED'}</span></div><div class="performance-results"><article><span>Learning samples</span><strong>${m.samples||0}</strong><small>${wr.toFixed(1)}% historical win rate</small></article><article><span>Avg return</span><strong>${Number(m.avgReturn||0)>=0?'+':''}${Number(m.avgReturn||0).toFixed(2)}%</strong><small>resolved AGI observations</small></article><article><span>Learning rate</span><strong>${(Number(agiState.learningRate||.08)*100).toFixed(1)}%</strong><small>bounded online update</small></article><article><span>Evidence ledger</span><strong>${l.length}</strong><small>last 500 observations retained</small></article></div><div class="validation-row"><strong>Safety</strong><span>AGI cannot bypass Data ≥85 · Confidence ≥75 · Risk ≥68 · R:R ≥1.45 · Uncertainty ≤42 · Abstention.</span></div><p class="muted">AGI v2 يستخدم وكلاءً مستقلين (Technical / Regime / Risk / Evidence / Validation / Context Memory) مع اختبار مضاد للفرضية وذاكرة سياقية. يتعلم من النتائج الحقيقية ضمن حدود صارمة. AGI يتعلم من المحرك الأساسي وML وHistorical Learning وWalk-Forward وStress وMonte Carlo وShadow وPaper وChampion/Challenger، ويستقبل TradingView كدليل سياقي وcTrader كدليل أداء/استراتيجيات. لا يتم اعتبار إشارة TradingView وحدها نتيجة رابحة دون Outcome.</p>`;
}

const AGI_RESEARCH_VERSION='lsai-agi-research-v1';
const AGI_RESEARCH_DEFAULT={enabled:true,maxHypotheses:8,minConfidence:62,minDelta:4,cooldownHours:12,maxInfluence:0.03};
function agiResearchStore(){try{return {...AGI_RESEARCH_DEFAULT,...JSON.parse(localStorage.getItem(AGI_RESEARCH_VERSION)||'{}')}}catch{return {...AGI_RESEARCH_DEFAULT}}}
function agiResearchLedger(){try{const x=JSON.parse(localStorage.getItem(AGI_RESEARCH_VERSION+'-ledger')||'[]');return Array.isArray(x)?x:[]}catch{return []}}
function saveAgiResearchLedger(x){try{localStorage.setItem(AGI_RESEARCH_VERSION+'-ledger',JSON.stringify(x.slice(-200)))}catch{}}
function agiResearchContext(m,o){return [m?.symbol||'UNKNOWN',m?.timeframe||'AUTO',o?.assetStrategy||o?.strategy||'BALANCED',m?.regime||m?.marketRegime||'UNKNOWN'].join('|')}
function agiGenerateHypotheses(){
  const cfg=agiResearchStore(); if(!cfg.enabled||!Array.isArray(markets)||!markets.length)return {generated:0};
  const now=Date.now(), ledger=agiResearchLedger(), recent=new Set(ledger.filter(x=>now-Number(x.at||0)<Number(cfg.cooldownHours||12)*3600000).map(x=>x.context+'|'+x.type));
  const out=[];
  for(const m of markets.filter(x=>x?.candles?.length).slice(0,40)){
    let o; try{o=opportunityScore(m)}catch{continue}
    const ctx=agiResearchContext(m,o), regime=m.regime||m.marketRegime||'UNKNOWN';
    const candidates=[
      {type:'STRATEGY_SWAP',claim:`تبديل الاستراتيجية إلى ${o.assetStrategy||'TREND'} قد يحسن الجودة في هذا السياق`,delta:Number(o.strategyPolicyBoost||0)+Number(o.assetStrategyConfidence||0)*.05,confidence:Number(o.strategyPolicyConfidence||o.assetStrategyConfidence||50)},
      {type:'SOURCE_REBALANCE',claim:'إعادة وزن مصادر الأدلة قد تقلل أثر التعارض',delta:Number(o.contextFusionConfidence||50)-Number(o.contextFusionConflict||0)*.35,confidence:Number(o.contextFusionConfidence||50)},
      {type:'TIMEFRAME_REVIEW',claim:`الإطار ${m.timeframe||'AUTO'} قد لا يكون الأمثل لهذا الـRegime`,delta:Number(o.mtfScore||50)-Number(o.uncertainty||50)*.25,confidence:Number(o.mtfScore||50)},
      {type:'STRUCTURE_CONFIRMATION',claim:'تأكيد Structure/Fibonacci قد يحسن جودة الدخول',delta:Number(o.structureScore||50)+Number(o.fibonacciScore||50)-100,confidence:Math.max(Number(o.structureScore||50),Number(o.fibonacciScore||50))}
    ];
    for(const h of candidates){const key=ctx+'|'+h.type;if(recent.has(key)||h.confidence<Number(cfg.minConfidence||62)||h.delta<Number(cfg.minDelta||4))continue;out.push({id:`hyp-${now}-${Math.random().toString(36).slice(2,8)}`,at:now,context:ctx,symbol:m.symbol,timeframe:m.timeframe||'AUTO',strategy:o.assetStrategy||o.strategy||'BALANCED',regime,type:h.type,claim:h.claim,expectedDelta:Number(h.delta.toFixed(2)),confidence:Number(h.confidence.toFixed(1)),status:'PROPOSED',testRoute:'EXPERIMENT_LAB',safety:'NO_GATE_IMPACT'});}
  }
  const selected=out.sort((a,b)=>(b.expectedDelta*b.confidence)-(a.expectedDelta*a.confidence)).slice(0,Number(cfg.maxHypotheses||8));
  if(selected.length){saveAgiResearchLedger([...ledger,...selected]);addLog(`AGI Research: ${selected.length} bounded hypotheses generated for Experiment Lab.`);}
  return {generated:selected.length,hypotheses:selected};
}
function agiFalsifyHypothesis(h){if(!h)return {status:'REJECT'};const confidence=Number(h.confidence||0),delta=Number(h.expectedDelta||0);if(confidence<Number(agiResearchStore().minConfidence||62)||delta<Number(agiResearchStore().minDelta||4))return {status:'REJECT',reason:'Evidence below research threshold'};return {status:'TEST_REQUIRED',reason:'Hypothesis must be tested in SHADOW before any policy influence.'}}
function renderAGIResearchPanel(){const host=document.querySelector('#bgResearchMount .background-mount');if(!host)return;let box=document.querySelector('#agiResearchPanel');if(!box){box=document.createElement('section');box.id='agiResearchPanel';box.className='panel';host.appendChild(box)}const cfg=agiResearchStore(),rows=agiResearchLedger().slice().reverse().slice(0,15);box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">AGI AUTONOMOUS RESEARCH</p><h2>محرك الفرضيات والبحث الذاتي</h2><p class="muted">يولد AGI فرضيات قابلة للاختبار، ثم يرسلها إلى Experiment Lab. لا تستطيع الفرضية تعديل بوابات السلامة أو اعتماد نفسها.</p></div><span class="tag">${cfg.enabled?'ACTIVE':'PAUSED'}</span></div><div class="performance-results"><article><span>Hypotheses</span><strong>${rows.length}</strong><small>bounded research ledger</small></article><article><span>Min confidence</span><strong>${Number(cfg.minConfidence||62)}</strong><small>research threshold</small></article><article><span>Min expected delta</span><strong>${Number(cfg.minDelta||4).toFixed(1)}</strong><small>before SHADOW testing</small></article><article><span>Influence cap</span><strong>${Number(cfg.maxInfluence||.03).toFixed(2)}</strong><small>no direct gate impact</small></article></div><div class="table-wrap"><table><thead><tr><th>Context</th><th>Hypothesis</th><th>Expected Δ</th><th>Confidence</th><th>Status</th><th>Route</th></tr></thead><tbody>${rows.map(x=>`<tr><td>${escapeHTML(x.symbol)} · ${escapeHTML(x.timeframe)} · ${escapeHTML(x.regime)}</td><td>${escapeHTML(x.claim)}</td><td>+${Number(x.expectedDelta||0).toFixed(1)}</td><td>${Number(x.confidence||0).toFixed(1)}</td><td>${escapeHTML(x.status||'PROPOSED')}</td><td>Experiment Lab → Revalidation → Governance</td></tr>`).join('')||'<tr><td colspan="6">لا توجد فرضيات بعد. سيولد AGI فرضيات مع دورة الخلفية التالية.</td></tr>'}</tbody></table></div><p class="meta">كل فرضية تمر باختبار قابل للتفنيد في SHADOW. لا يوجد تأثير مباشر على التأهل أو التداول الحقيقي.</p>`}

function agiApplyToOpportunity(m,o,decision){const a=agiSupervisorV2(m,o,decision);if(!a.enabled)return a; o.agiScore=a.score;o.agiConfidence=a.confidence;o.agiAction=a.action;o.agiConflict=a.conflict;o.agiUncertainty=a.uncertainty;o.agiReason=a.reason;o.agiFinalBoost=a.finalBoost;o.agiAgents=a.agents||[];o.agiCounterfactual=a.counterfactual||null;o.agiContextSamples=a.context?.samples||0;return a;}

function opportunityScore(m){
  const s=signalDetail(m);
  const signalPct=s.total?s.score/s.total*100:0;
  const momentum=clamp(Number(m.momentum||0),-12,12);
  const volumeRatio=clamp(Number(m.volumeRatio||1),0.25,4);
  const trend=clamp(Number(m.trendStrength||0),0,12);
  const slope=clamp(Number(m.emaSlope||0),-8,8);
  const volatility=Number(m.volatilityPct||0);
  const rangePos=clamp(Number(m.rangePosition||50),0,100);
  const liquidity=m.quoteVolume>0?clamp((Math.log10(Math.max(1,m.quoteVolume))-5)/4*100,0,100):35;
  const dataQuality=clamp(Number(m.dataQuality||100),0,100);
  const momentumScore=clamp((momentum+12)/24*100,0,100);
  const volumeScore=clamp((volumeRatio-0.75)/1.75*100,0,100);
  const trendScore=clamp((trend/12)*100,0,100);
  const slopeScore=clamp((slope+8)/16*100,0,100);
  const volatilityScore=volatility>0?clamp(100-Math.abs(volatility-55)*1.6,0,100):50;
  const locationScore=rangePos>=35&&rangePos<=85?100:rangePos<20?35:70;
  const adxScore=clamp(Number(m.adx||0)/35*100,0,100), adxDirection=Number(m.adxBull)?100:50, bbScore=clamp(100-Math.abs(Number(m.bbPosition||50)-62)*1.8,0,100), ichimokuScore=clamp(Number(m.ichimokuScore||50),0,100); const fibScore=Number(m.fibonacciScore||50), structureScore=Number(m.structureScore||50), structureCombined=Number(m.structureCombinedScore||50);
  const baseRaw=signalPct*.23+momentumScore*.12+volumeScore*.08+trendScore*.09+slopeScore*.07+adxScore*.06+adxDirection*.04+bbScore*.05+ichimokuScore*.07+liquidity*.05+volatilityScore*.06+locationScore*.03+dataQuality*.04+fibScore*.025+structureScore*.025+structureCombined*.02;
  const baseScore=clamp(baseRaw,0,100);
  const mtfScore=Number.isFinite(Number(m.mtfScore))?Number(m.mtfScore):50;
  const regimeInfo=m.regimeInfo||marketRegime(m);
  const portfolio=portfolioIntelligence(m);
  const riskScore=clamp((100-Math.abs(volatility-55)*1.25-Math.max(0,rangePos-88)*1.5-Math.max(0,18-rangePos)*1.5)*regimeInfo.riskMultiplier*0.72 + portfolio.score*0.28,0,100);
  const ex=adaptiveExecutionForMarket(m);const atrPct=Number(m.atrPct||0);const atrMult=Number(ex.atrStopMultiplier||2);const stopFloor=Number(ex.sl||settings.sl||2);const stopPct=clamp(Math.max(stopFloor,atrPct*atrMult||volatility*.035),stopFloor,Math.max(stopFloor,8));
  const rewardRisk=stopPct>0?Number(ex.tp||settings.tp||4.5)/stopPct:1;
  const rrScore=clamp(rewardRisk/2*100,0,100);
  const mlScore=mlGateScore(m); const mlWeight=(m.mlStatus==='STABLE'||m.mlStatus==='READY')?.08:0;
  const score=Math.round(clamp((baseScore*.64+mtfScore*.12+riskScore*.12+rrScore*.05+regimeInfo.fit*.07)*(1-mlWeight)+mlScore*mlWeight,0,100));
  const label=score>=82?'HIGH':score>=68?'MEDIUM':score>=55?'WATCH':'LOW';
  const ai=aiConsensus(m,{score,signalPct});
  const meta=metaDecisionLayer(m,{score,ai,regimeInfo,portfolio});
  const league=championChallenger(m,{score,aiConsensus:ai.consensus,mtfScore,riskScore,metaScore:meta.score,rewardRisk});
  const decision=strategyEnsembleDecision(m,{score,signalPct,mtfScore,riskScore,rewardRisk,metaScore:meta.score});
  const activeTf=m.timeframe||settings.timeframe||'4h';
  const learned=learnedStrategyFor(`${m.base}/${m.quote}`,activeTf);
  const strategyPolicy=strategyPolicySelection(m,{assetStrategy:learned?.winner||null,strategy:learned?.winner||null,contextPolicySelected:[]});
  const selectedStrategy=strategyPolicy.selectedStrategy||learned?.winner||null;
  const selectedVariant=strategyPolicy.selectedVariant||learned?.winnerVariant||null;
  const assetStrategyConfidence=learned?Number(learned.confidence||0):0;
  const assetStrategyFit=learned?clamp(50+(assetStrategyConfidence-50)*0.6,0,100):50;
  const agi=agiApplyToOpportunity(m,{...m,score,aiConsensus:ai.consensus,decisionConfidence:decision.confidence,mtfScore,riskScore,rewardRisk,metaScore:meta.score,uncertainty:meta.uncertainty,abstain:meta.abstain,trendStrength:trend,momentum,regimeFit:regimeInfo.fit,mlProbability:Number(m.mlProbability??50)},decision);
  const abstain=meta.abstain || decision.decision==='REJECT' || (agi.action==='NO_TRADE'||agi.action==='CONFLICT');
  const fusion=applyContextFusionToOpportunity(m,{...m,score,aiConsensus:ai.consensus,decisionConfidence:decision.confidence,mtfScore,riskScore,rewardRisk,metaScore:meta.score,uncertainty:meta.uncertainty,abstain,trendStrength:trend,momentum,mlProbability:Number(m.mlProbability??50),assetStrategy:selectedStrategy||null,strategy:selectedStrategy||null});
  const policy=contextPolicySelection(m,{assetStrategy:learned?.winner||null,strategy:learned?.winner||null},fusionSourceEvidence(m,{...m,score,mlProbability:Number(m.mlProbability??50),assetStrategy:learned?.winner||null}));
  const policyBoost=policy.learned?clamp((Number((policy.rows?.[0]?.weight)||1)-1)*100*Number(contextPolicyStore().maxInfluence||.08),-2,4):0;
  const learnedBoost=learned&&assetStrategyConfidence>=70?clamp((assetStrategyFit-50)*0.08,-2,4):0;
  const strategyPolicyBoost=strategyPolicy.learned?clamp((Number(strategyPolicy.selectedScore||50)-50)*Number(contextPolicyStore().maxInfluence||.08)/2,-2,3):0;
  const recovery=adaptiveRecovery(m,{...m,assetStrategy:selectedStrategy||learned?.winner||'BALANCED',strategy:selectedStrategy||learned?.winner||'BALANCED'},strategyPolicy,fusion.selected);
  recordRecoveryDecision(recovery,m,{...m,assetStrategy:selectedStrategy||learned?.winner||'BALANCED'});
  const recoveryBoost=recovery.recovered?Number(recovery.boost||0):0;
  const rankScore=Math.round(clamp(score*.51+decision.confidence*.17+mtfScore*.07+riskScore*.07+rrScore*.04+meta.score*.09+league.activeScore*.05+learnedBoost+strategyPolicyBoost+Number(agi.finalBoost||0)+Number(fusion.rankBoost||0)+policyBoost+recoveryBoost,0,100));
  return {score,rankScore,label,aiScore:Number(agi.score||50),agiScore:Number(agi.score||50),agiConfidence:Number(agi.confidence||50),agiAction:agi.action,agiConflict:Number(agi.conflict||0),agiReason:agi.reason,aiConsensus:ai.consensus,decision:decision.decision,decisionConfidence:decision.confidence,strategyVotes:decision.votes,signalPct,momentum,volumeRatio,trendStrength:trend,emaSlope:slope,volatilityPct:volatility,rangePosition:rangePos,liquidity,dataQuality,mtfScore:Number(m.mtfScore||50),mtfAlignment:Number(m.mtfAlignment||50),riskScore,stopPct,rewardRisk,adx:Number(m.adx||0),bbPosition:Number(m.bbPosition||50),ichimokuScore:Number(m.ichimokuScore||50),mlProbability:Number(m.mlProbability??50),mlStatus:m.mlStatus||'INSUFFICIENT_DATA',mlAccuracy:Number(m.mlAccuracy||0),mlOosAccuracy:Number(m.mlOosAccuracy||0),mlBaselineAccuracy:Number(m.mlBaselineAccuracy||0),mlPrecision:Number(m.mlPrecision||0),mlRecall:Number(m.mlRecall||0),mlBrier:Number(m.mlBrier||0),mlDrift:m.mlDrift||{status:'INSUFFICIENT_DATA',score:100},regime:regimeInfo.regime,regimeFit:regimeInfo.fit,riskMultiplier:regimeInfo.riskMultiplier,metaScore:meta.score,uncertainty:meta.uncertainty,abstain,modelChampion:league.champion,modelActive:league.active,modelActiveScore:league.activeScore,modelScores:league.scores,contextFusionScore:fusion.score,contextFusionConfidence:fusion.confidence,contextFusionConflict:fusion.conflict,contextFusionSources:fusion.selected,contextFusionAgreement:fusion.agreement,assetStrategy:selectedStrategy||null,assetStrategyConfidence,assetStrategyFit,assetStrategyVariant:selectedVariant,learnedVariant:selectedVariant,learnedParameters:strategyPolicy.selectedParameters||learned?.winnerParameters||{},learnedExecutionVariant:strategyPolicy.selectedExecution||learned?.winnerExecutionVariant||null,learnedExecution:strategyPolicy.selectedExecutionPatch||learned?.winnerExecution||null,strategyPolicyStrategy:selectedStrategy||null,strategyPolicyVariant:selectedVariant,strategyPolicyExecution:strategyPolicy.selectedExecution||null,strategyPolicyScore:strategyPolicy.selectedScore,strategyPolicyConfidence:strategyPolicy.confidence,strategyPolicyLearned:strategyPolicy.learned,strategyPolicyFeatureBucket:strategyPolicy.featureBucket,strategyPolicyBoost:strategyPolicyBoost,contextPolicyCombo:policy.combo,contextPolicySelected:policy.selected,contextPolicyConfidence:policy.confidence,contextPolicyBoost:policyBoost,recoveryAction:recovery.action,recoveryStrategy:recovery.recommendedStrategy,recoverySources:recovery.recommendedSources,recoveryReason:recovery.reason,recoveryBoost:recoveryBoost,fibonacciScore:Number(m.fibonacciScore||50),fibonacciLevel:m.fibonacciLevel,fibonacciPosition:Number(m.fibonacciPosition||50),structureScore:Number(m.structureScore||50),structureDirection:Number(m.structureDirection||0),structureBOS:m.structureBOS||null,structureFVG:m.structureFVG||null,structureOrderBlock:m.structureOrderBlock||null};
}
function indicatorScore(m){let score=0,total=0,i=settings.indicators;if(i.utbot?.enabled){total++;if(m.ut==='buy')score++;}if(i.rsi.enabled){total++;if(m.rsi<=i.rsi.threshold)score++;}if(i.ema.enabled){total++;if(m.trend)score++;}if(i.fractals.enabled){total++;if(m.fractal)score++;}if(i.macd.enabled){total++;if(m.macd)score++;}if(i.volume.enabled){total++;if(m.volume)score++;}if(i.atr.enabled){total++;if(m.atr)score++;}return {score,total,qualified:total>0&&score>=Math.min(settings.minSignalScore,total)};}
function signalDetail(m){const i=settings.indicators, parts=[];if(i.utbot?.enabled)parts.push(['UT Bot',m.ut==='buy']);if(i.rsi?.enabled)parts.push(['RSI',m.rsi<=i.rsi.threshold]);if(i.ema?.enabled)parts.push(['EMA',m.trend]);if(i.macd?.enabled)parts.push(['MACD',m.macd]);if(i.fractals?.enabled)parts.push(['Fractal',m.fractal]);if(i.volume?.enabled)parts.push(['Volume',m.volume]);if(i.atr?.enabled)parts.push(['ATR',m.atr]);const score=parts.filter(x=>x[1]).length,total=parts.length,required=Math.min(settings.minSignalScore,total);const qualified=total>0&&score>=required;const ratio=total?score/total:0;const grade=qualified?(score===total&&total>1?'STRONG BUY':'BUY'):(m.ut==='sell'?'SELL':'WAIT');return {parts,score,total,required,qualified,grade,ratio};}
function renderOpportunities(){
  const source=(settings.autoSelection?selectedOpportunities:qualifiedOpportunities)
    .map(symbol=>markets.find(m=>m.symbol===pairParts(symbol).symbol))
    .filter(Boolean).filter(m=>m.price>0);
  const rows=source.map(m=>({m,o:opportunityScore(m)})).sort((a,b)=>b.o.rankScore-a.o.rankScore);
  const el=$('#opportunityRows'); if(!el)return;
  const strip=$('#topOpportunityStrip');
  if(strip) strip.innerHTML=rows.map((x,i)=>`<button type="button" class="top-opportunity" data-trade="${x.m.base}/${x.m.quote}" title="Simulate ${x.m.base}/${x.m.quote}"><strong>#${i+1} ${x.m.base}/${x.m.quote}</strong><span>Score ${x.o.score} · Rank ${x.o.rankScore} · AI ${x.o.aiConsensus}</span><small>${x.o.decision} · ${x.o.strategyVotes}/2 core strategies · MTF ${x.o.mtfScore} · Risk ${x.o.riskScore} · $${Number(x.m.price).toLocaleString()} · 24h ${x.m.change>=0?'+':''}${x.m.change}%</small></button>`).join('')||'<div class="empty-state">No Top opportunities yet.</div>';
  el.innerHTML=rows.map((x,i)=>`<tr class="opportunity-row" data-trade="${x.m.base}/${x.m.quote}" title="Open ${x.m.base}/${x.m.quote} details">
    <td><strong>#${i+1}</strong></td><td><strong>${x.m.base}/${x.m.quote}</strong><br><small>$${Number(x.m.price).toLocaleString()}</small></td>
    <td><strong>${x.o.score}/100</strong><br><small>${x.o.label}</small></td><td>${x.o.momentum>=0?'+':''}${x.o.momentum.toFixed(2)}%</td>
    <td>${x.o.volumeRatio.toFixed(2)}×</td><td>${x.m.quoteVolume?Number(x.m.quoteVolume).toLocaleString():'—'}</td>
    <td><strong>${x.o.aiConsensus}/100</strong></td><td><strong>${x.o.metaScore}/100</strong><br><small>${x.o.uncertainty}% uncertainty</small></td><td>${x.o.regime}<br><small>fit ${x.o.regimeFit} · ${x.o.abstain?'ABSTAIN':'ACTIVE'}</small></td><td>${Number(x.o.dataQuality||0)}/100<br><small>${x.o.decision} · Conf ${x.o.decisionConfidence} · MTF ${x.o.mtfScore} · RR ${x.o.rewardRisk.toFixed(2)}</small></td></tr>`).join('')||'<tr><td colspan="8">No qualified opportunities. The engine will not promote unqualified setups.</td></tr>';
  const status=$('#opportunityStatus'); if(status)status.textContent=rows.length?`Top ${rows.length} · qualified opportunities only`:'No qualified opportunities';
}
function unifiedSignalStatus(m){
  const o=opportunityScore(m);
  const engine=engineQualified(m,o);
  const indicator=indicatorScore(m).qualified;
  if(engine) return {key:'qualified',label:'ENGINE QUALIFIED',className:'qualified',o,indicator};
  if(indicator) return {key:'signal',label:'INDICATOR SIGNAL',className:'signal',o,indicator};
  return {key:'watch',label:'WATCH',className:'watch',o,indicator};
}
function signalCandidates(){
  const pairs=[...new Set([
    ...watchPairs(),
    ...qualifiedOpportunities,
    ...selectedOpportunities,
    ...lastNearMisses.map(x=>`${x.m.base}/${x.m.quote}`)
  ])];
  return pairs.map(pair=>markets.find(m=>m.symbol===pairParts(pair).symbol)).filter(m=>m&&m.price>0)
    .map(m=>({m,s:unifiedSignalStatus(m)})).sort((a,b)=>{
      const rank={qualified:3,signal:2,watch:1};
      return (rank[b.s.key]-rank[a.s.key])||((b.s.o.rankScore||0)-(a.s.o.rankScore||0));
    });
}
function renderSignals(){
  const items=signalCandidates().filter(x=>signalFilter==='all'||x.s.key===signalFilter);
  const cards=items.map(({m,s})=>{
    const d=signalDetail(m),o=s.o;
    const action=s.key==='qualified'?`<button class="signal-action" data-trade="${m.coin}/${m.quote}">Simulate</button>`:(s.key==='signal'?`<button class="signal-action research-action" data-trade="${m.coin}/${m.quote}">Research / Simulate</button>`:'');
    return `<article class="signal-card unified-signal-card"><div class="signal-card-head"><div><h3>${m.coin}/${m.quote}</h3><small class="meta">$${Number(m.price).toLocaleString()} · ${m.timeframe||settings.timeframe} · 24h ${m.change>=0?'+':''}${m.change}%</small></div><span class="signal-grade ${s.className}">${s.label}</span></div><div class="signal-metrics"><span>Score <strong>${o.score}</strong></span><span>AI <strong>${o.aiConsensus}</strong></span><span>Confidence <strong>${o.decisionConfidence}</strong></span><span>Meta <strong>${o.metaScore}</strong></span><span>R:R <strong>${o.rewardRisk.toFixed(2)}</strong></span></div><div class="signal-components">${d.parts.map(([name,ok])=>`<span class="signal-chip ${ok?'pass':'off'}">${name} ${ok?'✓':'·'}</span>`).join('')||'<span class="signal-chip off">No indicators enabled</span>'}</div><small class="meta">Strategy ${o.strategyVotes}/2 · Risk ${o.riskScore} · Data ${o.dataQuality} · MTF ${o.mtfScore}</small>${action}</article>`;
  }).join('');
  const cardsEl=$('#signalCards'); if(cardsEl) cardsEl.innerHTML=cards||'<div class="empty-state">No signals match the current filter. Run a scan or switch the filter.</div>';
  const status=$('#signalCenterStatus'); if(status) status.textContent=`${signalCandidates().length} current signals · unified engine model`;
  const qc=$('#signalQualifiedCount'); if(qc) qc.textContent=qualifiedOpportunities.length;
  const tc=$('#signalTopCount'); if(tc) tc.textContent=selectedOpportunities.length;
  const mc=$('#signalManualCount'); if(mc) mc.textContent=watchPairs().length;
  const nc=$('#signalNearCount'); if(nc) nc.textContent=lastNearMisses.length;
  const rowsEl=$('#signalMatrixRows');
  if(rowsEl){
    rowsEl.innerHTML=signalCandidates().map(({m,s})=>`<tr><td><strong>${m.coin}/${m.quote}</strong></td><td><span class="signal ${s.className==='qualified'?'':'wait'}">${s.label}</span></td><td>${s.o.score}</td><td>${s.o.aiConsensus}</td><td>${s.o.decisionConfidence}</td><td>${s.o.strategyVotes}/2</td><td>${s.o.riskScore}</td><td>${s.o.rewardRisk.toFixed(2)}</td><td>${s.o.dataQuality}</td></tr>`).join('')||'<tr><td colspan="9">Run a scan to populate the decision matrix.</td></tr>';
  }
}

function trendCycleEligible(m,o){
  if(!m||!o) return false;
  const trend=Number(o.trendStrength||0), mtf=Number(o.mtfScore||0), risk=Number(o.riskScore||0), ai=Number(o.aiConsensus||0);
  return trend>=8 && mtf>=70 && risk>=65 && ai>=settings.aiConsensusThreshold;
}
function cycleModeFor(m,o){
  const mode=String(settings.tradeCycleMode||'auto').toLowerCase();
  if(mode==='single') return 'SINGLE';
  if(mode==='trend') return trendCycleEligible(m,o)?'TREND CYCLE':'SINGLE';
  return trendCycleEligible(m,o)?'TREND CYCLE':'SINGLE';
}
function cycleReentryAllowed(m,o,p){
  if(!m||!o||!p) return false;
  const score=Number(o.score||0), ai=Number(o.aiConsensus||0), mtf=Number(o.mtfScore||0), risk=Number(o.riskScore||0);
  return p.cycleMode==='TREND CYCLE' && p.cycles<Math.max(1,Number(settings.trendCycleMaxCycles)||4) && score>=Number(settings.trendCycleReentryScore||72) && ai>=settings.aiConsensusThreshold && mtf>=70 && risk>=65 && m.trend;
}
function closeSimulatedCycle(p,m,ret,reason){
  const cycleTarget=Number(settings.trendCycleTarget||0.8);
  const partial=Math.max(10,Math.min(90,Number(settings.trendCyclePartial)||30));
  if(p.cycleMode==='TREND CYCLE' && reason==='cycle-profit' && !p.partialTaken){
    const sold=p.amount*partial/100, proceeds=sold*(1+ret/100); balance+=proceeds; const pnl=proceeds-sold;
    rollDailyStats(); dailyStats.realizedPnl+=pnl;
    p.amount-=sold; p.partialTaken=true; p.cycles=(p.cycles||1)+1; p.lastCycleAt=Date.now();
    p.entryPrice=m.price; p.price=m.price; p.trailingStopPct=Math.max(0.2,Number(settings.trendCycleTrail)||0.7);
    closedTrades.unshift({coin:p.coin,returnPct:ret,pnl,reason:'trend cycle partial exit',closedAt:Date.now(),cycle:p.cycles});
    closedTrades=closedTrades.slice(0,100); addLog(`Trend Cycle: ${p.coin}/${p.quote} partial ${partial}% exit at +${ret.toFixed(2)}%; cycle ${p.cycles}.`); return true;
  }
  return false;
}

const SHADOW_KEY='lsai-shadow-ledger-v1';
function shadowLedger(){try{const x=JSON.parse(localStorage.getItem(SHADOW_KEY)||'[]');return Array.isArray(x)?x:[]}catch{return []}}
function saveShadowLedger(x){localStorage.setItem(SHADOW_KEY,JSON.stringify(x.slice(-300)))}
function resolvedNow(ledger){return ledger.some(x=>x.resolved&&!x.feedbackApplied)}
function updateShadowLedger(){
  const ledger=shadowLedger(), now=Date.now();
  for(const r of ledger){
    const m=markets.find(x=>x.symbol===r.symbol); if(!m||!m.price)continue;
    const ret=(Number(m.price)/Math.max(1,Number(r.entryPrice))-1)*100;
    r.lastPrice=Number(m.price); r.unrealizedPct=ret; r.ageHours=(now-r.createdAt)/3600000;
    r.bestPct=Math.max(Number(r.bestPct||ret),ret); r.worstPct=Math.min(Number(r.worstPct||ret),ret);
    const horizonHours=Number(r.horizonHours||96);
    if(!r.resolved && r.ageHours>=horizonHours){r.resolved=true;r.resolvedAt=now;r.outcome=ret>=0?'WIN':'LOSS';r.realizedPct=ret;r.correct=(r.predictedUp==null?null:(r.predictedUp?ret>0:ret<=0));r.feedbackApplied=false;r.agiFeedbackApplied=false}
  }
  const newlyResolved=resolvedNow(ledger); if(newlyResolved){updateFeedbackModel(); for(const r of ledger)if(r.resolved){if(!r.feedbackApplied){recordChampionOutcome(r);r.feedbackApplied=true;}if(!r.agiFeedbackApplied){agiRecordResolved(r);r.agiFeedbackApplied=true;}} } saveShadowLedger(ledger); renderChampionChallenger(); return ledger;
}
function captureShadowDecisions(items){
  const ledger=shadowLedger(), now=Date.now();
  for(const x of items||[]){
    const symbol=x.m.symbol, d=x.d, o=x.o; if(!symbol||!x.m.price||!d)continue;
    const recent=ledger.find(r=>r.symbol===symbol&&!r.resolved&&now-r.createdAt<24*3600000);
    if(recent)continue;
    ledger.push({id:`${symbol}-${now}-${Math.random().toString(36).slice(2,7)}`,symbol,pair:`${x.m.base}/${x.m.quote}`,createdAt:now,entryPrice:Number(x.m.price),decision:d.decision,confidence:Number(d.confidence||0),score:Number(o.score||0),rankScore:Number(o.rankScore||0),ai:Number(o.aiConsensus||0),mlProbability:Number(o.mlProbability??50),predictedUp:Number(o.mlProbability??50)>=50,predictedRegime:x.m.regime||'UNKNOWN',timeframe:x.m.timeframe||'AUTO',strategy:o.assetStrategy||d.strategy||'CORE',features:x.m.mlFeatures||null,horizonHours:96,bestPct:0,worstPct:0,resolved:false,modelChampion:x.o.modelChampion||'BALANCED',modelActive:x.o.modelActive||'BALANCED',modelScores:x.o.modelScores||{},evidence:agiEvidence(x.m,x.o),selectedSources:x.o.contextPolicySelected||x.o.contextFusionSources||['core'],contextPolicyCombo:x.o.contextPolicyCombo||'core',agiAction:x.o.agiAction||'WAIT',agiScore:Number(x.o.agiScore||50)});
  }
  saveShadowLedger(ledger);
}
function renderShadowMonitor(){
  const box=$('#shadowMonitorPanel');if(!box)return;const l=updateShadowLedger(),resolved=l.filter(x=>x.resolved),wins=resolved.filter(x=>x.outcome==='WIN').length,avg=resolved.length?resolved.reduce((s,x)=>s+Number(x.realizedPct||0),0)/resolved.length:0,correct=resolved.filter(x=>x.correct).length;
  $('#shadowCount').textContent=l.length;$('#shadowResolved').textContent=resolved.length;$('#shadowWinRate').textContent=resolved.length?(wins/resolved.length*100).toFixed(1)+'%':'—';$('#shadowAvg').textContent=resolved.length?(avg>=0?'+':'')+avg.toFixed(2)+'%':'—';const scored=resolved.filter(x=>x.correct!==null&&x.correct!==undefined);$('#shadowAccuracy').textContent=scored.length?(correct/scored.length*100).toFixed(1)+'%':'—';$('#shadowMonitorStatus').textContent=settings.shadowEnabled||settings.validationMode==='shadow'?'SHADOW ON · decisions only':'SHADOW OFF';
  $('#shadowRows').innerHTML=l.slice().reverse().slice(0,10).map(x=>`<tr><td>${x.pair}</td><td>${x.decision}</td><td>${x.score}</td><td>${Number(x.mlProbability).toFixed(1)}%</td><td>${Number(x.unrealizedPct||0)>=0?'+':''}${Number(x.unrealizedPct||0).toFixed(2)}%</td><td>${x.resolved?x.outcome:'OPEN'}</td></tr>`).join('')||'<tr><td colspan="6">No shadow decisions recorded yet.</td></tr>';
}
function startShadowMonitor(){settings.shadowEnabled=true;localStorage.setItem('lsai-shadow-enabled','1');renderShadowMonitor();}
function stopShadowMonitor(){settings.shadowEnabled=false;localStorage.setItem('lsai-shadow-enabled','0');renderShadowMonitor()}
window.startShadowMonitor=startShadowMonitor;window.stopShadowMonitor=stopShadowMonitor;function renderPaperMonitor(){const p=paperStats();const ids=[['paperCount',p.count],['paperClosed',p.closed],['paperWinRate',p.closed?p.winRate.toFixed(1)+'%':'—'],['paperAvg',p.closed?(p.avg>=0?'+':'')+p.avg.toFixed(2)+'%':'—'],['paperNet',p.closed?(p.net>=0?'+':'')+p.net.toFixed(2):'—']];for(const [id,v] of ids){const e=$('#'+id);if(e)e.textContent=v}const st=$('#paperMonitorStatus');if(st)st.textContent=settings.validationMode==='paper'?'PAPER ON · virtual execution':'SIMULATION ONLY'}


const PAPER_KEY='lsai-paper-ledger-v1';
function paperLedger(){try{const x=JSON.parse(localStorage.getItem(PAPER_KEY)||'[]');return Array.isArray(x)?x:[]}catch{return []}}
function savePaperLedger(x){localStorage.setItem(PAPER_KEY,JSON.stringify(x.slice(-500)))}
function paperStats(){const l=paperLedger(),closed=l.filter(x=>x.status==='CLOSED'),wins=closed.filter(x=>Number(x.pnlPct)>0);const avg=closed.length?closed.reduce((a,x)=>a+Number(x.pnlPct||0),0)/closed.length:0;return {count:l.length,closed:closed.length,winRate:closed.length?wins.length/closed.length*100:0,avg,net:closed.reduce((a,x)=>a+Number(x.pnl||0),0),open:l.filter(x=>x.status==='OPEN').length}}
function recordPaperPosition(p){const l=paperLedger();if(l.some(x=>x.id===p.paperId))return;p.paperId=`P-${p.symbol}-${p.openedAt}`;l.push({id:p.paperId,symbol:p.symbol,pair:`${p.coin}/${p.quote}`,openedAt:p.openedAt,entryPrice:Number(p.price),amount:Number(p.amount),status:'OPEN',regime:p.regime||'UNKNOWN',mlProbability:Number(p.mlProbability||50),score:Number(p.score||0),timeframe:p.timeframe||null,timeframeScore:Number(p.timeframeScore||0),assetStrategy:p.assetStrategy||null,assetStrategyVariant:p.assetStrategyVariant||null,assetParameters:p.assetParameters||{},assetExecution:p.assetExecution||null,profileConfidence:Number(p.profileConfidence||0),contextPolicySelected:p.contextPolicySelected||['core'],contextFusionSources:p.contextFusionSources||['core'],assetStrategyVariant:p.assetStrategyVariant||null,strategyPolicyStrategy:p.strategyPolicyStrategy||null,strategyPolicyVariant:p.strategyPolicyVariant||null,strategyPolicyExecution:p.strategyPolicyExecution||null,fibonacciScore:Number(p.fibonacciScore||50),structureScore:Number(p.structureScore||50),structureCombinedScore:Number(p.structureCombinedScore||50)});savePaperLedger(l)}
function updatePaperLedger(){const l=paperLedger(), now=Date.now();for(const r of l){if(r.status!=='OPEN')continue;const m=markets.find(x=>x.symbol===r.symbol);if(!m?.price)continue;r.lastPrice=Number(m.price);r.pnlPct=(r.lastPrice/r.entryPrice-1)*100;r.ageHours=(now-r.openedAt)/3600000;if(r.ageHours>=96){r.status='CLOSED';r.closedAt=now;r.pnl=r.amount*r.pnlPct/100;r.reason='paper horizon review';if(!r.agiFeedbackApplied){const mm={trendStrength:Number(r.trendStrength||0),momentum:Number(r.momentum||0),mtfScore:Number(r.mtfScore||50),riskScore:Number(r.riskScore||50),rewardRisk:Number(r.rewardRisk||1),regimeFit:Number(r.regimeFit||50),mlProbability:Number(r.mlProbability||50)};agiRecordResolved({id:r.id,symbol:r.symbol,timeframe:r.timeframe,strategy:r.strategy||r.assetStrategy,regime:r.regime||'UNKNOWN',realizedPct:r.pnlPct,evidence:agiEvidence(mm,{...mm,momentum:mm.momentum,trendStrength:mm.trendStrength,regimeFit:mm.regimeFit}),selectedSources:r.contextPolicySelected||r.contextFusionSources||['core'],assetStrategy:r.assetStrategy||null,variant:r.assetStrategyVariant||r.strategyPolicyVariant||null,executionVariant:r.strategyPolicyExecution||null,fibonacciScore:Number(r.fibonacciScore||50),structureScore:Number(r.structureScore||50),structureCombinedScore:Number(r.structureCombinedScore||50),source:'paper'});r.agiFeedbackApplied=true}}}savePaperLedger(l);return l}
function autoTradeRequirements(){
  const w=(()=>{try{return JSON.parse(localStorage.getItem('lsai-walkforward-last')||'null')}catch{return null}})();
  const wb=(()=>{try{return JSON.parse(localStorage.getItem('lsai-walkbackward-last')||'null')}catch{return null}})();
  const mc=(()=>{try{return JSON.parse(localStorage.getItem('lsai-montecarlo-last')||'null')}catch{return null}})();
  const st=(()=>{try{return JSON.parse(localStorage.getItem('lsai-stress-last')||'null')}catch{return null}})();
  const p=paperStats();
  const shadow=shadowLedger().filter(x=>x.resolved);
  const championRows=typeof championStatsSummary==='function'?championStatsSummary():[];
  const champion=championRows.find(x=>x.key===championState().champion);
  const checks=[
    ['Forward Purged Walk-forward',!!w&&w.verdict==='ROBUST'],
    ['Backward diagnostic',!!wb&&wb.verdict==='PASS DIAGNOSTIC'],
    ['Monte Carlo',!!mc&&mc.verdict==='ROBUST'],
    ['Stress Test',!!st&&String(st.verdict||'').startsWith('PASS')],
    ['Paper closed trades',p.closed>=50],
    ['Paper win rate',p.closed>=50&&p.winRate>=52],
    ['Paper drawdown evidence',p.closed>=50&&p.net>=-settings.budget*.05],
    ['Shadow resolved evidence',shadow.length>=50],
    ['Champion evidence',!!champion&&champion.trials>=50],
    ['Daily loss / exposure guardrails',settings.dailyLossLimit>0&&settings.maxExposure<=50],
    ['Auto-trade armed',settings.autoTradeArmed===true],
  ];
  const passed=checks.filter(x=>x[1]).length;
  const liveEligible=passed===checks.length&&settings.liveTradingAcknowledged===true;
  return {checks,passed,total:checks.length,liveEligible};
}
function renderAutoTradeControl(){
  const box=$('#autoTradeStatusPanel'); if(!box)return;
  const g=autoTradeRequirements(), mode=settings.autoTradeMode||'off';
  const label=mode==='paper'?'PAPER AUTO':mode==='live'?'LIVE REQUEST':'OFF';
  const state=mode==='live'?(g.liveEligible?'LIVE ELIGIBLE — EXECUTION LAYER LOCKED':'LIVE LOCKED — VALIDATION REQUIRED'):(mode==='paper'?'PAPER AUTO READY':'MANUAL / SIMULATION');
  box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">AUTO TRADE CONTROL</p><h2>Execution safety gate</h2></div><span class="tag">${label}</span></div><div class="performance-results"><article><span>Current mode</span><strong>${state}</strong><small>Auto Trade لا ينفذ أوامر حقيقية في هذه النسخة.</small></article><article><span>Readiness evidence</span><strong>${g.passed}/${g.total}</strong><small>Forward, backward diagnostic, Monte Carlo, stress, shadow, paper &amp; risk gates.</small></article><article><span>Armed</span><strong>${settings.autoTradeArmed?'YES':'NO'}</strong><small>لا يتم التسليح تلقائيًا.</small></article><article><span>Live execution</span><strong>LOCKED</strong><small>يتطلب Execution Gateway منفصلًا ومصادقة صريحة لاحقًا.</small></article></div><div class="validation-row"><strong>Mandatory live requirements</strong><span>${g.checks.map(c=>`${c[1]?'✓':'✕'} ${c[0]}`).join(' · ')}</span></div><p class="muted">Backward Walk هو بوابة مطلوبة لـ Auto Trade في هذه النسخة، لكنه ليس كافيًا وحده: يجب أن ينجح مع Forward OOS وMonte Carlo وStress وShadow وPaper وبوابات المخاطر. وظيفته تشخيص عدم تماثل النظام وكشف مشاكل البيانات.</p></div>`;
}
function readinessGate(){
  updatePaperLedger();
  const p=paperStats();
  const w=(()=>{try{return JSON.parse(localStorage.getItem('lsai-walkforward-last')||'null')}catch{return null}})();
  const wb=(()=>{try{return JSON.parse(localStorage.getItem('lsai-walkbackward-last')||'null')}catch{return null}})();
  const mc=(()=>{try{return JSON.parse(localStorage.getItem('lsai-montecarlo-last')||'null')}catch{return null}})();
  const st=(()=>{try{return JSON.parse(localStorage.getItem('lsai-stress-last')||'null')}catch{return null}})();
  const shadow=shadowLedger().filter(x=>x.resolved);
  const researchChecks=[
    ['Walk-forward',!!w&&w.verdict==='ROBUST',w?.verdict||'NOT RUN'],
    ['Backward diagnostic',!!wb&&wb.verdict==='PASS DIAGNOSTIC',wb?.verdict||'NOT RUN'],
    ['Monte Carlo',!!mc&&mc.verdict==='ROBUST',mc?.verdict||'NOT RUN'],
    ['Stress test',!!st&&String(st.verdict||'').startsWith('PASS'),st?.verdict||'NOT RUN'],
    ['Shadow evidence',shadow.length>=50,`${shadow.length}/50 resolved`],
    ['Paper sample',p.closed>=50,`${p.closed}/50 closed`],
    ['Paper win rate',p.closed>=50&&p.winRate>=52,p.closed?`${p.winRate.toFixed(1)}% / 52%`: 'NOT READY'],
    ['Paper drawdown evidence',p.closed>=50&&p.net>=-settings.budget*.05,p.closed?`${p.net>=0?'+':''}${p.net.toFixed(2)} / floor -${(settings.budget*.05).toFixed(2)}`:'NOT READY'],
  ];
  const researchPassed=researchChecks.filter(x=>x[1]).length;
  const auto=autoTradeRequirements();
  const status=researchPassed===researchChecks.length?'READY FOR AUTO-TRADE EVIDENCE':researchPassed>=5?'CAUTION — CONTINUE PAPER':'NOT READY';
  return {status,passed:researchPassed,total:researchChecks.length,checks:researchChecks,p,autoResearch:researchPassed===researchChecks.length,autoTradePassed:auto.passed===auto.total,autoTrade: auto};
}
function renderReadiness(){const el=$('#readinessResults');if(!el)return;const g=readinessGate();el.innerHTML=`<article><span>Research readiness</span><strong>${g.status}</strong></article><article><span>Research gates</span><strong>${g.passed}/${g.total}</strong></article><article><span>Auto Trade gate</span><strong>${g.autoTradePassed?'PASS':'NOT READY'}</strong><small>${g.autoTrade.passed}/${g.autoTrade.total} mandatory checks</small></article><article><span>Paper closed trades</span><strong>${g.p.closed}</strong></article><article><span>Paper win rate</span><strong>${g.p.closed?g.p.winRate.toFixed(1)+'%':'—'}</strong></article><div class="validation-row"><strong>Research gate details</strong><span>${g.checks.map(c=>`${c[1]?'✓':'✕'} ${c[0]}: ${c[2]}`).join(' · ')}</span></div><div class="validation-row"><strong>Auto Trade gate details</strong><span>${g.autoTrade.checks.map(c=>`${c[1]?'✓':'✕'} ${c[0]}`).join(' · ')}</span></div>`;$('#readinessStatus').textContent=g.status}
function render(){
  rollDailyStats(); renderOpportunities(); watchPairs().forEach(ensureMarket); const watched=watchPairs();
  const marketList=markets.filter(m=>watched.includes(m.coin+'/'+m.quote)&&m.price>0).slice(0,12);
  $('#marketRows').innerHTML=marketList.map(m=>{const s=unifiedSignalStatus(m);const action=s.key==='qualified'?`<button class="table-button" data-trade="${m.coin}/${m.quote}">Simulate</button>`:(s.key==='signal'?`<button class="table-button" data-trade="${m.coin}/${m.quote}">Research</button>`:'');return `<tr><td><strong>${m.coin}/${m.quote}</strong></td><td>$${Number(m.price).toLocaleString()}</td><td class="${m.change>=0?'positive':'negative'}">${m.change>=0?'+':''}${m.change}%</td><td><span class="signal ${s.className==='qualified'?'':'wait'}">${s.label}</span><small class="meta signal-subline">Score ${s.o.score} · AI ${s.o.aiConsensus} · Conf ${s.o.decisionConfidence}</small></td><td>${action}</td></tr>`}).join('')||'<tr><td colspan="5">No manual watchlist pairs with current market data.</td></tr>';
  const mwc=$('#marketWatchCount'); if(mwc) mwc.textContent=`${marketList.length} shown · unified engine strategy`;
  const safety=safetyStatus();$('#balance').textContent=money(balance);$('#safetyDailyLoss').textContent=`${safety.lossPct.toFixed(2)}% / ${settings.dailyLossLimit}%`;$('#safetyExposure').textContent=`${safety.exposurePct.toFixed(1)}% / ${settings.maxExposure}%`;$('#safetyStatus').textContent=(safety.lossBreached||safety.exposureBreached)?'TRADING PAUSED':'SAFE';$('#safetyStatus').className=(safety.lossBreached||safety.exposureBreached)?'negative':'positive';$('#positionsCount').textContent=positions.length;$('#positionCap').textContent=dynamicPositionCapacity(currentQualifiedOpportunities().length);
  const capEl=$('#positionCap'); if(capEl) capEl.title='No fixed position ceiling; capacity is determined by qualified opportunities, available capital, exposure and risk limits.';$('#riskAmount').textContent=money(settings.budget*settings.risk/100);$('#takeProfitValue').textContent=settings.tp+'%';$('#stopLossValue').textContent=settings.sl+'%';$('#holdingValue').textContent='Adaptive — no fixed holding period';$('#entryRule').textContent=`${settings.minSignalScore}+ indicator confirmations`;$('#riskRule').textContent=`${settings.risk}% maximum loss / trade`;$('#strategyName').textContent=settings.strategyName;$('#timeframeValue').textContent=settings.timeframeMode==='auto'?`AUTO · ${markets[0]?.timeframe||'per asset'}`:settings.timeframe;$('#positionsEmpty').hidden=positions.length>0;$('#portfolioTag').textContent=positions.length?`${positions.length} open`:'No positions';$('#positionsList').innerHTML=positions.map(p=>`<div class="position"><div><strong>${p.coin}/${p.quote}</strong><small>Entry $${p.price.toLocaleString()} · ${p.cycleMode||'SINGLE'} · cycle ${p.cycles||1} · adaptive exit</small></div><div><strong>${money(p.amount)}</strong><small>TP ${settings.tp}% · SL ${settings.sl}%</small></div></div>`).join('');renderLog();renderPerformance();renderMLMonitor();renderAdaptiveArchitecture();renderChampionChallenger();renderShadowMonitor();renderPaperMonitor();renderReadiness();renderAutoTradeControl();renderPrimaryControls();renderControlRoom();renderSignals();renderResearchDecision();
}
function reviewPositions(){
  const kept=[];
  for(const p of positions){
    const m=markets.find(x=>x.symbol===p.symbol), basePrice=Number(p.price||p.entryPrice||0), ret=m&&basePrice?(m.price/basePrice-1)*100:0;
    const o=m?opportunityScore(m):null;
    if(p.cycleMode==='TREND CYCLE' && m && ret>=Number(settings.trendCycleTarget||0.8) && !p.partialTaken){
      closeSimulatedCycle(p,m,ret,'cycle-profit');
      if(cycleReentryAllowed(m,o,p)){p.partialTaken=false;p.openedAt=Date.now();p.price=m.price;p.entryPrice=m.price;kept.push(p);continue;}
    }
    const trailing=Number(p.trailingStopPct||0);
    const weak=m&&!m.trend&&m.rsi<50;
    const trailHit=trailing>0&&ret<=-trailing&&p.partialTaken;
    const ex=adaptiveExecutionForMarket(m||p);const tp=Number(p.tpPct||ex.tp||settings.tp),sl=Number(p.slPct||ex.sl||settings.sl);const reason=trailHit?'trailing protection':ret>=tp?'take-profit reached':ret<=-sl?'stop-loss reached':weak?'trend weakened':null;
    if(!reason){kept.push(p);continue;}
    const returned=p.amount*(1+ret/100),pnl=returned-p.amount;balance+=returned;rollDailyStats();dailyStats.realizedPnl+=pnl;
    closedTrades.unshift({coin:p.coin,returnPct:ret,pnl,reason,closedAt:Date.now(),cycle:p.cycles||1});closedTrades=closedTrades.slice(0,100);
    addLog(`Adaptive simulated exit: ${p.coin}/${p.quote} - ${reason} (${ret.toFixed(2)}%).`)
  }
  positions=kept;persist();
}

function openTrade(pair){const m=markets.find(x=>x.symbol===pairParts(pair).symbol)||ensureMarket(pair);const safety=safetyStatus();if(!m||!m.price){addLog(`Trade blocked: no current Spot price for ${pair}. Run market scan first.`);return;}if(safety.lossBreached){addLog(`Trade blocked: daily loss limit of ${settings.dailyLossLimit}% reached.`);return;}if(safety.exposureBreached){addLog(`Trade blocked: portfolio exposure limit of ${settings.maxExposure}% reached.`);return;}if(lastEntryAt(pair)&&Date.now()-lastEntryAt(pair)<settings.cooldownMinutes*60000){addLog(`Trade blocked: ${pair} is inside the ${settings.cooldownMinutes}-minute cooldown.`);return;}pending=m;$('#tradeTitle').textContent=`Simulate ${m.base}/${m.quote} purchase`;$('#tradeDescription').textContent=`Reserve a simulated position using ${money(settings.dealAmount)}.`;$('#tradeChecklist').innerHTML=[`Spot pair only: ${m.base}/${m.quote}`,`Indicator signal: ${indicatorScore(m).score}/${indicatorScore(m).total}`,
    `Opportunity Engine: ${currentQualifiedOpportunities().some(x=>x.symbol===m.symbol)?'QUALIFIED':'Research only — not Top/Qualified'}`,`Risk capped at ${settings.risk}% with ${settings.sl}% stop loss`,`Take-profit target ${settings.tp}%`,`Trade mode: ${cycleModeFor(m,opportunityScore(m))}`,`Trend Cycle: partial ${settings.trendCyclePartial}% at +${settings.trendCycleTarget}% when trend remains valid`,`Adaptive exit; no fixed holding period — exits follow trend, momentum, volatility and risk conditions`,`No real funds involved`].map(x=>`<div>${x}</div>`).join('');$('#tradeDialog').showModal();}
async function refreshSpotMarket(inputPairs=null,providedTickers=null){
  const pairs=Array.isArray(inputPairs)?[...new Set(inputPairs.map(normalizePair).filter(Boolean))]:watchPairs();
  if(!pairs.length) throw new Error('No Spot pairs are selected');
  let tickers=Array.isArray(providedTickers)?providedTickers:[];
  if(!tickers.length){
    const now=Date.now();
    if(clientTickerCache.rows.length && now-clientTickerCache.at<CLIENT_TICKER_TTL) tickers=clientTickerCache.rows;
    else try{const tr=await apiFetch('/api/tickers',{cache:'no-store',retryAttempts:2});if(tr.ok){const td=await tr.json();tickers=Array.isArray(td.tickers)?td.tickers:[];if(tickers.length){clientTickerCache.at=now;clientTickerCache.rows=tickers;}}}catch{}
  }
  if(!tickers.length){
    for(const base of ['https://data-api.binance.vision','https://api.binance.com']){
      try{const r=await fetchWithTimeout(`${base}/api/v3/ticker/24hr`,{cache:'no-store',headers:{accept:'application/json'}},7000);const rows=await r.json().catch(()=>[]);if(r.ok&&Array.isArray(rows)){tickers=rows.map(x=>({symbol:x.symbol,price:Number(x.lastPrice),change:Number(x.priceChangePercent),quoteVolume:Number(x.quoteVolume),volume:Number(x.volume)}));break;}}catch{}
    }
  }
  const tickerMap=new Map(tickers.map(t=>[t.symbol,t]));
  const candidates=pairs.map(p=>({pair:p,symbol:pairParts(p).symbol,ticker:tickerMap.get(pairParts(p).symbol)}))
    .sort((a,b)=>(Number(b.ticker?.quoteVolume)||0)-(Number(a.ticker?.quoteVolume)||0));
  const maxPairs=String(settings.maxScanPairs).toLowerCase()==='auto'?Math.max(1,Math.min(300,Math.ceil(Math.max(pairs.length,universeSymbols.length||pairs.length)*0.05))):Math.max(1,Math.min(300,Number(settings.maxScanPairs)||pairs.length));
  // AUTO candidate selection already ranks liquidity. Do not apply the minimum
  // volume setting as a second hard gate here; doing so caused 60 candidates
  // to collapse to 32 before candle analysis. The volume threshold is a ranking
  // preference in AUTO mode, while the opportunity engine evaluates liquidity
  // as part of the composite score.
  const autoMode=!!settings.autoSelection;
  const minVol=Math.max(0,Number(settings.minQuoteVolume)||0);
  const eligible=autoMode
    ? candidates.slice(0,maxPairs)
    : candidates.filter(x=>!x.ticker || Number(x.ticker.quoteVolume||0)>=minVol).slice(0,maxPairs);
  const skipped=Math.max(0,pairs.length-eligible.length);
  const results=[]; const concurrency=String(settings.scanConcurrency).toLowerCase()==='auto'?Math.max(4,Math.min(12,Math.ceil(Math.sqrt(eligible.length)*1.5))):Math.max(1,Math.min(10,Number(settings.scanConcurrency)||4)); let cursor=0; let completed=0; let progressFailures=0;
  const progress=()=>{const status=$('#scanStatus'),detail=$('#scanDetail');if(!status||!detail)return;status.textContent='Scanning';detail.textContent=`Analyzing Binance Spot candidates: ${completed}/${eligible.length} completed${progressFailures?` · ${progressFailures} failed`:''} · canonical ${settings.timeframeMode==='auto'?'4h':(settings.timeframe||'4h')} first · deeper MTF only after qualification.`;};
  progress();
  async function worker(){
    while(cursor<eligible.length){
      const item=eligible[cursor++];
      try{
        const {base,quote,symbol}=pairParts(item.pair);
        // Fast broad scan: do not run the expensive adaptive-timeframe search for every
        // candidate. AUTO first evaluates one canonical Spot timeframe, then only qualified
        // opportunities receive deeper multi-timeframe confirmation below. This prevents
        // a 60-candidate scan from exploding into hundreds of public candle requests.
        const tfChoice={timeframe:settings.timeframeMode==='auto'?'4h':(settings.timeframe||'4h'),score:100,profile:null,ranked:[]};
        const activeTf=tfChoice.timeframe;
        let data=null;
        try{
          const r=await apiFetch(`/api/candles?symbol=${encodeURIComponent(symbol)}&interval=${encodeURIComponent(activeTf)}&limit=180`,{cache:'no-store',retryAttempts:1,timeoutMs:9000});
          const d=await r.json().catch(()=>({}));
          if(r.ok&&Array.isArray(d.candles))data=d;
        }catch{}
        if(!data){
          let lastErr='No candle source';
          for(const host of ['https://data-api.binance.vision','https://api.binance.com','https://api1.binance.com','https://api2.binance.com','https://api3.binance.com']){
            try{const r=await fetchWithTimeout(`${host}/api/v3/klines?symbol=${encodeURIComponent(symbol)}&interval=${encodeURIComponent(activeTf)}&limit=180`,{cache:'no-store',headers:{accept:'application/json'}},6500);const rows=await r.json().catch(()=>null);if(r.ok&&Array.isArray(rows)){data={candles:rows.map(x=>({openTime:x[0],open:Number(x[1]),high:Number(x[2]),low:Number(x[3]),close:Number(x[4]),volume:Number(x[5]),closeTime:x[6]}))};break;}lastErr=`HTTP ${r.status}`;}catch(e){lastErr=e.message||lastErr;}}
          if(!data)throw new Error(`${item.pair}: ${lastErr}`);
        }
        const c=data.candles||[];
        if(c.length<50)throw new Error(`${item.pair}: not enough candles (${c.length})`);
        const closes=c.map(x=>x.close),ind=settings.indicators;
        const ev=ind.ema?.enabled?ema(closes,ind.ema.period||20):[];
        const rv=ind.rsi?.enabled?rsi(closes,ind.rsi.period||14):[];
        const ut=ind.utbot?.enabled?utBotSignals(c,ind.utbot.keyValue||1,ind.utbot.atrPeriod||10,ind.utbot.source||'close'):null;
        const fr=ind.fractals?.enabled?fractals(c,ind.fractals.lookback||2):null;
        const mac=ind.macd?.enabled?macd(closes,ind.macd.fast||12,ind.macd.slow||26,ind.macd.signal||9):null;
        const at=atrSeries(c,ind.atr?.period||14),adxv=ind.adx?.enabled?adxDmi(c,ind.adx.period||14):null,bb=ind.bollinger?.enabled?bollingerBands(closes,ind.bollinger.period||20,ind.bollinger.multiplier||2):null,ich=ind.ichimoku?.enabled?ichimokuState(c,ind.ichimoku):null;
        const last=c.at(-1),lastClose=last.close,ageMs=Date.now()-Number(last.closeTime||last.openTime||Date.now());
        const avgVol=c.slice(-21,-1).reduce((a,x)=>a+Number(x.volume||0),0)/Math.max(1,Math.min(20,c.length-1));
        const quality=clamp(100-(ageMs>Math.max(15*60e3,intervalMs(activeTf)*2)?20:0)-(c.length<100?15:0),0,100);
        results.push({coin:base,base,quote,symbol,price:lastClose,change:item.ticker?Number(item.ticker.change):c.length>1?((lastClose/c.at(-2).close)-1)*100:0,quoteVolume:item.ticker?Number(item.ticker.quoteVolume):0,dataAt:Date.now(),candleAgeMs:ageMs,dataQuality:quality,rsi:rv.at(-1)??50,trend:ev.at(-1)!=null?lastClose>ev.at(-1):false,fractal:!!fr?.down.slice(Math.max(0,fr.down.length-(ind.fractals.lookback||2)-3),-1).some(Boolean),ut:ut?.signals.at(-1)||'neutral',macd:mac?mac.hist.at(-1)>0:false,volume:!ind.volume?.enabled||last.volume>=avgVol*(ind.volume.multiplier||1.2),atr:!ind.atr?.enabled||((at.at(-1)||0)/lastClose*100<=5),momentum:momentumPct(closes,12),volumeRatio:volumeRatio(c,20),trendStrength:trendStrength(closes,20),emaSlope:emaSlopePct(closes,ind.ema?.period||20,5),volatilityPct:volatilityPct(closes,20),rangePosition:rangePosition(c,20),macdMomentum:macdMomentum(mac),adx:adxv?.adx.at(-1)||0,adxBull:(adxv?.pdi.at(-1)||0)>(adxv?.mdi.at(-1)||0),bbPosition:bb?.position.at(-1)??50,bbWidth:bb?.width.at(-1)??0,atrPct:lastClose?((at.at(-1)||0)/lastClose*100):0,ichimokuScore:ich?.score??50,ichimokuBull:!!ich?.bull,ichimokuBear:!!ich?.bear,timeframe:activeTf,timeframeScore:tfChoice.score,timeframeProfile:tfChoice.profile,timeframeRanked:tfChoice.ranked||[],candles:c,...(()=>{const fs=fibonacciStructureContext(c,60);return {fibonacciScore:fs.fibScore,fibonacciLevel:fs.fibLevel,fibonacciPrice:fs.fibPrice,fibonacciPosition:fs.fibPosition,structureScore:fs.structureScore,structureDirection:fs.structureDirection,structureBOS:fs.bos,structureFVG:fs.fvg,structureOrderBlock:fs.orderBlock,structureSwingHigh:fs.swingHigh,structureSwingLow:fs.swingLow,structureCombinedScore:fs.combinedScore};})()});
        applyValidatedAssetProfile(results[results.length-1]);
        const regimeInfo=marketRegime(results[results.length-1]); results[results.length-1].regimeInfo=regimeInfo; results[results.length-1].regime=regimeInfo.regime;
        const mm=results[results.length-1]; const ml=adaptiveMLForMarket(mm); Object.assign(mm,{mlProbability:ml.probability,mlStatus:ml.status,mlAccuracy:ml.accuracy||0,mlOosAccuracy:ml.oosAccuracy||0,mlBaselineAccuracy:ml.baselineAccuracy||0,mlPrecision:ml.precision||0,mlRecall:ml.recall||0,mlBrier:ml.brier||0,mlSamples:ml.samples||0,mlValidationSamples:ml.validationSamples||0,mlDrift:ml.drift,mlFeatures:ml.features||null,mlFeedbackWeight:ml.feedbackWeight||0});
      }catch(error){results.push({pair:item.pair,error:String(error?.message||error)});progressFailures++;}
      finally{completed++;progress();}
    }
  }
  await Promise.all(Array.from({length:Math.min(concurrency,eligible.length)},worker));
  let failures=0;
  results.forEach(m=>{if(m.error){failures++;return;}const old=markets.find(y=>y.symbol===m.symbol);if(old)Object.assign(old,m);else markets.push(m);});
  reviewPositions();
  if(results.length&&failures===results.length)throw new Error(`All ${failures} scanned pair(s) failed to load`);
  if(failures)addLog(`${failures} of ${results.length} scanned pair(s) could not be refreshed.`);
  return {updated:results.length-failures,failed:failures,total:results.length,scanned:eligible.length,skipped};
}
function intervalMs(tf){return ({'1m':60000,'3m':180000,'5m':300000,'15m':900000,'30m':1800000,'1h':3600000,'2h':7200000,'4h':14400000,'6h':21600000,'8h':28800000,'12h':43200000,'1d':86400000,'3d':259200000,'1w':604800000,'1M':2592000000}[tf]||14400000);}

function autoOpenQualified(){const paperAuto=settings.autoTradeMode==='paper'||(settings.autoTradeMode==='off'&&settings.validationMode==='paper'&&settings.autoOpen);if(!paperAuto||!settings.autoTradeArmed||settings.positionMode!=='dynamic')return;const gate=autoTradeRequirements();if(gate.passed<gate.total)return;const safety=safetyStatus();if(safety.lossBreached||safety.exposureBreached)return;const qualified=currentQualifiedOpportunities();let capacity=dynamicPositionCapacity(qualified.length);for(const m of qualified){if(capacity<=0)break;if(positions.some(p=>p.symbol===m.symbol))continue;if(lastEntryAt(m.symbol)&&Date.now()-lastEntryAt(m.symbol)<settings.cooldownMinutes*60000)continue;const oo=opportunityScore(m); const amount=Math.min(balance,dynamicPositionAmount(m,oo),Math.max(0,settings.budget*(settings.maxExposure/100)-currentExposure()));if(amount<10)break;balance-=amount;rollDailyStats();dailyStats.entries++;const openedAt=Date.now(); const exPolicy=oo.strategyPolicyExecution && oo.learnedExecution && typeof oo.learnedExecution==='object'?oo.learnedExecution:null; const ex=exPolicy?{tp:Number(exPolicy.tp||settings.tp),sl:Number(exPolicy.sl||settings.sl),atrStopMultiplier:Number(exPolicy.atrStopMultiplier||2)}:adaptiveExecutionForMarket(m); const pp={coin:m.base,base:m.base,quote:m.quote,symbol:m.symbol,price:m.price*(1+settings.slippage/100),amount,openedAt,aiConsensus:aiConsensus(m,oo).consensus,regime:m.regime,mlProbability:oo.mlProbability,score:oo.score,timeframe:m.timeframe||settings.timeframe||'4h',timeframeScore:m.timeframeScore||0,assetStrategy:oo.assetStrategy||null,assetStrategyVariant:oo.learnedVariant||null,assetParameters:oo.learnedParameters||{},assetExecution:oo.learnedExecution||ex,profileConfidence:Number(oo.assetStrategyConfidence||0),contextPolicyCombo:oo.contextPolicyCombo||'core',contextPolicySelected:oo.contextPolicySelected||['core'],contextFusionSources:oo.contextFusionSources||['core'],strategyPolicyStrategy:oo.strategyPolicyStrategy||oo.assetStrategy||null,strategyPolicyVariant:oo.strategyPolicyVariant||oo.assetStrategyVariant||null,strategyPolicyExecution:oo.strategyPolicyExecution||oo.learnedExecutionVariant||null,fibonacciScore:Number(oo.fibonacciScore||50),structureScore:Number(oo.structureScore||50),structureCombinedScore:Number(oo.structureCombinedScore||50),tpPct:ex.tp,slPct:ex.sl,atrStopMultiplier:ex.atrStopMultiplier}; positions.push(pp); if(settings.validationMode==='paper') recordPaperPosition(pp); capacity--;}persist();}

async function getFreshTickerRows(){
  const now=Date.now();
  if(clientTickerCache.rows.length&&now-clientTickerCache.at<CLIENT_TICKER_TTL)return clientTickerCache.rows;
  try{const r=await apiFetch('/api/tickers',{cache:'no-store',retryAttempts:2});if(r.ok){const d=await r.json();const rows=Array.isArray(d.tickers)?d.tickers:[];if(rows.length){clientTickerCache.at=now;clientTickerCache.rows=rows;return rows;}}}catch{}
  return clientTickerCache.rows;
}
function prepareAutomaticCandidatesFromTickers(tickers){
  if(!settings.autoSelection||!Array.isArray(universeSymbols)||!universeSymbols.length){scanCandidates=[];return null;}
  const quotes=new Set((settings.quoteAssets||[settings.quote||'USDT']).map(x=>String(x).toUpperCase()));
  const max=autoCandidateLimit(universeSymbols.length);
  const byTicker=new Map((tickers||[]).map(t=>[String(t.symbol||'').toUpperCase(),t]));
  const rows=universeSymbols.filter(x=>x&&x.symbol&&quotes.has(String(x.quoteAsset).toUpperCase())).map(x=>{
    const t=byTicker.get(String(x.symbol).toUpperCase());
    const volume=Number(t?.quoteVolume)||Number(x.quoteVolume)||0;
    const change=Math.abs(Number(t?.change)||0);
    const categories=projectCategories(x).length;
    // Liquidity is primary; modest category/volatility bonuses only break ties and never override liquidity materially.
    const score=Math.log10(Math.max(1,volume))*20+categories*3+Math.min(change,20)*0.15;
    return {x,volume,score};
  }).sort((a,b)=>b.volume-a.volume||b.score-a.score);
  scanCandidates=rows.slice(0,max).map(r=>`${r.x.baseAsset}/${r.x.quoteAsset}`);
  scanCandidates.forEach(ensureMarket);
  return scanCandidates;
}
async function scan(){ if(scanInFlight){$('#scanDetail').textContent='A scan is already running — waiting for the current analysis to finish.';return;} scanInFlight=true;$('#scanStatus').textContent='Scanning';$('#scanDetail').textContent=settings.autoSelection?'Ranking Binance Spot liquidity, then running a fast safety-first candidate scan…':'Calculating indicators from live public Spot candles…';try{selectedOpportunities=[];qualifiedOpportunities=[];const tickers=await getFreshTickerRows();const autoCandidates=settings.autoSelection?prepareAutomaticCandidatesFromTickers(tickers):null;const scanPool=settings.autoSelection?(autoCandidates||[]):watchPairs();if(!scanPool.length)throw new Error(settings.autoSelection?'No eligible Binance Spot candidates were produced. Load Binance Spot pairs and check quote/volume filters.':'No Spot pairs are selected');const refresh=await refreshSpotMarket(scanPool,tickers);
    // Personal Watch is intentionally not scanned as part of AUTO. It uses only data already cached
    // by the engine, avoiding a second candle pass and keeping the opportunity universe unbiased.
    let selection=finalizeAutomaticSelection();if(selection.qualifiedCount&&settings.multiTimeframe){await confirmMultiTimeframe(selection.qualifiedOpportunities||selection.selected);selection=finalizeAutomaticSelection();}lastRankedOpportunities=selection.ranked||[]; lastNearMisses=selection.nearMisses||[]; applyExternalEvidenceToRanking(); renderExternalResearch(); renderOpportunityDiagnostics(selection.ranked||[],selection.qualifiedOpportunities?selection.ranked.filter(x=>selection.qualifiedOpportunities.includes(`${x.m.base}/${x.m.quote}`)):[],selection.nearMisses||[]);const analyzedPool=(autoCandidates||watchPairs()).map(normalizePair);const n=selection.qualifiedCount;lastScanStats={universe:universeSymbols.length||watchPairs().length,candidates:analyzedPool.length,analyzed:refresh.scanned-refresh.failed,qualified:n,top:selection.selected.length};autoOpenQualified();render();$('#scanStatus').textContent=selection.selected.length?'Opportunities found':(n?'Qualified setups found':'No qualified opportunity');const topNames=selection.selected.length?` · Top: ${selection.selected.join(', ')}`:''; const bestSnap=researchDecisionSnapshot()[0];$('#scanDetail').textContent=`${refresh.updated}/${refresh.scanned} candidates analyzed${refresh.failed?` · ${refresh.failed} failed`:''}${refresh.skipped?` · ${refresh.skipped} outside scan capacity`:''} · ${selection.qualifiedCount} qualified · ${selection.selected.length} top${topNames} · Top ≤ Qualified · score ≥${settings.minOpportunityScore} · AI ≥${settings.aiConsensusThreshold} · data quality ≥85% · confidence ≥75% · risk ≥68% · R:R ≥1.45.`; const uc=$('#universeAvailableCount'); if(uc) uc.textContent=(universeSymbols.length||watchPairs().length).toLocaleString(); const cc=$('#candidateCount'); if(cc) cc.textContent=lastScanStats.candidates; const ac=$('#analyzedCount'); if(ac) ac.textContent=lastScanStats.analyzed; const qc=$('#qualifiedCount'); if(qc) qc.textContent=lastScanStats.qualified; const tc=$('#topOpportunityCount'); if(tc) tc.textContent=lastScanStats.top; syncOpportunityControls();const tfSummary=[...new Set(markets.filter(m=>scanCandidates.includes(`${m.base}/${m.quote}`)&&m.timeframe).map(m=>m.timeframe))];addLog(`Opportunity scan complete: ${selection.qualifiedCount} qualified, ${selection.selected.length} top Spot opportunities from ${lastScanStats.candidates} candidates. Adaptive TFs: ${tfSummary.join(', ')||'—'}.`);if(settings.validationMode==='shadow'||settings.shadowEnabled){const snap=researchDecisionSnapshot().slice(0,5);captureShadowDecisions(snap);localStorage.setItem('lsai-shadow-last',JSON.stringify({at:Date.now(),items:snap.map(x=>({pair:`${x.m.base}/${x.m.quote}`,decision:x.d.decision,confidence:x.d.confidence,score:x.o.score,ai:x.o.aiConsensus,mtf:x.d.mtf,risk:x.o.riskScore,ml:x.o.mlProbability}))}));} }catch(e){reviewPositions();updatePaperLedger();render();$('#scanStatus').textContent='Scan limited';$('#scanDetail').textContent=`${e.message}. Check the API connection.`;addLog(`Market scan error: ${e.message}`);}finally{scanInFlight=false;}}
function startAutoReview(){if(reviewTimer)clearInterval(reviewTimer);reviewTimer=setInterval(async()=>{if(scanInFlight)return;scanInFlight=true;try{if(settings.autoSelection&&universeSymbols.length){const tickers=await getFreshTickerRows();prepareAutomaticCandidatesFromTickers(tickers);const refresh=await refreshSpotMarket(scanCandidates,tickers);let selection=finalizeAutomaticSelection();if(selection.qualifiedCount&&settings.multiTimeframe){await confirmMultiTimeframe(selection.qualifiedOpportunities||selection.selected);selection=finalizeAutomaticSelection();}lastRankedOpportunities=selection.ranked||[];lastNearMisses=selection.nearMisses||[];lastScanStats={...lastScanStats,candidates:scanCandidates.length,analyzed:refresh.scanned-refresh.failed,qualified:selection.qualifiedCount,top:selection.selected.length};queueUniverseForLearning(universeSymbols.map(x=>`${x.baseAsset}/${x.quoteAsset}`));runHistoricalLearningQueue(1).catch(()=>{});}else if(!settings.autoSelection)await refreshSpotMarket(watchPairs());render();}catch{reviewPositions();render()}finally{scanInFlight=false;}},Math.max(1,settings.reviewInterval)*60000)}
function syncOpportunityControls(){
  const cap=[['maxScanPairsInputVisible','maxScanPairsInput'],['maxOpportunitiesInputVisible','maxOpportunitiesInput'],['scanConcurrencyInputVisible','scanConcurrencyInput']];
  for(const [v,h] of cap){const x=$('#'+v), y=$('#'+h); if(x) x.value='AUTO'; if(y) y.value='auto';}
  const score=$('#minOpportunityScoreInputVisible'); if(score) score.value='AUTO';
  const vol=$('#minQuoteVolumeInputVisible'); if(vol) vol.value='AUTO';
  const auto=$('#autoSelectionInputVisible'); if(auto) auto.value=settings.autoSelection?'true':'false';
  const tag=$('#opportunityModeTag'); if(tag) tag.textContent=settings.autoSelection?'AUTO':'MANUAL';
}
function bindVisibleOpportunityControls(){
  const x=$('#autoSelectionInputVisible'), y=$('#autoSelectionInput');
  if(x&&y)x.addEventListener('change',()=>{y.value=x.value; y.dispatchEvent(new Event('change',{bubbles:true})); syncOpportunityControls();});
}
function fillSettings(){const fields={strategyName:'strategyNameInput',budget:'budgetInput',dealAmount:'dealAmountInput',quote:'quoteInput',positionMode:'positionModeInput',risk:'riskInput',tp:'tpInput',sl:'slInput',holding:'holdingInput',reviewInterval:'reviewIntervalInput',watchlist:'watchlistInput',timeframe:'timeframeInput',minSignalScore:'minSignalScoreInput',dailyLossLimit:'dailyLossLimitInput',maxExposure:'maxExposureInput',cooldownMinutes:'cooldownMinutesInput',slippage:'slippageInput',minQuoteVolume:'minQuoteVolumeInput',maxScanPairs:'maxScanPairsInput',maxProjectPairs:'maxProjectPairsInput',maxOpportunities:'maxOpportunitiesInput',tradeCycleMode:'tradeCycleModeInput',trendCycleTarget:'trendCycleTargetInput',trendCyclePartial:'trendCyclePartialInput',trendCycleReentryScore:'trendCycleReentryScoreInput',trendCycleMaxCycles:'trendCycleMaxCyclesInput',trendCycleTrail:'trendCycleTrailInput',minOpportunityScore:'minOpportunityScoreInput',scanConcurrency:'scanConcurrencyInput',aiConsensusThreshold:'aiConsensusThresholdInput'};for(const [k,id] of Object.entries(fields)){const el=$('#'+id);if(!el)continue;el.value=(k==='maxScanPairs'||k==='maxProjectPairs'||k==='maxOpportunities'||k==='scanConcurrency')&&String(settings[k]).toLowerCase()==='auto'?'AUTO':settings[k];}const tfm=$('#timeframeModeInput');if(tfm)tfm.value=settings.timeframeMode||'auto';const qa=$('#quoteAssetsInput');if(qa){const enabled=new Set(settings.quoteAssets||[settings.quote||'USDT']);[...qa.options].forEach(o=>o.selected=enabled.has(o.value));}$('#autoOpenInput').value=String(settings.autoOpen);const atm=$('#autoTradeModeInput');if(atm)atm.value=settings.autoTradeMode||'off';const ata=$('#autoTradeArmedInput');if(ata)ata.checked=settings.autoTradeArmed===true;const mtf=$('#multiTimeframeInput');if(mtf)mtf.checked=settings.multiTimeframe!==false;const ens=$('#strategyEnsembleInput');if(ens)ens.checked=settings.strategyEnsemble!==false;const ema=$('#ensembleMinAgreementInput');if(ema)ema.value=settings.ensembleMinAgreement||2;const vm=$('#validationModeInput');if(vm)vm.value=settings.validationMode||'simulation';const ctf=$('#confirmationTimeframesInput');if(ctf){const enabled=new Set(settings.confirmationTimeframes||[]);[...ctf.options].forEach(o=>o.selected=enabled.has(o.value));}const i=settings.indicators;for(const [name,cfg] of Object.entries(i)){const enabled=$(`#${name}Enabled`);if(enabled)enabled.checked=cfg.enabled;for(const key of Object.keys(cfg).filter(k=>k!=='enabled')){const el=$(`#${name}${key[0].toUpperCase()+key.slice(1)}`);if(el)el.value=cfg[key];}}} fillUniverseSettings();renderPairList();
function readSettings(){const num=id=>Number($('#'+id).value);settings={...settings,tradeCycleMode:$('#tradeCycleModeInput')?.value||'auto',trendCycleTarget:Math.max(0.2,Math.min(5,num('trendCycleTargetInput')||0.8)),trendCyclePartial:Math.max(10,Math.min(90,num('trendCyclePartialInput')||30)),trendCycleReentryScore:Math.max(60,Math.min(95,num('trendCycleReentryScoreInput')||72)),trendCycleMaxCycles:Math.max(1,Math.min(10,num('trendCycleMaxCyclesInput')||4)),trendCycleTrail:Math.max(0.2,Math.min(5,num('trendCycleTrailInput')||0.7)),strategyName:$('#strategyNameInput').value.trim()||'Custom Strategy',budget:num('budgetInput'),dealAmount:Math.max(10,num('dealAmountInput')||100),quote:$('#quoteInput').value,quoteAssets:[...new Set([$('#quoteInput').value,...[...document.querySelectorAll('#quoteAssetsInput option:checked')].map(x=>x.value)])],positionMode:$('#positionModeInput').value,risk:num('riskInput'),tp:num('tpInput'),sl:num('slInput'),holding:'auto',reviewInterval:num('reviewIntervalInput'),autoOpen:$('#autoOpenInput').value==='true',autoTradeMode:$('#autoTradeModeInput')?.value||'off',autoTradeArmed:$('#autoTradeArmedInput')?.checked===true,watchlist:(()=>{const v=$('#watchlistInput').value.split(',').map(normalizePair).filter(Boolean).join(', ');return v||settings.watchlist||DEFAULT.watchlist;})(),timeframe:$('#timeframeInput').value,timeframeMode:$('#timeframeModeInput')?.value||'auto',multiTimeframe:$('#multiTimeframeInput')?.checked!==false,confirmationTimeframes:[...new Set([...document.querySelectorAll('#confirmationTimeframesInput option:checked')].map(x=>x.value))],minSignalScore:num('minSignalScoreInput'),dailyLossLimit:num('dailyLossLimitInput'),maxExposure:num('maxExposureInput'),cooldownMinutes:num('cooldownMinutesInput'),slippage:num('slippageInput'),minQuoteVolume:Math.max(0,num('minQuoteVolumeInput')),maxScanPairs:(String($('#maxScanPairsInput').value).trim().toLowerCase()==='auto'||!String($('#maxScanPairsInput').value).trim())?'auto':Math.max(10,Math.min(200,num('maxScanPairsInput'))),maxProjectPairs:(String($('#maxProjectPairsInput').value).trim().toLowerCase()==='auto'||!String($('#maxProjectPairsInput').value).trim())?'auto':Math.max(5,Math.min(1000000,num('maxProjectPairsInput'))),maxOpportunities:(String($('#maxOpportunitiesInput').value).trim().toLowerCase()==='auto'||!String($('#maxOpportunitiesInput').value).trim())?'auto':Math.max(5,Math.min(100,num('maxOpportunitiesInput'))),minOpportunityScore:Math.max(40,Math.min(95,num('minOpportunityScoreInput'))),scanConcurrency:(String($('#scanConcurrencyInput').value).trim().toLowerCase()==='auto'||!String($('#scanConcurrencyInput').value).trim())?'auto':Math.max(1,Math.min(10,num('scanConcurrencyInput'))),aiConsensusThreshold:Math.max(40,Math.min(95,num('aiConsensusThresholdInput'))),autoSelection:$('#autoSelectionInput').value==='true',strategyEnsemble:$('#strategyEnsembleInput')?.checked!==false,ensembleMinAgreement:Math.max(1,Math.min(2,num('ensembleMinAgreementInput')||2)),validationMode:$('#validationModeInput')?.value||'simulation',indicators:{
  utbot:{enabled:$('#utbotEnabled').checked,keyValue:num('utbotKeyValue'),atrPeriod:num('utbotAtrPeriod'),source:$('#utbotSource').value},
  rsi:{enabled:$('#rsiEnabled').checked,period:num('rsiPeriod'),threshold:num('rsiThreshold')},
  ema:{enabled:$('#emaEnabled').checked,period:num('emaPeriod')},
  macd:{enabled:$('#macdEnabled').checked,fast:num('macdFast'),slow:num('macdSlow'),signal:num('macdSignal')},
  fractals:{enabled:$('#fractalsEnabled').checked,lookback:num('fractalsLookback')},
  volume:{enabled:$('#volumeEnabled').checked,multiplier:num('volumeMultiplier')},
  atr:{enabled:$('#atrEnabled').checked,period:num('atrPeriod'),stopMultiplier:num('atrStopMultiplier')},
  adx:{enabled:$('#adxEnabled').checked,period:num('adxPeriod'),min:num('adxMin')},
  bollinger:{enabled:$('#bollingerEnabled').checked,period:num('bollingerPeriod'),multiplier:num('bollingerMultiplier')},
  ichimoku:{enabled:$('#ichimokuEnabled').checked,conversion:num('ichimokuConversion'),base:num('ichimokuBase'),spanB:num('ichimokuSpanB'),displacement:num('ichimokuDisplacement')}
}};readUniverseSettings();}

const UNIVERSE_SEEDS={
  stable:new Set(['USDC','FDUSD','DAI','TUSD','USDP','USDS','PYUSD','EURC','USDE','USD1']),
  ai:new Set(['FET','ASI','AGIX','OCEAN','RENDER','TAO','NEAR','ICP','AKT','GRT','ARKM','IO','AIOZ','WLD','VIRTUAL','Bittensor'.toUpperCase(),'NMR']),
  l1:new Set(['BTC','ETH','BNB','SOL','ADA','AVAX','DOT','ATOM','TRX','TON','NEAR','ICP','SUI','APT','SEI','XLM','XRP','ALGO','HBAR','ETC']),
  l2:new Set(['ARB','OP','STRK','ZK','MANTA','IMX','METIS','ZRO','MNT','POL']),
  defi:new Set(['UNI','AAVE','MKR','LDO','CRV','COMP','SNX','SUSHI','DYDX','1INCH','CAKE','JUP','RAY','ENA','PENDLE']),
  depin:new Set(['RNDR','RENDER','FIL','AR','HNT','AKT','THETA','IOTX','STORJ','GRASS','TAO']),
  rwa:new Set(['ONDO','MKR','CFG','POLYX','OM','RIO','GFI','TRU','PROPS']),
  gaming:new Set(['IMX','SAND','MANA','AXS','GALA','RON','BEAM','PIXEL','MAGIC','ILV','ENJ']),
  infra:new Set(['LINK','GRT','PYTH','API3','TIA','FIL','AR','QNT','THETA','LPT','DYM']),
  payments:new Set(['XRP','XLM','LTC','BCH','XMR','DASH','DOGE','CELO','ALGO'])
};
let universeSymbols=[];
let lastRankedOpportunities=[];
let lastNearMisses=[];
let signalFilter='all';
function escapeHTML(value){return String(value??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\"/g,'&quot;').replace(/'/g,'&#39;');}
// v7.33.2 external research bridges: TradingView + cTrader are evidence sources only.
const TV_STORE_KEY='lsai-tradingview-evidence-v1';
const CT_STORE_KEY='lsai-ctrader-challengers-v1';
let tradingViewEvidence=[];
let cTraderChallengers=[];
try{tradingViewEvidence=JSON.parse(localStorage.getItem(TV_STORE_KEY)||'[]');if(!Array.isArray(tradingViewEvidence))tradingViewEvidence=[];}catch{tradingViewEvidence=[];}
try{cTraderChallengers=JSON.parse(localStorage.getItem(CT_STORE_KEY)||'[]');if(!Array.isArray(cTraderChallengers))cTraderChallengers=[];}catch{cTraderChallengers=[];}
function persistExternalResearch(){try{localStorage.setItem(TV_STORE_KEY,JSON.stringify(tradingViewEvidence.slice(-100)));localStorage.setItem(CT_STORE_KEY,JSON.stringify(cTraderChallengers.slice(-100)));}catch{}}
const UNIVERSAL_EVIDENCE_KEY='lsai-universal-evidence-v1';
function universalEvidenceLedger(){try{const x=JSON.parse(localStorage.getItem(UNIVERSAL_EVIDENCE_KEY)||'[]');return Array.isArray(x)?x:[]}catch{return []}}
function saveUniversalEvidence(x){try{localStorage.setItem(UNIVERSAL_EVIDENCE_KEY,JSON.stringify(x.slice(-1000)))}catch{}}
function ingestUniversalEvidence(source,payload,meta={}){const ledger=universalEvidenceLedger();const symbol=normalizeExternalSymbol(payload?.symbol||payload?.ticker||payload?.pair)||null;const event={id:`ue-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,source:String(source||'unknown'),symbol,receivedAt:Date.now(),kind:meta.kind||'evidence',confidence:Number(payload?.confidence??payload?.score??50)||50,score:Number(payload?.score??payload?.confidence??50)||50,hasOutcome:Number.isFinite(Number(payload?.realizedPct))||Number.isFinite(Number(payload?.pnl))||Number.isFinite(Number(payload?.profit)),payload};ledger.push(event);saveUniversalEvidence(ledger);return event;}
function universalEvidenceSummary(){const l=universalEvidenceLedger();const by={};for(const x of l)by[x.source]=(by[x.source]||0)+1;return {total:l.length,by,last:l[l.length-1]||null,outcomes:l.filter(x=>x.hasOutcome).length};}

function normalizeExternalSymbol(v){let x=String(v||'').toUpperCase().replace(/[^A-Z0-9]/g,'');if(x.endsWith('USDT'))return x; if(x) return x+'USDT'; return null;}
function parseJsonInput(id){const raw=String($(id)?.value||'').trim();if(!raw)throw new Error('لا توجد إشارة مستوردة. ألصق JSON في الحقل أو أرسل TradingView Webhook إلى بوابة الاستقبال.');let d;try{d=JSON.parse(raw);}catch(e){throw new Error('JSON غير صالح');}if(!d||typeof d!=='object')throw new Error('البيانات يجب أن تكون JSON object');return d;}
function importTradingViewEvidence(){try{const d=parseJsonInput('#tvSignalInput');const symbol=normalizeExternalSymbol(d.symbol||d.ticker||d.pair);if(!symbol)throw new Error('رمز TradingView غير موجود');const action=String(d.action||d.signal||d.direction||'watch').toLowerCase();const score=clamp(Number(d.score??d.confidence??d.rating??50)||50,0,100);const confidence=clamp(Number(d.confidence??d.score??50)||50,0,100);const ue=ingestUniversalEvidence('TradingView',d,{kind:'manual'});tradingViewEvidence.push({id:`tv-${Date.now()}`,symbol,action,score,confidence,timeframe:String(d.timeframe||settings.timeframe||'4h'),strategy:String(d.strategy||'TradingView/Pine'),regime:String(d.regime||d.marketRegime||'ALL'),source:'TradingView',at:Date.now(),raw:{symbol,action,score,confidence,timeframe:String(d.timeframe||'4h'),strategy:String(d.strategy||'TradingView/Pine'),regime:String(d.regime||d.marketRegime||'ALL')}});persistExternalResearch();$('#tvSignalInput').value='';renderExternalResearch();addLog(`TradingView evidence imported: ${symbol} · ${action} · score ${Math.round(score)}. It will be used as external evidence, not as an order.`);}catch(e){const el=$('#tvBridgeStatus');if(el)el.textContent=`ERROR · ${e.message}`;}}
function cTraderLearningStore(){try{return JSON.parse(localStorage.getItem('lsai-ctrader-learning-v1')||'{}')}catch{return {}}}
function saveCTraderLearningStore(x){try{localStorage.setItem('lsai-ctrader-learning-v1',JSON.stringify(x))}catch{}}
function learnFromCTraderPayload(d,record){const st=cTraderLearningStore(),key=`${record.symbol}|${record.timeframe}|${record.strategy}`;const trades=Array.isArray(d.trades)?d.trades:(Array.isArray(d.history)?d.history:[]);const wins=trades.filter(t=>Number(t.profit??t.pnl??t.return??0)>0);const losses=trades.filter(t=>Number(t.profit??t.pnl??t.return??0)<0);const patterns=wins.slice(0,500).map(t=>({entryRegime:t.entryRegime||t.regime||null,timeframe:t.timeframe||record.timeframe,strategy:t.strategy||record.strategy,entry:t.entry??t.entryPrice??null,exit:t.exit??t.exitPrice??null,profit:Number(t.profit??t.pnl??t.return??0)||0,rr:Number(t.rewardRisk??t.rr??0)||0,indicators:t.indicators||t.features||{},params:t.parameters||t.params||{}}));st[key]={symbol:record.symbol,timeframe:record.timeframe,strategy:record.strategy,trades:record.trades,winRate:record.winRate,profitFactor:record.profitFactor,maxDrawdown:record.maxDrawdown,expectancy:record.expectancy,successfulTrades:wins.length,failedTrades:losses.length,patterns,source:'cTrader historical learning',updatedAt:Date.now(),confidence:clamp(record.trades>=50?record.winRate*.7+Math.min(100,record.profitFactor*50)*.3:record.winRate*.5,0,100)};saveCTraderLearningStore(st);return st[key]}
function importCTraderResult(){try{const d=parseJsonInput('#ctSignalInput');const symbol=normalizeExternalSymbol(d.symbol||d.ticker||d.pair);if(!symbol)throw new Error('رمز cTrader غير موجود');const trades=Math.max(0,Number(d.trades||d.closedTrades||0)||0),winRate=clamp(Number(d.winRate??d.winrate??0)||0,0,100),pf=Math.max(0,Number(d.profitFactor??d.pf??0)||0),dd=Math.max(0,Number(d.maxDrawdown??d.drawdown??0)||0),expectancy=Number(d.expectancy||0)||0;const rec={id:`ct-${Date.now()}`,symbol,timeframe:String(d.timeframe||'4h'),strategy:String(d.strategy||d.name||'cBot'),regime:String(d.regime||d.marketRegime||'ALL'),trades,winRate,profitFactor:pf,maxDrawdown:dd,expectancy,source:'cTrader',at:Date.now()};cTraderChallengers.push(rec);ingestUniversalEvidence('cTrader',d,{kind:'manual'});const learned=learnFromCTraderPayload(d,rec);persistExternalResearch();$('#ctSignalInput').value='';renderExternalResearch();addLog(`cTrader imported + historical learning: ${symbol} · ${rec.strategy} · ${trades} trades · ${winRate.toFixed(1)}% win · learned ${learned.successfulTrades} successful patterns. Full LOODY’S validation remains mandatory.`);}catch(e){const el=$('#ctBridgeStatus');if(el)el.textContent=`ERROR · ${e.message}`;}}
function cTraderLearningSummary(){const st=cTraderLearningStore(),rows=Object.values(st);return {profiles:rows.length,successful:rows.reduce((a,x)=>a+Number(x.successfulTrades||0),0),patterns:rows.reduce((a,x)=>a+(x.patterns?.length||0),0)} }
function latestExternalTV(symbol){const rows=tradingViewEvidence.filter(x=>x.symbol===normalizeExternalSymbol(symbol)).sort((a,b)=>b.at-a.at);return rows[0]||null;}
function externalTVScore(m){const e=latestExternalTV(m?.symbol);if(!e)return null;const ageHours=(Date.now()-e.at)/3600000;const freshness=Math.max(0,100-Math.min(100,ageHours*8));const action=(e.action||'').toLowerCase();const directional=(action==='buy'||action==='long')?100:(action==='sell'||action==='short')?0:50;return Math.round(clamp(e.score*.45+e.confidence*.25+freshness*.15+directional*.15,0,100));}
function externalAdjudicationForMarket(m){const tv=latestExternalTV(m?.symbol);if(!tv)return {tv:null,tvScore:null,boost:0,label:'NO EXTERNAL EVIDENCE'};const score=externalTVScore(m);const d=researchDecisionSnapshot().find(x=>x.m.symbol===m.symbol);const engine=d?.d?.confidence??50;const agreement=score>=68&&engine>=75?100:score>=68&&engine>=60?70:score<45&&engine<60?30:50;return {tv,tvScore:score,engineConfidence:engine,agreement,boost:score>=75&&agreement>=70?2:0,label:score>=75&&agreement>=70?'ALIGNED':'REVIEW'};}
function challengerScore(x){return clamp(x.winRate*.35+Math.min(100,x.profitFactor*50)*.25+Math.max(0,100-x.maxDrawdown*4)*.2+clamp(50+x.expectancy*50,0,100)*.2,0,100);}
async function syncExternalBridgeFeeds(){
  const feeds=[['/api/integrations/tradingview','tv'],['/api/integrations/ctrader','ct']];
  for(const [path,type] of feeds){try{
    const r=await apiFetch(`${path}?history=1`,{cache:'no-store',retryAttempts:1});if(!r.ok)continue;
    const d=await r.json();const records=Array.isArray(d.records)?d.records:[];
    for(const item of records){const body=item?.data||{};const symbol=normalizeExternalSymbol(item?.symbol||body.symbol||body.ticker||body.pair);if(!symbol)continue;const marker=Number(item?.receivedAt||0);
      if(type==='tv'){
        if(!tradingViewEvidence.some(x=>x.bridgeReceivedAt===marker&&x.symbol===symbol)){tradingViewEvidence.push({id:`tv-bridge-${marker}`,bridgeReceivedAt:marker,symbol,action:String(body.action||body.signal||body.direction||'watch').toLowerCase(),score:clamp(Number(body.score??body.confidence??50)||50,0,100),confidence:clamp(Number(body.confidence??body.score??50)||50,0,100),timeframe:String(body.timeframe||'4h'),strategy:String(body.strategy||'TradingView/Pine'),source:'TradingView Webhook',at:marker||Date.now(),raw:body});ingestUniversalEvidence('TradingView Webhook',body,{kind:'webhook'});}
      }else{
        if(!cTraderChallengers.some(x=>x.bridgeReceivedAt===marker&&x.symbol===symbol)){const rec={id:`ct-bridge-${marker}`,bridgeReceivedAt:marker,symbol,timeframe:String(body.timeframe||'4h'),strategy:String(body.strategy||body.name||'cBot'),regime:String(body.regime||body.marketRegime||'ALL'),trades:Number(body.trades||body.closedTrades||0)||0,winRate:Number(body.winRate??body.winrate??0)||0,profitFactor:Number(body.profitFactor??body.pf??0)||0,maxDrawdown:Number(body.maxDrawdown??body.drawdown??0)||0,expectancy:Number(body.expectancy||0)||0,source:'cTrader Bridge',at:marker||Date.now()};cTraderChallengers.push(rec);try{if(Array.isArray(body.trades)||Array.isArray(body.history))learnFromCTraderPayload(body,rec)}catch{}ingestUniversalEvidence('cTrader Bridge',body,{kind:'webhook'});}
      }
    }
    persistExternalResearch();renderUniversalEvidencePanel();renderEvidenceIntelligencePanel();
  }catch{}}
  tradingViewEvidence=tradingViewEvidence.slice(-200);cTraderChallengers=cTraderChallengers.slice(-200);
  renderExternalResearch();
}
function renderEvidenceIntelligencePanel(){
  const mount=document.querySelector('#bgEvidenceMount .background-mount');
  if(!mount)return;
  let box=$('#evidenceIntelligencePanel');
  if(!box){box=document.createElement('section');box.id='evidenceIntelligencePanel';box.className='panel evidence-intelligence-panel';mount.appendChild(box);}
  const rows=evidenceIntelligenceSnapshot();
  const contexts=Object.values(evidenceIntel().contexts||{}).sort((a,b)=>Number(b.resolved||0)-Number(a.resolved||0)).slice(0,8);
  const contextHtml=contexts.map(x=>`<article><span>${escapeHTML(x.symbol)} · ${escapeHTML(x.timeframe)} · ${escapeHTML(x.strategy)}</span><strong>${x.resolved?Number(x.accuracy).toFixed(1)+'%':'NEUTRAL'}</strong><small>${x.resolved} resolved · reliability ×${evidenceContextReliability(x.source,x).toFixed(2)}</small></article>`).join('');
  const html=rows.map(x=>`<article><span>${escapeHTML(x.source)}</span><strong>${x.resolved?x.accuracy.toFixed(1)+'%':'NEUTRAL'}</strong><small>${x.seen} observations · reliability ×${x.reliability.toFixed(2)}</small></article>`).join('');
  const m=lastRankedOpportunities[0], ci=m?evidenceConflictForMarket(m,m):null, fusion=m?contextFusion(m,m):null;
  const conflicts=evidenceConflictLedger().slice(-8).reverse();
  const conflictHtml=conflicts.map(x=>`<article><span>${escapeHTML(x.symbol)} · ${escapeHTML(x.timeframe||'AUTO')}</span><strong>${escapeHTML(x.resolution||'LEARNING')}</strong><small>conflict ${x.conflict}/100 · ${escapeHTML(x.resolvedBy||'weighted evidence')}</small></article>`).join('');
  box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">EVIDENCE INTELLIGENCE ENGINE</p><h2>جودة المصادر والتعارض</h2><p class="muted">تحليل مستقل للأدلة خارج الشاشة الرئيسية. يتعلم من النتائج الصريحة، ويراقب التعارض، ويُعدّل التأثير ضمن حدود آمنة فقط.</p></div><span class="tag">ADAPTIVE</span></div><div class="performance-results">${html}</div><h3>سمعة السياق: الأصل + الإطار الزمني + الاستراتيجية</h3><div class="performance-results">${contextHtml||'<article><span>لا توجد نتائج سياقية كافية بعد</span><strong>LEARNING</strong><small>يلزم 5 نتائج محسومة على الأقل لكل سياق.</small></article>'}</div><div class="validation-row"><strong>Conflict monitor</strong><span>${ci?`Top ${escapeHTML(m.symbol)} · conflict ${ci.score}/100 · agreements ${ci.agreements}`:'لا توجد فرصة حالية للمقارنة'}</span></div><div class="validation-row"><strong>Context Fusion</strong><span>${fusion?`score ${fusion.score}/100 · confidence ${fusion.confidence}/100 · sources ${fusion.selected.join(', ')||'core only'} · agreement ${fusion.agreement}%`:'لا توجد فرصة حالية للدمج'}</span></div><h3>سجل حل التعارض</h3><div class="performance-results">${conflictHtml||'<article><span>لا توجد تعارضات محسومة</span><strong>READY</strong><small>سيتم تسجيل التعارضات عند توفر مصادر متعارضة.</small></article>'}</div>`;
}
function evidenceConflictLedger(){try{const x=JSON.parse(localStorage.getItem('lsai-evidence-conflict-v1')||'[]');return Array.isArray(x)?x:[]}catch{return []}}
function saveEvidenceConflictLedger(x){try{localStorage.setItem('lsai-evidence-conflict-v1',JSON.stringify(x.slice(-300)))}catch{}}
function resolveEvidenceConflict(m,o){
  const ci=evidenceConflictForMarket(m,o); if(!ci||ci.score<20)return null;
  const f=contextFusion(m,o); const direction=f.dominant||ci.coreDirection||0;
  const resolution=direction>0?'CORE/FUSION BULLISH':direction<0?'CORE/FUSION BEARISH':'ABSTAIN — NO DOMINANT EVIDENCE';
  const entry={symbol:m?.symbol||o?.symbol||'UNKNOWN',timeframe:m?.timeframe||o?.timeframe||'AUTO',strategy:o?.assetStrategy||o?.strategy||'ALL',conflict:ci.score,agreements:ci.agreements,resolvedBy:resolution,at:Date.now()};
  const ledger=evidenceConflictLedger(); const key=`${entry.symbol}|${entry.timeframe}|${entry.strategy}|${Math.floor(entry.at/300000)}`; if(!ledger.some(x=>x.key===key)){entry.key=key;ledger.push(entry);saveEvidenceConflictLedger(ledger)}
  return entry;
}
function renderUniversalEvidencePanel(){const s=universalEvidenceSummary();const el=$('#universalEvidenceSummary');if(!el)return;const rows=Object.entries(s.by).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`<article><span>${escapeHTML(k)}</span><strong>${v}</strong><small>evidence events</small></article>`).join('');el.innerHTML=`<article><span>Total evidence</span><strong>${s.total}</strong><small>unified ledger</small></article><article><span>Resolved outcomes</span><strong>${s.outcomes}</strong><small>only explicit outcomes count</small></article>${rows||'<article><span>Status</span><strong>WAITING</strong><small>No external evidence yet</small></article>'}`;const st=$('#universalEvidenceStatus');if(st)st.textContent=s.total?'ACTIVE · '+s.total+' EVENTS':'WAITING FOR FEEDS';}

function renderExternalResearch(){
  renderUniversalEvidencePanel();
  const tvRows=$('#tvSignalRows');if(tvRows){tvRows.innerHTML=tradingViewEvidence.slice().sort((a,b)=>b.at-a.at).slice(0,50).map(x=>{const m=markets.find(q=>q.symbol===x.symbol);const ev=m?externalAdjudicationForMarket(m):{tvScore:x.score,agreement:'—',label:'WAITING MARKET'};const age=Math.max(0,(Date.now()-x.at)/3600000);return `<tr><td>${escapeHTML(x.symbol)}</td><td>${escapeHTML(x.action)}</td><td>${escapeHTML(x.timeframe)}</td><td>${Math.round(x.score)}</td><td>${Math.round(x.confidence)}</td><td>${age<1?Math.round(age*60)+'m':Math.round(age)+'h'}</td><td>${escapeHTML(ev.label)} · ${ev.tvScore??Math.round(x.score)}/100</td></tr>`;}).join('')||'<tr><td colspan="7">No TradingView evidence imported yet.</td></tr>';}
  const tc=$('#tvSignalCount');if(tc)tc.textContent=tradingViewEvidence.length;const currentTV=lastRankedOpportunities.map(x=>externalTVScore(x)).filter(x=>x!=null);const te=$('#tvEvidenceScore');if(te)te.textContent=currentTV.length?Math.round(currentTV.reduce((a,b)=>a+b,0)/currentTV.length):'—';const ta=$('#tvAgreement');if(ta){const vals=lastRankedOpportunities.map(m=>externalAdjudicationForMarket(m).agreement).filter(x=>typeof x==='number');ta.textContent=vals.length?Math.round(vals.reduce((a,b)=>a+b,0)/vals.length)+'/100':'—';}
  const ctRows=$('#ctSignalRows');if(ctRows){ctRows.innerHTML=cTraderChallengers.slice().sort((a,b)=>challengerScore(b)-challengerScore(a)).slice(0,50).map(x=>{const s=challengerScore(x);const pass=x.trades>=20&&x.winRate>=50&&x.profitFactor>=1.2&&x.maxDrawdown<=20;return `<tr><td>${escapeHTML(x.symbol)}</td><td>${escapeHTML(x.strategy)}</td><td>${escapeHTML(x.timeframe)}</td><td>${x.trades}</td><td>${Number(x.winRate).toFixed(1)}</td><td>${Number(x.profitFactor).toFixed(2)}</td><td>${Number(x.maxDrawdown).toFixed(1)}</td><td>${pass?'CANDIDATE · '+Math.round(s):'RESEARCH ONLY'}</td></tr>`;}).join('')||'<tr><td colspan="8">No cTrader challenger results imported yet.</td></tr>';}
  const cc=$('#ctSignalCount');if(cc)cc.textContent=cTraderChallengers.length;const pf=$('#ctBestPF');if(pf)pf.textContent=cTraderChallengers.length?Math.max(...cTraderChallengers.map(x=>Number(x.profitFactor)||0)).toFixed(2):'—';const dd=$('#ctBestDD');if(dd)dd.textContent=cTraderChallengers.length?Math.min(...cTraderChallengers.map(x=>Number(x.maxDrawdown)||0)).toFixed(1)+'%':'—';
}

function applyExternalEvidenceToRanking(){
  if(!lastRankedOpportunities.length)return;
  lastRankedOpportunities.forEach(m=>{const e=externalAdjudicationForMarket(m);m.externalResearch=m.externalResearch||{};m.externalResearch.tradingView=e;if(e.boost)m.score=clamp(Number(m.score||0)+e.boost,0,100);});
  lastRankedOpportunities.sort((a,b)=>Number(b.score||0)-Number(a.score||0));
}

function isSpotUniverseSymbol(x){if(!x||x.status!=='TRADING')return false;if(Array.isArray(x.permissionSets)&&x.permissionSets.length)return x.permissionSets.some(set=>Array.isArray(set)&&set.includes('SPOT'));return x.isSpotTradingAllowed!==false;}
function universeEnabled(){return {stable:$('#universeStable')?.checked,ai:$('#universeAI')?.checked,l1:$('#universeL1')?.checked,l2:$('#universeL2')?.checked,defi:$('#universeDeFi')?.checked,depin:$('#universeDePIN')?.checked,rwa:$('#universeRWA')?.checked,gaming:$('#universeGaming')?.checked,infra:$('#universeInfra')?.checked,payments:$('#universePayments')?.checked,meme:$('#universeMeme')?.checked};}
function classifyAsset(base,quote){const cats=[];const e=universeEnabled();if(e.stable&&UNIVERSE_SEEDS.stable.has(base))cats.push('Stable');for(const k of ['ai','l1','l2','defi','depin','rwa','gaming','infra','payments'])if(e[k]&&UNIVERSE_SEEDS[k].has(base))cats.push(k.toUpperCase());if(e.meme&&['DOGE','SHIB','PEPE','BONK','FLOKI','WIF','MEME','BRETT','MOG','BABYDOGE'].includes(base))cats.push('MEME');if(e.stable&&['USDT','USDC','FDUSD','DAI','USDS','TUSD','USDE','USDP','PYUSD'].includes(quote))cats.push('STABLE-QUOTE');return [...new Set(cats)];}
function renderUniverse(list){
  const box=$('#universeList');if(!box)return;
  const q=String($('#universeSearch')?.value||'').trim().toUpperCase();
  const filtered=q?list.filter(x=>`${x.baseAsset}/${x.quoteAsset}`.includes(q)||x.baseAsset.includes(q)||x.quoteAsset.includes(q)):list;
  const selected=new Set(watchPairs()); const projectSet=new Set(autoProjectPairs);
  const visible=filtered.slice(0,200);
  box.innerHTML=visible.map(x=>{const pair=`${x.baseAsset}/${x.quoteAsset}`;const on=selected.has(pair),inProject=projectSet.has(pair);return `<span class="universe-chip pair-option ${on?'selected':''}"><strong>${pair}</strong><small>$${x.quoteVolume?Number(x.quoteVolume).toLocaleString():'—'} · ${x.categories.length?x.categories.join(' · '):'Spot'}${inProject?' · AUTO PROJECT':''}</small><button type="button" class="pair-add" data-add-pair="${pair}">${on?'Manual':'Add manual'}</button></span>`}).join('')||'<span class="meta">No Binance Spot pairs match the current filter.</span>';
  const count=$('#universeAvailableCount');if(count)count.textContent=list.length.toLocaleString();
  const uc=$('#universeCount');if(uc)uc.textContent=`${filtered.length.toLocaleString()} matches · showing ${visible.length.toLocaleString()}`; const pc=$('#projectPoolCount'); if(pc)pc.textContent=`AUTO Project Pool: ${autoProjectPairs.length.toLocaleString()}`;
}
function projectCategories(x){return (x?.categories||[]).filter(c=>c!=='STABLE-QUOTE');}
function projectPairsFromUniverse(list){
  const quotes=new Set((settings.quoteAssets||[settings.quote||'USDT']).map(x=>String(x).toUpperCase()));
  const max=String(settings.maxProjectPairs).toLowerCase()==='auto'?Infinity:Math.max(5,Math.min(1000000,Number(settings.maxProjectPairs)||50));
  return list.filter(x=>projectCategories(x).length>0&&quotes.has(String(x.quoteAsset).toUpperCase()))
    .sort((a,b)=>(projectCategories(b).length-projectCategories(a).length)||((Number(b.quoteVolume)||0)-(Number(a.quoteVolume)||0)))
    .slice(0,max).map(x=>`${x.baseAsset}/${x.quoteAsset}`);
}
function engineQualified(m,o){
  const cp=controlPolicy||CONTROL_DEFAULT;
  const scoreFloor=Math.max(68,Number(cp.scoreFloor)||68,Number(settings.minOpportunityScore)||68);
  const aiFloor=Math.max(68,Number(cp.aiFloor)||68,Number(settings.aiConsensusThreshold)||68);
  const confFloor=Math.max(75,Number(cp.confidenceFloor)||75);
  const riskFloor=Math.max(68,Number(cp.riskFloor)||68);
  const rrFloor=Math.max(1.45,Number(cp.rrFloor)||1.45);
  const uncertaintyMax=Math.min(42,Math.max(15,Number(cp.maxUncertainty)||42));
  const abstainBlocked=cp.strictAbstention!==false && o.abstain;
  return !!m && Number(m.price)>0 && !abstainBlocked && o.score>=scoreFloor && o.aiConsensus>=aiFloor &&
    Number(m.dataQuality??100)>=85 && Number(o.decisionConfidence||0)>=confFloor &&
    Number(o.strategyVotes||0)>=settings.ensembleMinAgreement && Number(o.riskScore||0)>=riskFloor && Number(o.rewardRisk||0)>=rrFloor &&
    Number(o.metaScore||0)>=70 && Number(o.uncertainty||100)<=uncertaintyMax;
}
function autoCandidatePairs(list){
  const quotes=new Set((settings.quoteAssets||[settings.quote||'USDT']).map(x=>String(x).toUpperCase()));
  const minVol=Math.max(0,Number(settings.minQuoteVolume)||0);
  const max=String(settings.maxScanPairs).toLowerCase()==='auto'?autoCandidateLimit(universeSymbols.length):Math.max(10,Math.min(200,Number(settings.maxScanPairs)||60));
  const bySymbol=new Map(list.map(x=>[x.symbol,x]));
  const explicit=autoProjectPairs.map(normalizePair).map(pair=>bySymbol.get(pairParts(pair).symbol)).filter(Boolean);
  const project=list.filter(x=>projectCategories(x).length>0&&quotes.has(String(x.quoteAsset).toUpperCase()));
  const broad=list.filter(x=>quotes.has(String(x.quoteAsset).toUpperCase()));
  const pool=[...new Map([...explicit,...project,...broad].map(x=>[x.symbol,x])).values()];
  // Liquidity is a preference, not a hard wall: fill the configured candidate pool
  // from the complete Spot universe when the preferred volume threshold is too strict.
  const preferred=pool.filter(x=>Number(x.quoteVolume||0)>=minVol).sort((a,b)=>Number(b.quoteVolume||0)-Number(a.quoteVolume||0));
  const fallback=pool.filter(x=>Number(x.quoteVolume||0)<minVol).sort((a,b)=>Number(b.quoteVolume||0)-Number(a.quoteVolume||0));
  return [...preferred,...fallback].slice(0,max).map(x=>`${x.baseAsset}/${x.quoteAsset}`);
}
function addProjectPairs(){
  if(!universeSymbols.length){$('#universeStatus').textContent='Load Binance Spot pairs first.';return 0;}
  const discovered=projectPairsFromUniverse(universeSymbols);
  autoProjectPairs=[...new Set([...autoProjectPairs,...discovered])];
  autoProjectPairs.forEach(ensureMarket);
  persist();renderUniverse(universeSymbols);render();
  $('#universeStatus').textContent=`${autoProjectPairs.length.toLocaleString()} project pairs in AUTO Project Pool · Manual watchlist unchanged.`;
  addLog(`AUTO Project Pool updated: ${autoProjectPairs.length} classified Spot pairs; manual watchlist unchanged.`);
  return autoProjectPairs.length;
}

function prepareAutomaticCandidates(){
  // AUTO mode must scan the Binance Universe itself; it must never depend on the manual watchlist.
  if(!settings.autoSelection || !Array.isArray(universeSymbols) || !universeSymbols.length){scanCandidates=[];return null;}
  scanCandidates=autoCandidatePairs(universeSymbols);
  // If the volume filter is too restrictive or ticker data is incomplete, keep AUTO usable:
  // rank the eligible Spot universe by known 24h volume and take the configured pool.
  if(!scanCandidates.length){
    const quotes=new Set((settings.quoteAssets||[settings.quote||'USDT']).map(x=>String(x).toUpperCase()));
    const max=String(settings.maxScanPairs).toLowerCase()==='auto'?autoCandidateLimit(universeSymbols.length):Math.max(1,Math.min(200,Number(settings.maxScanPairs)||60));
    scanCandidates=universeSymbols.filter(x=>x&&x.symbol&&quotes.has(String(x.quoteAsset).toUpperCase()))
      .sort((a,b)=>(Number(b.quoteVolume)||0)-(Number(a.quoteVolume)||0))
      .slice(0,max).map(x=>`${x.baseAsset}/${x.quoteAsset}`);
  }
  scanCandidates=scanCandidates.filter(Boolean).slice(0,autoCandidateLimit(universeSymbols.length));
  scanCandidates.forEach(ensureMarket);
  return scanCandidates;
}
async function fetchCandleSeries(symbol,interval,limit=140){
  const key=`${symbol}_${interval}_${limit}`; const cached=clientCandleCache.get(key);
  if(cached && Date.now()-cached.at<CLIENT_CANDLE_TTL && Array.isArray(cached.data) && cached.data.length) return cached.data;
  let data=null;
  try{const r=await apiFetch(`/api/candles?symbol=${encodeURIComponent(symbol)}&interval=${encodeURIComponent(interval)}&limit=${limit}`,{cache:'no-store',retryAttempts:2});const d=await r.json().catch(()=>({}));if(r.ok&&Array.isArray(d.candles))data=d.candles;}catch{}
  if(!data){for(const host of ['https://data-api.binance.vision','https://api.binance.com']){try{const r=await fetchWithTimeout(`${host}/api/v3/klines?symbol=${encodeURIComponent(symbol)}&interval=${encodeURIComponent(interval)}&limit=${limit}`,{cache:'no-store'},6500);const rows=await r.json().catch(()=>null);if(r.ok&&Array.isArray(rows)){data=rows.map(x=>({openTime:x[0],open:Number(x[1]),high:Number(x[2]),low:Number(x[3]),close:Number(x[4]),volume:Number(x[5]),closeTime:x[6]}));break;}}catch{}}}
  if(data?.length) { clientCandleCache.set(key,{at:Date.now(),data}); if(clientCandleCache.size>180){const first=clientCandleCache.keys().next().value;clientCandleCache.delete(first);} }
  return data||[];
}
function analyzeTimeframe(candles){
  if(candles.length<60)return {score:50,trend:50,rsi:50,momentum:0,adx:0,ichimoku:50,volatilityPct:0,candles:candles.length};
  const closes=candles.map(x=>Number(x.close)),e=ema(closes,20),rr=rsi(closes,14),mom=momentumPct(closes,8),a=adxDmi(candles,14),bb=bollingerBands(closes,20,2),ich=ichimokuState(candles,{conversion:9,base:26,spanB:52,displacement:26}),atr=atrSeries(candles,14),last=closes.at(-1),ev=e.at(-1)||last,rv=rr.at(-1)||50,av=a.adx.at(-1)||0,bbp=bb.position.at(-1)??50,atrLast=Number(atr.at(-1)||0);
  const trend=last>=ev?78:28,rsiScore=rv>=45&&rv<=72?88:rv>72?55:rv>=35?62:30,momScore=clamp(50+mom*7,0,100),adxScore=clamp(av/35*100,0,100),bbScore=clamp(100-Math.abs(bbp-62)*1.8,0,100);
  const volatilityPct=last>0?atrLast/last*100:0;
  return {score:Math.round(trend*.25+rsiScore*.18+momScore*.18+adxScore*.15+bbScore*.09+ich.score*.15),trend,rsi:rv,momentum:mom,adx:av,ichimoku:ich.score,volatilityPct,candles:candles.length};
}
async function confirmMultiTimeframe(symbols){
  if(!settings.multiTimeframe||!settings.confirmationTimeframes?.length)return;
  const targets=[...new Set(symbols)].slice(0,12);
  const tfSet=[...new Set(targets.flatMap(symbol=>{const m=markets.find(x=>x.symbol===symbol);return settings.timeframeMode==='auto'?adaptiveConfirmationTimeframes(m?.timeframe||settings.timeframe||'4h'):settings.confirmationTimeframes.filter(tf=>tf!==(m?.timeframe||settings.timeframe));}))];
  if(!tfSet.length||!targets.length)return;
  const jobs=[]; for(const symbol of targets){const m=markets.find(x=>x.symbol===symbol);const tfs=settings.timeframeMode==='auto'?adaptiveConfirmationTimeframes(m?.timeframe||settings.timeframe||'4h'):settings.confirmationTimeframes.filter(tf=>tf!==(m?.timeframe||settings.timeframe));for(const tf of tfs)jobs.push({symbol,tf});}
  let cursor=0; const worker=async()=>{while(cursor<jobs.length){const job=jobs[cursor++],m=markets.find(x=>x.symbol===job.symbol);if(!m)continue;const key=`${job.symbol}_${job.tf}`;const cached=clientMtfCache.get(key);if(cached&&Date.now()-cached.at<CLIENT_MTF_TTL){m.mtf=m.mtf||{};m.mtf[job.tf]=cached.value;continue;}try{const c=await fetchCandleSeries(job.symbol,job.tf,140);const a=analyzeTimeframe(c);m.mtf=m.mtf||{};m.mtf[job.tf]=a;clientMtfCache.set(key,{at:Date.now(),value:a});}catch{}}};
  await Promise.all(Array.from({length:Math.min(4,jobs.length)},worker));
  targets.forEach(symbol=>{const m=markets.find(x=>x.symbol===symbol);if(!m)return;const baseTf=m.timeframe||settings.timeframe||'4h';const tfs=settings.timeframeMode==='auto'?adaptiveConfirmationTimeframes(baseTf):settings.confirmationTimeframes.filter(tf=>tf!==baseTf);const vals=tfs.map(tf=>m.mtf?.[tf]?.score).filter(Number.isFinite);const bullish=vals.filter(v=>v>=60).length,bearish=vals.filter(v=>v<=40).length;m.mtfScore=vals.length?Math.round(vals.reduce((a,b)=>a+b,0)/vals.length):50;m.mtfAlignment=vals.length?Math.round(Math.max(bullish,bearish)/vals.length*100):50;m.mtfTimeframes=tfs;});
}
function strategyEnsembleDecision(m,o){
  const trendStrategy=clamp((Number(m.trendStrength||0)/12)*40 + (Number(m.emaSlope||0)>0?18:0) + (Number(m.momentum||0)>0?12:0) + (Number(m.adx||0)>=Number(settings.indicators?.adx?.min||18)?15:5) + (Number(m.ichimokuScore||50)-50)*.30,0,100);
  const pullbackStrategy=clamp((Number(m.rsi||50)<=58?55:30) + (Number(m.momentum||0)>0?25:0) + (Number(m.rangePosition||50)>=30&&Number(m.rangePosition||50)<=80?20:0),0,100);
  const technicalStrategy=clamp(Number(o?.signalPct||0),0,100);
  const ai=aiConsensus(m,o);
  const research=ai.consensus;
  const mtf=Number(o?.mtfScore||50);
  const alignment=Number(o?.mtfAlignment||50);
  const votes=[trendStrategy>=68,pullbackStrategy>=68].filter(Boolean).length;
  const independent=Math.max(trendStrategy,pullbackStrategy);
  const agreement=votes>=2?100:votes===1?62:30;
  const researchGate=research>=settings.aiConsensusThreshold?100:research>=60?60:25;
  const riskGate=Number(o?.riskScore||50)>=68 && Number(o?.rewardRisk||0)>=1.45;
  const metaScore=Number(o?.metaScore||50);
  const abstain=!!o?.abstain;
  const confidence=Math.round(clamp(independent*.17+technicalStrategy*.12+research*.16+mtf*.14+alignment*.08+agreement*.10+metaScore*.13+(riskGate?100:35)*.10,0,100));
  let decision='REJECT'; if(!abstain&&confidence>=84&&votes>=settings.ensembleMinAgreement&&research>=settings.aiConsensusThreshold&&riskGate&&metaScore>=75)decision='BEST'; else if(!abstain&&confidence>=75&&votes>=1&&research>=60&&riskGate&&metaScore>=68)decision='STRONG'; else if(!abstain&&confidence>=60)decision='WATCH';
  return {trendStrategy,pullbackStrategy,technicalStrategy,research,mtf,alignment,agreement,votes,riskGate,confidence,decision,ai,metaScore,abstain};
}
function explainDecision(m,o,d){
  const reasons=[];
  if(d.votes>=2)reasons.push(`${d.votes}/2 core strategies agree`); else if(d.votes===1)reasons.push('only one strategy confirms'); else reasons.push('strategy disagreement');
  reasons.push(`Regime ${o.regime||'—'} · fit ${o.regimeFit||'—'}`); reasons.push(`MTF ${d.mtf}/100`); reasons.push(`AI research ${d.research}/100`); reasons.push(`Meta ${o.metaScore}/100 · uncertainty ${o.uncertainty}%`); reasons.push(`risk ${o.riskScore}/100`); reasons.push(`R:R ${o.rewardRisk.toFixed(2)}`);
  return reasons.join(' · ');
}
function researchDecisionSnapshot(){
  const pool=(selectedOpportunities.length?selectedOpportunities:qualifiedOpportunities).map(pair=>markets.find(m=>m.symbol===pairParts(pair).symbol)).filter(Boolean).slice(0,5);
  return pool.map(m=>{const o=opportunityScore(m),d=strategyEnsembleDecision(m,o);return {m,o,d,why:explainDecision(m,o,d)}}).sort((a,b)=>b.d.confidence-a.d.confidence);
}
function renderAIDecisionCenter(){
  const panel=$('#aiCenterPanel');
  if(!panel)return;
  const host=$('#bgAIDecisionMount .background-mount');
  if(host && panel.parentElement!==host) host.appendChild(panel);
  panel.hidden=false;
  renderResearchDecision();
}
/* v7.56.0 — Decision Replay & Audit Engine.
   Captures a bounded, explainable snapshot of each ranked research decision.
   Replay is deterministic from the recorded evidence snapshot; it never fabricates
   missing historical candles. Audit data is local-only and cannot authorize orders. */
const DECISION_AUDIT_VERSION='lsai-decision-audit-v1';
const DECISION_AUDIT_DEFAULT={enabled:true,maxEntries:500};
function decisionAuditStore(){try{return {...DECISION_AUDIT_DEFAULT,...JSON.parse(localStorage.getItem(DECISION_AUDIT_VERSION)||'{}')}}catch{return {...DECISION_AUDIT_DEFAULT,entries:[]}}}
function saveDecisionAuditStore(x){try{x.updatedAt=Date.now();x.entries=(x.entries||[]).slice(-Number(x.maxEntries||500));localStorage.setItem(DECISION_AUDIT_VERSION,JSON.stringify(x))}catch{}}
function decisionAuditFingerprint(x){const raw=JSON.stringify([x.symbol,x.timeframe,x.regime,x.strategy,x.decision,x.confidence,x.score,x.ai,x.risk,x.rr,x.uncertainty,x.sources]);let h=2166136261;for(let i=0;i<raw.length;i++){h^=raw.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16)}
function captureDecisionAudit(x){if(!x?.m||!x?.o||!x?.d)return;const st=decisionAuditStore();if(st.enabled===false)return;const m=x.m,o=x.o,d=x.d;const entry={id:`AUD-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,at:Date.now(),appVersion:APP_VERSION,symbol:m.symbol,timeframe:m.timeframe||settings.timeframe||'AUTO',regime:m.regime||o.regime||'UNKNOWN',strategy:o.assetStrategy||o.strategy||'AUTO',variant:o.assetStrategyVariant||o.variant||null,decision:d.decision,confidence:d.confidence,score:Number(o.score||0),ai:Number(o.aiConsensus||d.research||0),risk:Number(o.riskScore||0),rr:Number(o.rewardRisk||0),uncertainty:Number(o.uncertainty||0),dataQuality:Number(m.dataQuality??100),strategyVotes:Number(o.strategyVotes??d.votes??0),mtf:Number(d.mtf||o.mtfScore||0),meta:Number(o.metaScore||d.metaScore||0),abstain:!!d.abstain,reason:x.why||explainDecision(m,o,d),sources:Array.isArray(o.contextFusionSources)?o.contextFusionSources.slice(0,6):[],sourceSelection:o.adaptiveSourceSelection||o.contextPolicySelected||null,fusion:{score:Number(o.contextFusionScore||0),confidence:Number(o.contextFusionConfidence||0),conflict:Number(o.contextFusionConflict||0)},learning:{policyScore:Number(o.strategyPolicyScore||0),policyConfidence:Number(o.strategyPolicyConfidence||0)},gates:qualificationGates(m,o).map(g=>({key:g.key,value:g.value,min:g.min,pass:g.pass})),fingerprint:''};entry.fingerprint=decisionAuditFingerprint(entry);const last=st.entries?.[st.entries.length-1];if(last?.fingerprint===entry.fingerprint&&Date.now()-Number(last.at||0)<60000)return;st.entries=Array.isArray(st.entries)?st.entries:[];st.entries.push(entry);saveDecisionAuditStore(st)}
function decisionAuditEntries(){const st=decisionAuditStore();return Array.isArray(st.entries)?st.entries:[]}
function replayDecisionAudit(entry){if(!entry)return null;const gatePass=Array.isArray(entry.gates)?entry.gates.filter(g=>g.pass).length:0;const gateTotal=Array.isArray(entry.gates)?entry.gates.length:0;const safetyPass=gateTotal>0&&gatePass===gateTotal&&!entry.abstain;return {...entry,replay:{status:'REPLAYED_SNAPSHOT',safetyPass,gatePass,gateTotal,consistency:fingerprintMatches(entry)?'CONSISTENT':'CHECKSUM MISMATCH'}}}
function fingerprintMatches(e){return decisionAuditFingerprint(e)===e.fingerprint}
/* v7.58.0 — Policy / Model Drift Monitor. */
const DRIFT_VERSION='lsai-policy-model-drift-v1';
const DRIFT_DEFAULT={enabled:true,minRecent:8,minBaseline:20,recentWindow:30,warningDelta:-0.08,criticalDelta:-0.16,sourcePenaltyFloor:.78,strategyPenaltyFloor:.82,maxEntries:500};
function driftStore(){try{return {...DRIFT_DEFAULT,...JSON.parse(localStorage.getItem(DRIFT_VERSION)||'{}')}}catch{return {...DRIFT_DEFAULT,entries:[]}}}
function saveDriftStore(x){try{x.entries=(x.entries||[]).slice(-Number(x.maxEntries||500));x.updatedAt=Date.now();localStorage.setItem(DRIFT_VERSION,JSON.stringify(x))}catch{}}
function driftRows(){const rows=decisionAttributionStore().entries||[];return rows.filter(x=>Number.isFinite(Number(x.realizedPct)))}
function driftGroupStats(rows,keyFn){const groups={};for(const r of rows){const k=keyFn(r);groups[k] ||= {key:k,resolved:0,wins:0,ret:0,quality:0,lastAt:0};const g=groups[k];g.resolved++;g.wins+=r.win?1:0;g.ret+=Number(r.realizedPct||0);g.quality+=Number(r.quality||0);g.lastAt=Math.max(g.lastAt,Number(r.at||0))}return groups}
function driftMetric(recent,baseline){const rw=recent.length?recent.filter(x=>x.win).length/recent.length:0,bw=baseline.length?baseline.filter(x=>x.win).length/baseline.length:0;return {recentWin:rw,baselineWin:bw,delta:rw-bw,recentReturn:recent.length?recent.reduce((a,x)=>a+Number(x.realizedPct||0),0)/recent.length:0,baselineReturn:baseline.length?baseline.reduce((a,x)=>a+Number(x.realizedPct||0),0)/baseline.length:0}}
function driftSeverity(delta,settings){if(delta<=Number(settings.criticalDelta))return 'CRITICAL';if(delta<=Number(settings.warningDelta))return 'WARNING';return 'STABLE'}
function driftFactorFromSeverity(sev,type='source'){if(sev==='CRITICAL')return type==='source'?0.78:0.82;if(sev==='WARNING')return type==='source'?0.90:0.91;return 1}
function evaluateDriftGroup(rows,keyFn,labelFn){const cfg=driftStore(), groups=driftGroupStats(rows,keyFn), out=[];for(const g of Object.values(groups)){if(g.resolved<Number(cfg.minBaseline))continue;const ordered=rows.filter(r=>keyFn(r)===g.key).sort((a,b)=>Number(a.at||0)-Number(b.at||0));const recent=ordered.slice(-Number(cfg.recentWindow||30)), baseline=ordered.slice(0,Math.max(0,ordered.length-recent.length));if(recent.length<Number(cfg.minRecent)||baseline.length<Number(cfg.minBaseline))continue;const m=driftMetric(recent,baseline),severity=driftSeverity(m.delta,cfg);out.push({key:g.key,label:labelFn(g.key),resolved:g.resolved,recent:recent.length,baseline:baseline.length,...m,severity,factor:driftFactorFromSeverity(severity,labelFn(g.key).startsWith('source')?'source':'strategy')})}return out.sort((a,b)=>((({CRITICAL:0,WARNING:1,STABLE:2}[a.severity]??9)-({CRITICAL:0,WARNING:1,STABLE:2}[b.severity]??9))||a.delta-b.delta))}
function driftSnapshot(){const rows=driftRows(),cfg=driftStore();const source=evaluateDriftGroup(rows,r=>r.source||'unknown',k=>`source:${k}`);const strategy=evaluateDriftGroup(rows,r=>[r.symbol||'?',r.timeframe||'AUTO',r.strategy||'AUTO',r.regime||'UNKNOWN'].join('|'),k=>`strategy:${k}`);const recent=rows.slice(-Number(cfg.recentWindow||30)),baseline=rows.slice(0,Math.max(0,rows.length-recent.length));const overall=recent.length>=cfg.minRecent&&baseline.length>=cfg.minBaseline?{...driftMetric(recent,baseline),severity:driftSeverity(driftMetric(recent,baseline).delta,cfg)}:{recentWin:0,baselineWin:0,delta:0,recentReturn:0,baselineReturn:0,severity:'INSUFFICIENT'};return {version:DRIFT_VERSION,updatedAt:Date.now(),resolved:rows.length,overall,source,strategy}}
function driftSourceFactor(source,context){const snap=driftSnapshot(), row=snap.source.find(x=>x.key===`source:${source}`);let f=row?.factor||1;const ctx=String(context||'');const exact=snap.strategy.find(x=>x.key===ctx);if(exact)f=Math.min(f,exact.factor);return clamp(f,Number(driftStore().sourcePenaltyFloor||.78),1)}
function updateDriftLedger(){const snap=driftSnapshot(),st=driftStore();const sig=JSON.stringify({overall:snap.overall,severe:snap.source.filter(x=>x.severity!=='STABLE').map(x=>[x.key,x.severity,x.delta]),strategy:snap.strategy.filter(x=>x.severity!=='STABLE').map(x=>[x.key,x.severity,x.delta])});const last=st.entries?.[st.entries.length-1];if(last?.signature===sig&&Date.now()-Number(last.at||0)<6*3600000)return snap;st.entries=Array.isArray(st.entries)?st.entries:[];st.entries.push({at:Date.now(),signature:sig,overall:snap.overall,sourceAlerts:snap.source.filter(x=>x.severity!=='STABLE').slice(0,20),strategyAlerts:snap.strategy.filter(x=>x.severity!=='STABLE').slice(0,20)});saveDriftStore(st);return snap}
/* v7.58.0 — Adaptive Recovery Engine.
   Converts drift observations into bounded recovery actions: prefer stable alternative
   strategies/sources, record recovery decisions, and never relax Core safety gates. */
const RECOVERY_VERSION='lsai-adaptive-recovery-v1';
const RECOVERY_DEFAULT={enabled:true,minEvidence:8,criticalThreshold:2,maxInfluence:4,sourceFloor:.78,maxEntries:500,cooldownHours:6};
function recoveryStore(){try{return {...RECOVERY_DEFAULT,...JSON.parse(localStorage.getItem(RECOVERY_VERSION)||'{}')}}catch{return {...RECOVERY_DEFAULT,entries:[]}}}
function saveRecoveryStore(x){try{x.entries=(x.entries||[]).slice(-Number(x.maxEntries||500));x.updatedAt=Date.now();localStorage.setItem(RECOVERY_VERSION,JSON.stringify(x))}catch{}}
function recoverySeverityForContext(m,strategy){const snap=driftSnapshot(),key=[m?.symbol||'?',m?.timeframe||settings.timeframe||'AUTO',strategy||'AUTO',m?.regime||m?.marketRegime||'UNKNOWN'].join('|');return snap.strategy.find(x=>x.key===key)||null}
function recoverySourceScore(name,m,o){const context={symbol:m?.symbol,timeframe:m?.timeframe||settings.timeframe||'AUTO',strategy:o?.assetStrategy||o?.strategy||'AUTO',regime:m?.regime||m?.marketRegime||'UNKNOWN'};const reliability=name==='tradingview'?evidenceContextReliability('TradingView',context):name==='ctrader'?evidenceContextReliability('cTrader',context):name==='validation'?evidenceSourceReliability('Validation'):name==='ml'?evidenceSourceReliability('ML'):1;const adaptive=adaptiveSourceWeight(name,context);const factor=driftSourceFactor(name==='tradingview'?'TradingView':name==='ctrader'?'cTrader':name,`source:${name}`);return Number(reliability||0)*Number(adaptive||1)*Number(factor||1)}
function adaptiveRecovery(m,o,strategyPolicy,selectedSources=[]){
  const cfg=recoveryStore(); if(cfg.enabled===false)return {enabled:false,action:'HOLD',boost:0,reason:'disabled'};
  const current=o?.assetStrategy||strategyPolicy?.selectedStrategy||'BALANCED';
  const currentDrift=recoverySeverityForContext(m,current);
  const sourceNames=['core','tradingview','ctrader','validation','ml'];
  const sourceScores=sourceNames.map(name=>({name,score:recoverySourceScore(name,m,o)})).sort((a,b)=>b.score-a.score);
  const sourceAlerts=sourceNames.map(name=>{const display=name==='tradingview'?'TradingView':name==='ctrader'?'cTrader':name==='validation'?'Validation':name==='ml'?'ML':'core';const row=driftSnapshot().source.find(x=>x.key===`source:${display}`||x.key===`source:${name}`);return {name,severity:row?.severity||'STABLE',factor:row?.factor||1}});
  const candidates=Array.isArray(strategyPolicy?.candidates)?strategyPolicy.candidates:[];
  const alternatives=candidates.map(c=>{const row=recoverySeverityForContext(m,c.id);return {...c,driftSeverity:row?.severity||'STABLE',driftFactor:row?.factor||1}}).filter(c=>c.id&&c.id!==current).sort((a,b)=>((b.policyScore||0)-(a.policyScore||0))||((b.driftFactor||1)-(a.driftFactor||1)));
  const criticalStrategy=currentDrift?.severity==='CRITICAL', criticalSources=sourceAlerts.filter(x=>x.severity==='CRITICAL').length;
  let action='HOLD',boost=0,recommendedStrategy=current,recommendedVariant=o?.assetStrategyVariant||'BASE',recommendedSources=selectedSources?.length?selectedSources.slice(0,3):['core'],reason='لا يوجد انجراف يستدعي الاستعادة.';
  if(criticalStrategy&&alternatives.length){const alt=alternatives.find(x=>x.driftSeverity!=='CRITICAL')||alternatives[0];recommendedStrategy=alt.id;recommendedVariant=alt.variant||alt.name||'BASE';action='STRATEGY_RECOVERY';boost=clamp(Number(cfg.maxInfluence||4),0,4);reason=`تم رصد انجراف حرج في ${current} واختيار بديل أكثر استقرارًا: ${alt.id}.`}
  else if(criticalSources){const stable=sourceScores.filter(x=>!sourceAlerts.find(a=>a.name===x.name&&a.severity==='CRITICAL')).slice(0,3).map(x=>x.name);if(stable.length>=1){recommendedSources=[...new Set(['core',...stable])].slice(0,3);action='SOURCE_RECOVERY';boost=clamp(Number(cfg.maxInfluence||4)*.65,0,3);reason=`تم رصد ${criticalSources} مصدر/مصادر حرجة؛ تم تفضيل الأدلة الأكثر استقرارًا.`}}
  else if(currentDrift?.severity==='WARNING'){action='CAUTIOUS_RECOVERY';boost=1;reason=`انجراف تحذيري في ${current}; خفض الاعتماد مع إبقاء القرار تحت بوابات السلامة.`}
  const recovered=(action!=='HOLD');
  return {enabled:true,action,boost,recovered,currentStrategy:current,recommendedStrategy,recommendedVariant,recommendedSources,criticalStrategy,criticalSources,sourceScores,reason,contextKey:[m?.symbol||'?',m?.timeframe||'AUTO',m?.regime||'UNKNOWN'].join('|')};
}
function recordRecoveryDecision(r,m,o){if(!r?.recovered)return;const st=recoveryStore();const key=`${m?.symbol}|${m?.timeframe||'AUTO'}|${o?.assetStrategy||'AUTO'}|${r.action}|${r.recommendedStrategy}`;const last=st.entries?.[st.entries.length-1];if(last?.key===key&&Date.now()-Number(last.at||0)<Number(st.cooldownHours||6)*3600000)return;st.entries=Array.isArray(st.entries)?st.entries:[];st.entries.push({at:Date.now(),key,action:r.action,symbol:m?.symbol,timeframe:m?.timeframe||'AUTO',regime:m?.regime||'UNKNOWN',currentStrategy:r.currentStrategy,recommendedStrategy:r.recommendedStrategy,recommendedVariant:r.recommendedVariant||null,recommendedSources:r.recommendedSources,reason:r.reason});saveRecoveryStore(st)}
function renderAdaptiveRecoveryPanel(){const host=$('#bgRecoveryMount .background-mount');if(!host)return;let box=$('#adaptiveRecoveryPanel');if(!box){box=document.createElement('section');box.id='adaptiveRecoveryPanel';box.className='panel adaptive-recovery-panel';host.appendChild(box)}const st=recoveryStore(), rows=(st.entries||[]).slice().reverse().slice(0,12);box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">ADAPTIVE RECOVERY ENGINE</p><h2>محرك الاستعادة التكيفية</h2><p class="muted">يحوّل إشارات الانجراف إلى استعادة محدودة: يفضّل استراتيجية أو مصادر أكثر استقرارًا، مع الاحتفاظ ببوابات السلامة كما هي.</p></div><span class="tag">${st.enabled?'AUTO':'OFF'}</span></div><div class="validation-row"><strong>Policy</strong><span>الاستعادة لا تخفض Data/Confidence/Risk/R:R gates ولا تفتح تداولًا حقيقيًا. التأثير الأقصى ${Number(st.maxInfluence||4).toFixed(1)} نقاط.</span></div><div class="table-wrap"><table><thead><tr><th>Time</th><th>Pair</th><th>Action</th><th>Current</th><th>Recommended</th><th>Sources</th></tr></thead><tbody>${rows.map(x=>`<tr><td>${new Date(x.at).toLocaleString()}</td><td>${escapeHTML(x.symbol||'—')}</td><td>${escapeHTML(x.action||'—')}</td><td>${escapeHTML(x.currentStrategy||'—')}</td><td>${escapeHTML(x.recommendedStrategy||'—')}</td><td>${escapeHTML((x.recommendedSources||[]).join(', '))}</td></tr>`).join('')||'<tr><td colspan="6">لا توجد عمليات استعادة حتى الآن.</td></tr>'}</tbody></table></div>`}
function renderDriftMonitorPanel(){const host=$('#bgDriftMount .background-mount');if(!host)return;let box=$('#driftMonitorPanel');if(!box){box=document.createElement('section');box.id='driftMonitorPanel';box.className='panel drift-monitor-panel';host.appendChild(box)}const s=updateDriftLedger(),sev=s.overall.severity,alerts=[...s.source,...s.strategy].filter(x=>x.severity!=='STABLE').slice(0,14);box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">POLICY / MODEL DRIFT MONITOR</p><h2>مراقبة انجراف النماذج والسياسات</h2><p class="muted">يراقب تدهور الأداء مقارنة بخط الأساس، ويحسب خفضًا تدريجيًا وآمنًا لتأثير المصدر أو السياسة. لا يستطيع هذا النظام تجاوز بوابات السلامة أو فتح تداول حقيقي.</p></div><span class="tag">${escapeHTML(sev)}</span></div><div class="performance-results"><article><span>Resolved evidence</span><strong>${s.resolved}</strong><small>Decision Attribution</small></article><article><span>Recent win rate</span><strong>${s.overall.severity==='INSUFFICIENT'?'—':(s.overall.recentWin*100).toFixed(1)+'%'}</strong><small>last ${driftStore().recentWindow} outcomes</small></article><article><span>Baseline delta</span><strong>${s.overall.severity==='INSUFFICIENT'?'—':((s.overall.delta>=0?'+':'')+(s.overall.delta*100).toFixed(1)+'pp')}</strong><small>recent vs baseline</small></article><article><span>Active alerts</span><strong>${alerts.length}</strong><small>WARNING / CRITICAL</small></article></div><div class="table-wrap"><table><thead><tr><th>Type</th><th>Context</th><th>Recent</th><th>Baseline</th><th>Delta</th><th>Severity</th><th>Influence</th></tr></thead><tbody>${alerts.map(x=>`<tr><td>${escapeHTML(x.label.split(':')[0])}</td><td>${escapeHTML(x.label.slice(x.label.indexOf(':')+1))}</td><td>${(x.recentWin*100).toFixed(1)}%</td><td>${(x.baselineWin*100).toFixed(1)}%</td><td>${(x.delta>=0?'+':'')+(x.delta*100).toFixed(1)}pp</td><td>${x.severity}</td><td>${(x.factor*100).toFixed(0)}%</td></tr>`).join('')||'<tr><td colspan="7">لا يوجد انجراف مؤثر حاليًا أو لا توجد أدلة كافية.</td></tr>'}</tbody></table></div><div class="audit-detail"><strong>سياسة الاستجابة:</strong> Stable = 100% من التأثير · Warning = خفض تدريجي · Critical = خفض أقوى، مع حدود دنيا ثابتة. عند نقص الأدلة لا يتم خفض التأثير.</div>`}
/* v7.56.0 — Decision Quality & Outcome Attribution Engine. */
const DECISION_ATTR_VERSION='lsai-decision-attribution-v1';
const DECISION_ATTR_DEFAULT={enabled:true,maxEntries:800,minConfidence:60};
function decisionAttributionStore(){try{return {...DECISION_ATTR_DEFAULT,...JSON.parse(localStorage.getItem(DECISION_ATTR_VERSION)||'{}')}}catch{return {...DECISION_ATTR_DEFAULT,entries:[]}}}
function saveDecisionAttributionStore(x){try{x.entries=(x.entries||[]).slice(-Number(x.maxEntries||800));x.updatedAt=Date.now();localStorage.setItem(DECISION_ATTR_VERSION,JSON.stringify(x))}catch{}}
function decisionAttributionKey(x){return [x.symbol,x.timeframe||'AUTO',x.strategy||'AUTO',x.regime||'UNKNOWN'].join('|')}
function decisionAttributionSourceRows(e){const src=Array.isArray(e.sources)?e.sources:[];return src.map(x=>String(x)).filter(Boolean)}
function attributeDecisionOutcome(audit,outcome,source){
  if(!audit||!Number.isFinite(Number(outcome)))return null;
  const ret=Number(outcome), win=ret>0, conf=Number(audit.confidence||0), score=Number(audit.score||0), quality=clamp(Math.round(conf*.45+score*.35+Number(audit.dataQuality||0)*.20),0,100);
  const expectedUp=['BEST','STRONG'].includes(String(audit.decision||'').toUpperCase());
  const directionalCorrect=expectedUp?win:!win;
  return {auditId:audit.id,at:Date.now(),symbol:audit.symbol,timeframe:audit.timeframe,strategy:audit.strategy,regime:audit.regime,decision:audit.decision,confidence:conf,score,quality,realizedPct:ret,win,directionalCorrect,source,sourceList:decisionAttributionSourceRows(audit),fusionConflict:Number(audit.fusion?.conflict||0),uncertainty:Number(audit.uncertainty||0)};
}
function decisionAttributionFindAudit(r){
  const entries=decisionAuditEntries(); const symbol=r.symbol, tf=r.timeframe||'AUTO', strategy=r.strategy||r.assetStrategy||'AUTO', regime=r.regime||'UNKNOWN', opened=Number(r.createdAt||r.openedAt||0);
  const candidates=entries.filter(e=>e.symbol===symbol&&(e.timeframe===tf||tf==='AUTO'||e.timeframe==='AUTO')&&(strategy==='AUTO'||e.strategy===strategy||e.strategy==='AUTO')&&(regime==='UNKNOWN'||e.regime===regime||e.regime==='UNKNOWN'));
  if(!candidates.length)return null;
  return candidates.map(e=>({e,d:Math.abs(Number(e.at||0)-opened)})).filter(x=>x.d<=48*3600000).sort((a,b)=>a.d-b.d)[0]?.e||null;
}
function decisionAttributionRun(){
  const st=decisionAttributionStore(); if(st.enabled===false)return {processed:0,added:0};
  const existing=new Set((st.entries||[]).map(x=>`${x.auditId}|${x.source}`)); let added=0,processed=0;
  const outcomes=[];
  shadowLedger().filter(x=>x.resolved&&Number.isFinite(Number(x.realizedPct))).forEach(r=>outcomes.push({r,source:'shadow',outcome:r.realizedPct}));
  paperLedger().filter(x=>x.status==='CLOSED'&&Number.isFinite(Number(x.pnlPct))).forEach(r=>outcomes.push({r,source:'paper',outcome:r.pnlPct}));
  for(const x of outcomes){const audit=decisionAttributionFindAudit(x.r);if(!audit)continue;processed++;const key=`${audit.id}|${x.source}`;if(existing.has(key))continue;const row=attributeDecisionOutcome(audit,x.outcome,x.source);if(row){st.entries.push(row);existing.add(key);added++;}}
  saveDecisionAttributionStore(st);return {processed,added,entries:st.entries.length};
}
function decisionAttributionSummary(){
  const rows=decisionAttributionStore().entries||[]; const resolved=rows.length, wins=rows.filter(x=>x.win).length, correct=rows.filter(x=>x.directionalCorrect).length;
  const avgQuality=resolved?rows.reduce((a,x)=>a+Number(x.quality||0),0)/resolved:0, avgRet=resolved?rows.reduce((a,x)=>a+Number(x.realizedPct||0),0)/resolved:0;
  const bySource={}; for(const r of rows){const k=r.source||'unknown';bySource[k] ||= {source:k,resolved:0,wins:0,correct:0,ret:0,quality:0};const q=bySource[k];q.resolved++;q.wins+=r.win?1:0;q.correct+=r.directionalCorrect?1:0;q.ret+=Number(r.realizedPct||0);q.quality+=Number(r.quality||0)}
  const sources=Object.values(bySource).map(x=>({...x,winRate:x.resolved?x.wins/x.resolved*100:0,accuracy:x.resolved?x.correct/x.resolved*100:0,avgReturn:x.resolved?x.ret/x.resolved:0,avgQuality:x.resolved?x.quality/x.resolved:0}));
  return {resolved,wins,winRate:resolved?wins/resolved*100:0,accuracy:resolved?correct/resolved*100:0,avgQuality,avgReturn,sources};
}
function renderDecisionAttributionPanel(){
  const host=$('#bgAuditAttributionMount .background-mount');if(!host)return;let box=$('#decisionAttributionPanel');if(!box){box=document.createElement('section');box.id='decisionAttributionPanel';box.className='panel decision-attribution-panel';host.appendChild(box)}
  const run=decisionAttributionRun(), s=decisionAttributionSummary(), rows=(decisionAttributionStore().entries||[]).slice().reverse().slice(0,12);
  box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">DECISION QUALITY &amp; OUTCOME ATTRIBUTION</p><h2>جودة القرار ونَسب النتيجة</h2><p class="muted">يربط قرارات Decision Audit بنتائج Shadow/Paper، ثم يقيس جودة القرار واتجاهه والـRegime ومصادر الأدلة. لا يغيّر النتيجة بأثر رجعي ولا يتجاوز بوابات السلامة.</p></div><span class="tag">${s.resolved} ATTRIBUTED</span></div><div class="performance-results"><article><span>Attributed outcomes</span><strong>${s.resolved}</strong><small>+${run.added} new this run</small></article><article><span>Decision win rate</span><strong>${s.resolved?s.winRate.toFixed(1)+'%':'—'}</strong><small>realized outcome</small></article><article><span>Directional accuracy</span><strong>${s.resolved?s.accuracy.toFixed(1)+'%':'—'}</strong><small>decision direction vs outcome</small></article><article><span>Avg decision quality</span><strong>${s.resolved?s.avgQuality.toFixed(1):'—'}</strong><small>confidence · score · data</small></article></div><div class="table-wrap"><table><thead><tr><th>Source</th><th>Resolved</th><th>Win%</th><th>Accuracy</th><th>Avg Return</th><th>Quality</th></tr></thead><tbody>${s.sources.map(x=>`<tr><td>${escapeHTML(x.source)}</td><td>${x.resolved}</td><td>${x.winRate.toFixed(1)}%</td><td>${x.accuracy.toFixed(1)}%</td><td>${x.avgReturn>=0?'+':''}${x.avgReturn.toFixed(2)}%</td><td>${x.avgQuality.toFixed(1)}</td></tr>`).join('')||'<tr><td colspan="6">لا توجد نتائج منسوبة بعد. ستظهر بعد إغلاق Shadow/Paper.</td></tr>'}</tbody></table></div><div class="table-wrap"><table><thead><tr><th>Symbol</th><th>TF</th><th>Strategy</th><th>Regime</th><th>Decision</th><th>Outcome</th><th>Quality</th></tr></thead><tbody>${rows.map(x=>`<tr><td>${escapeHTML(x.symbol)}</td><td>${escapeHTML(x.timeframe)}</td><td>${escapeHTML(x.strategy)}</td><td>${escapeHTML(x.regime)}</td><td>${escapeHTML(x.decision)}</td><td>${x.realizedPct>=0?'+':''}${Number(x.realizedPct).toFixed(2)}%</td><td>${Number(x.quality).toFixed(1)}</td></tr>`).join('')||'<tr><td colspan="7">لا توجد قرارات منسوبة بعد.</td></tr>'}</tbody></table></div>`;
}
function renderDecisionAuditPanel(){const host=$('#bgAuditMount .background-mount');if(!host)return;let box=$('#decisionAuditPanel');if(!box){box=document.createElement('section');box.id='decisionAuditPanel';box.className='panel decision-audit-panel';host.appendChild(box)}const all=decisionAuditEntries(),rows=all.slice().reverse().slice(0,15),last=rows[0];box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">DECISION REPLAY &amp; AUDIT</p><h2>سجل القرارات وإعادة التشغيل</h2><p class="muted">يحفظ لقطة قابلة للتدقيق للأدلة والأوزان والـRegime والاستراتيجية والبوابات لحظة القرار. إعادة التشغيل هنا تعيد بناء اللقطة المسجلة ولا تدّعي امتلاك شموع تاريخية غير محفوظة.</p></div><span class="tag">${all.length} RECORDS</span></div><div class="performance-results"><article><span>Recorded decisions</span><strong>${all.length}</strong><small>Local audit ledger</small></article><article><span>Latest</span><strong>${last?escapeHTML(last.decision):'—'}</strong><small>${last?escapeHTML(last.symbol):'No scan yet'}</small></article><article><span>Integrity</span><strong>${last&&fingerprintMatches(last)?'OK':'—'}</strong><small>Snapshot checksum</small></article></div><div class="table-wrap"><table><thead><tr><th>Time</th><th>Symbol</th><th>TF / Regime</th><th>Decision</th><th>Confidence</th><th>Score</th><th>Gates</th><th>Replay</th></tr></thead><tbody>${rows.map(e=>{const r=replayDecisionAudit(e);return `<tr><td>${new Date(e.at).toLocaleTimeString()}</td><td>${escapeHTML(e.symbol)}</td><td>${escapeHTML(e.timeframe)} / ${escapeHTML(e.regime)}</td><td>${escapeHTML(e.decision)}</td><td>${e.confidence}</td><td>${Number(e.score).toFixed(1)}</td><td>${r.replay.gatePass}/${r.replay.gateTotal}</td><td>${r.replay.consistency==='CONSISTENT'?'CONSISTENT':'CHECK'}</td></tr>`}).join('')||'<tr><td colspan="8">لا توجد قرارات مسجلة بعد. شغّل Scan لإنشاء أول لقطة تدقيق.</td></tr>'}</tbody></table></div>${last?`<div class="audit-detail"><strong>آخر قرار:</strong> ${escapeHTML(last.symbol)} · ${escapeHTML(last.decision)} · ${escapeHTML(last.reason||'—')}<br><small>Sources: ${escapeHTML((last.sources||[]).join(' · ')||'core')} · Fusion ${Number(last.fusion?.score||0).toFixed(1)} · Conflict ${Number(last.fusion?.conflict||0).toFixed(1)} · Policy ${Number(last.learning?.policyScore||0).toFixed(1)}</small></div>`:''}`}
function renderResearchDecision(){
  const box=$('#aiDecisionResults'); if(!box)return; const rows=researchDecisionSnapshot(); rows.forEach(captureDecisionAudit);
  box.innerHTML=rows.map((x,i)=>`<div class="ai-decision-row"><div><strong>#${i+1} ${x.m.base}/${x.m.quote}</strong><small>${x.d.decision} · ${x.why}</small></div><div class="ai-decision-metrics"><span>Confidence <b>${x.d.confidence}</b></span><span>Strategies <b>${x.d.votes}/2</b></span><span>MTF <b>${x.d.mtf}</b></span><span>Risk <b>${x.o.riskScore}</b></span></div></div>`).join('')||'<div class="empty-state">Run a scan to generate the research decision layer.</div>';
  const best=rows[0]; const status=$('#aiDecisionStatus'); if(status)status.textContent=best?`Decision: ${best.d.decision} · ${best.m.base}/${best.m.quote}`:'Waiting for scan';
}
function qualificationGates(m,o){
  const gates=[
    {key:'score',label:'Score',value:Number(o.score||0),min:Number(settings.minOpportunityScore)},
    {key:'ai',label:'AI',value:Number(o.aiConsensus||0),min:Number(settings.aiConsensusThreshold)},
    {key:'data',label:'Data quality',value:Number(m?.dataQuality??100),min:85},
    {key:'confidence',label:'Decision confidence',value:Number(o.decisionConfidence||0),min:75},
    {key:'strategy',label:'Strategy agreement',value:Number(o.strategyVotes||0),min:Number(settings.ensembleMinAgreement),format:v=>`${v}/2`},
    {key:'risk',label:'Risk score',value:Number(o.riskScore||0),min:68},
    {key:'rr',label:'R:R',value:Number(o.rewardRisk||0),min:1.45,format:v=>v.toFixed(2)}
  ];
  return gates.map(g=>({...g,pass:g.value>=g.min,display:g.format?g.format(g.value):Number.isInteger(g.value)?g.value:g.value.toFixed(1),need:g.format?g.format(g.min):Number.isInteger(g.min)?g.min:g.min.toFixed(1)}));
}
function diagnosticNearMiss(x){
  const gates=qualificationGates(x.m,x.o), failed=gates.filter(g=>!g.pass);
  const deficit=failed.reduce((sum,g)=>sum+Math.max(0,(g.min-g.value)/(g.min||1)),0);
  return {...x,gates,failed,failedCount:failed.length,deficit};
}
function renderOpportunityDiagnostics(ranked,qualified,nearMisses){
  const box=$('#opportunityDiagnostics'); if(!box)return;
  const qset=new Set(qualified.map(x=>x.m.symbol));
  const counts={score:0,ai:0,data:0,confidence:0,strategy:0,risk:0,rr:0,other:0};
  ranked.forEach(x=>{
    if(qset.has(x.m.symbol))return;
    const failed=qualificationGates(x.m,x.o).filter(g=>!g.pass);
    if(failed.length) failed.forEach(g=>{counts[g.key]++;}); else counts.other++;
  });
  const labels={score:'Score',ai:'AI',data:'Data quality',confidence:'Decision confidence',strategy:'Strategy agreement',risk:'Risk score',rr:'R:R',other:'Other'};
  const parts=Object.entries(counts).filter(([,n])=>n).map(([k,n])=>`<span>${labels[k]} <b>${n}</b></span>`).join('');
  const near=nearMisses.slice(0,5).map(x=>{
    const d=diagnosticNearMiss(x);
    const blockers=d.failed.map(g=>`${g.label} ${g.display}/${g.need}`).join(' · ')||'No failed gate';
    const symbol=x?.m?.symbol || `${x?.m?.base||''}/${x?.m?.quote||''}`;
    if(!symbol || symbol==='/' || symbol==='undefined/undefined') return '';
    return `<span class="near-miss" title="${blockers}"><strong>${symbol}</strong> · Score ${x.o.score.toFixed(1)} · AI ${x.o.aiConsensus} · ❌ ${blockers}</span>`;
  }).join('');
  box.innerHTML=`<div class="diagnostic-row"><strong>Rejection analytics</strong>${parts||'<span>No rejections</span>'}</div>${near?`<div class="diagnostic-row diagnostic-near"><strong>Near qualified</strong>${near}</div>`:''}`;
}
function finalizeAutomaticSelection(){
  // Automatic mode is fully universe-driven. Personal watch pairs never constrain ranking.
  const pool=settings.autoSelection?(scanCandidates.length?scanCandidates:autoCandidatePairs(universeSymbols)):watchPairs();
  const ranked=pool.map(pair=>markets.find(m=>m.symbol===pairParts(pair).symbol)).filter(m=>m&&m.price>0).map(m=>({m,o:opportunityScore(m)})).sort((a,b)=>b.o.rankScore-a.o.rankScore);
  // The composite score already contains the indicator evidence. Do not require a
  // second hard indicator gate: conflicting indicators are common in live markets
  // and previously caused strong composite opportunities to be rejected twice.
  const qualified=ranked.filter(x=>engineQualified(x.m,x.o));
  // Keep the closest rejected candidates for diagnostics without promoting them to Top.
  // Near-miss ranking is based on failed-gate count first, then normalized distance to passing all gates.
  const nearMisses=ranked.filter(x=>!qualified.includes(x)).map(diagnosticNearMiss)
    .sort((a,b)=>a.failedCount-b.failedCount||a.deficit-b.deficit||b.o.rankScore-a.o.rankScore).slice(0,8);
  const topLimit=String(settings.maxOpportunities).toLowerCase()==='auto'?autoOpportunityLimit(scanCandidates.length,qualified.length):Math.max(1,Math.min(100,Number(settings.maxOpportunities)||20));
  const chosen=qualified.slice(0,topLimit).map(x=>`${x.m.base}/${x.m.quote}`);
  qualifiedOpportunities=qualified.map(x=>`${x.m.base}/${x.m.quote}`);
  selectedOpportunities=chosen;
  return {selected:chosen,ranked,qualifiedCount:qualified.length,qualifiedOpportunities:qualified.map(x=>`${x.m.base}/${x.m.quote}`),nearMisses};
}
async function discoverUniverse(){
  const status=$('#universeStatus');
  if(status) status.textContent='Loading Binance Spot pairs…';
  try{
    let d=null,lastError='';
    // Same-origin Worker first. This is the canonical API for the deployed app.
    try{
      const r=await apiFetch('/api/exchange-info',{cache:'no-store',headers:{accept:'application/json'},retryAttempts:2});
      const body=await r.json().catch(()=>({}));
      if(r.ok&&Array.isArray(body.symbols)&&body.symbols.length>=1)d=body;
      else lastError+=` · Worker ${r.status||'OK'}${body.error?`: ${body.error}`:''}`;
    }catch(e){lastError+=` · Worker: ${e.message}`;}
    // Public Binance mirrors are fallbacks for standalone/mobile builds.
    if(!d){
      for(const base of ['https://data-api.binance.vision','https://api.binance.com','https://api1.binance.com']){
        try{
          const r=await fetchWithTimeout(`${base}/api/v3/exchangeInfo?symbolStatus=TRADING`,{cache:'no-store',headers:{accept:'application/json'}},9000);
          const body=await r.json().catch(()=>({}));
          if(r.ok&&Array.isArray(body.symbols)){d={symbols:body.symbols,source:'Binance public Spot market data'};break;}
          lastError+=` · ${new URL(base).hostname} ${r.status}`;
        }catch(e){lastError+=` · ${new URL(base).hostname}: ${e.name==='AbortError'?'timeout':e.message}`;}
      }
    }
    if(!d)throw Error(`Exchange info unavailable.${lastError}`);
    exchangeSymbols=d.symbols||[];
    let list=exchangeSymbols.filter(isSpotUniverseSymbol).map(x=>({...x,categories:classifyAsset(x.baseAsset,x.quoteAsset),quoteVolume:0}));
    // Fuse 24h ticker data only as enrichment/repair for truncated exchangeInfo responses.
    try{
      const tr=await apiFetch('/api/tickers',{cache:'no-store',headers:{accept:'application/json'},retryAttempts:2}); const td=await tr.json().catch(()=>({}));
      const tickers=Array.isArray(td.tickers)?td.tickers:[]; const by=new Map(list.map(x=>[x.symbol,x]));
      for(const t of tickers){const symbol=String(t.symbol||'').toUpperCase();if(!symbol||by.has(symbol))continue;const m=symbol.match(/^([A-Z0-9]{1,20})(USDT|USDC|FDUSD|DAI|TUSD|USDP|USDS|EUR|TRY|BRL|GBP|AUD|JPY|PLN|RON|ZAR|UAH|NGN|RUB|MXN|ARS|IDR|VND|THB|BIDR|COP|CLP)$/);if(!m)continue;by.set(symbol,{symbol,baseAsset:m[1],quoteAsset:m[2],status:'TRADING',isSpotTradingAllowed:true,categories:classifyAsset(m[1],m[2]),quoteVolume:Number(t.quoteVolume)||0});}
      list=[...by.values()]; const vm=new Map(tickers.map(x=>[x.symbol,Number(x.quoteVolume)||0])); list.forEach(x=>x.quoteVolume=vm.get(x.symbol)||x.quoteVolume||0);
    }catch{}
    universeSymbols=list; saveUniverseCache(list,d.source||'Binance public Spot market data'); renderUniverse(list); renderChartPairOptions(chartState.symbol||'');
    const discoverBtn=$('#discoverAssets'); if(discoverBtn)discoverBtn.textContent='Refresh Binance Spot pairs';
    const projectPairs=projectPairsFromUniverse(list).slice(0,30); watchPairs().forEach(ensureMarket);
    $('#watchlistInput').value=settings.watchlist; persist(); renderPairList();
    if(status)status.textContent=`Found ${list.length.toLocaleString()} unique tradable Spot pairs · ${projectPairs.length.toLocaleString()} classified matches · automatic selection ready`;
    $('#pairStatus').textContent='Universe loaded. Use “Auto-add project pairs” to populate the AUTO Project Pool; Manual Watchlist remains separate.';
    addLog(`Binance Spot discovery: ${list.length.toLocaleString()} tradable pairs loaded.`); render();
    if(settings.autoSelection)$('#universeStatus').textContent='Universe ready. Run Scan to rank the best opportunities automatically.';
    await loadChart(chartState.symbol||watchPairs()[0]||'BTC/USDT',settings.timeframe);
  }catch(e){if(status)status.textContent=`Discovery failed: ${e.message}`;addLog(`Asset Universe error: ${e.message}`);}
}
const KNOWN_BSTOCKS=['SPCXB','GMEB','AXTIB','CRWVB','INTWB','KORUB','MUUB','MVLLB','ORCLB','QNTB','SNXXB','TQQQB','STXB','SQQQB','MRNAB','CRWDB','WDCB','NVDAB'];
function renderTradFiResults(query=''){
  const box=$('#tradfiResults');if(!box)return;const q=String(query||'').trim().toUpperCase(),type=$('#tradfiType')?.value||'all';
  const spot=(universeSymbols||[]).filter(x=>KNOWN_BSTOCKS.includes(String(x.baseAsset||'').toUpperCase())).map(x=>({type:'bstock',symbol:`${x.baseAsset}/${x.quoteAsset}`,label:x.baseAsset,volume:Number(x.quoteVolume||0)}));
  const seed=[...spot,...[
    ['AAPL','Apple','stock'],['NVDA','NVIDIA','stock'],['MSFT','Microsoft','stock'],['AMZN','Amazon','stock'],['QQQ','Invesco QQQ','etf'],['SPY','SPDR S&P 500 ETF','etf'],['NVDAB','NVIDIA bStock','bstock'],['WDCB','Western Digital bStock','bstock'],['GMEB','GameStop bStock','bstock'],['CRWDB','CrowdStrike bStock','bstock'],['WEB3','Web3 research adapter','web3'],['NFT','NFT research adapter','nft']
  ].map(([symbol,label,t])=>({type:t,symbol,label,volume:0}))];
  const rows=seed.filter(x=>(type==='all'||x.type===type)&&(!q||x.symbol.includes(q)||x.label.toUpperCase().includes(q))).slice(0,24);
  box.innerHTML=rows.map(x=>`<div class="tradfi-result"><div><strong>${x.symbol}</strong><small>${x.label} · ${x.type.toUpperCase()}${x.volume?` · volume ${x.volume.toLocaleString()}`:''}</small></div><span class="tradfi-status">Research only</span></div>`).join('')||'<div class="empty-state">No research matches. Direct Stocks/ETFs data requires a connected market-data provider; Binance Spot bStocks appear when discovered in the Spot Universe.</div>';
}
function scanBStocks(){if(!universeSymbols.length){$('#tradfiBridgeStatus').innerHTML='<strong>Bridge status:</strong> Load Asset Universe first, then scan bStocks.';return;}const matches=universeSymbols.filter(x=>KNOWN_BSTOCKS.includes(String(x.baseAsset||'').toUpperCase()));$('#tradfiBridgeStatus').innerHTML=`<strong>Bridge status:</strong> ${matches.length} known bStock symbols found in the current Spot Universe.`;renderTradFiResults('B');}
function clearUniverse(){autoProjectPairs=[];clearUniverseCache();universeSymbols=[];exchangeSymbols=[];const btn=$('#discoverAssets');if(btn)btn.textContent='Load all Binance Spot pairs';renderUniverse([]);$('#universeStatus').textContent='Discovered Spot Universe cleared · Personal Watch unchanged';render();}
function renderPairList(){const box=$('#pairList');if(!box)return;box.innerHTML=watchPairs().map(pair=>`<span class="universe-chip"><strong>${pair}</strong><button type="button" class="pair-remove" data-remove-pair="${pair}" aria-label="Remove ${pair}">×</button></span>`).join('')||'<span class="meta">No pairs configured.</span>';}
function savePairList(){settings.watchlist=[...new Set(watchPairs())].join(', ');$('#watchlistInput').value=settings.watchlist;persist();renderPairList();render();if(typeof renderChartPairOptions==='function')renderChartPairOptions(chartState.symbol||'');}
async function addPair(){const input=$('#pairInput'),status=$('#pairStatus');const pair=normalizePair(input.value);if(!pair||!pairParts(pair).symbol){status.textContent='Enter a pair such as BTC/USDT.';return;}try{await discoverUniverse();const ok=universeSymbols.some(x=>x.symbol===pairParts(pair).symbol&&x.status==='TRADING');if(!ok){status.textContent=`${pair} is not currently tradable on Binance Spot.`;return;}const pairs=[...new Set([...watchPairs(),pair])];settings.watchlist=pairs.join(', ');ensureMarket(pair);input.value='';status.textContent=`Added ${pair} to Personal Watch.`;savePairList();}catch(e){status.textContent=`Could not validate ${pair}: ${e.message}`;}}
async function validatePairs(){const status=$('#pairStatus');status.textContent='Validating pairs…';try{const r=await apiFetch('/api/exchange-info',{cache:'no-store'});if(!r.ok)throw Error('Exchange info unavailable');const d=await r.json(),available=new Set((d.symbols||[]).filter(x=>x.status==='TRADING').map(x=>x.symbol));const valid=watchPairs().filter(p=>available.has(pairParts(p).symbol));const removed=watchPairs().filter(p=>!available.has(pairParts(p).symbol));settings.watchlist=valid.join(', ');$('#watchlistInput').value=settings.watchlist;valid.forEach(ensureMarket);savePairList();status.textContent=`${valid.length} valid pairs${removed.length?` · removed ${removed.length} unavailable pair(s)`:''}.`;}catch(e){status.textContent=`Validation failed: ${e.message}`;}}
document.addEventListener('click',e=>{const p=e.target.dataset.removePair;if(p){settings.watchlist=watchPairs().filter(x=>x!==p).join(', ');savePairList();}});
$('#addPair')?.addEventListener('click',addPair);$('#refreshPairs')?.addEventListener('click',validatePairs);$('#universeSearch')?.addEventListener('input',()=>renderUniverse(universeSymbols));$('#addAllMatching')?.addEventListener('click',()=>{const q=String($('#universeSearch')?.value||'').trim().toUpperCase();if(!q){$('#pairStatus').textContent='Enter a search term first. Matching pairs will be added to the AUTO Project Pool.';return;}const matches=universeSymbols.filter(x=>`${x.baseAsset}/${x.quoteAsset}`.includes(q)||x.baseAsset.includes(q)||x.quoteAsset.includes(q));const cap=String(settings.maxProjectPairs).toLowerCase()==='auto' ? Infinity : Math.max(5,Math.min(1000000,Number(settings.maxProjectPairs)||50));autoProjectPairs=[...new Set([...autoProjectPairs,...matches.map(x=>`${x.baseAsset}/${x.quoteAsset}`)])];autoProjectPairs.forEach(ensureMarket);persist();renderPairList();renderUniverse(universeSymbols);render();if(typeof renderChartPairOptions==='function')renderChartPairOptions(chartState.symbol||'');$('#pairStatus').textContent=`Added ${matches.length.toLocaleString()} matching pairs to AUTO Project Pool · ${autoProjectPairs.length.toLocaleString()} stored (no pool cap).`;});document.addEventListener('click',e=>{const p=e.target.dataset.addPair;if(p){const pairs=[...new Set([...watchPairs(),p])];if(pairs.length>20){$('#pairStatus').textContent='Manual watchlist is full (20). Use AUTO Project Pool for larger selections.';return;}settings.watchlist=pairs.join(', ');$('#watchlistInput').value=settings.watchlist;persist();renderPairList();renderUniverse(universeSymbols);render();if(typeof renderChartPairOptions==='function')renderChartPairOptions(chartState.symbol||'');$('#pairStatus').textContent=`Added ${p} to Personal Watch.`;}});
function fillUniverseSettings(){const e=settings.assetUniverse||{};const ids={stable:'universeStable',ai:'universeAI',l1:'universeL1',l2:'universeL2',defi:'universeDeFi',depin:'universeDePIN',rwa:'universeRWA',gaming:'universeGaming',infra:'universeInfra',payments:'universePayments',meme:'universeMeme'};for(const [k,id] of Object.entries(ids)){const el=$('#'+id);if(el)el.checked=!!e[k];}}
function readUniverseSettings(){settings.assetUniverse=universeEnabled();}
document.addEventListener('click',e=>{if(e.target.dataset.trade)openTrade(e.target.dataset.trade);if(e.target.dataset.open==='settings'){fillSettings();$('#settingsDialog').showModal();}if(e.target.id==='openStrategyRiskSettings'){fillSettings();$('#settingsDialog').showModal();}});
$('#runScan').onclick=scan;
$('#runBacktestHero')?.addEventListener('click',()=>{location.hash='#backtestPanel';document.querySelector('#runBacktest')?.click();});
$('#discoverAssets')?.addEventListener('click',discoverUniverse);$('#autoProjectPairs')?.addEventListener('click',addProjectPairs);$('#scanBStocks')?.addEventListener('click',scanBStocks);$('#tradfiSearch')?.addEventListener('input',e=>renderTradFiResults(e.target.value));$('#tradfiType')?.addEventListener('change',()=>renderTradFiResults($('#tradfiSearch')?.value));
$('#clearUniverse')?.addEventListener('click',clearUniverse);
$('#tvImportSignal')?.addEventListener('click',importTradingViewEvidence);$('#ctImportSignal')?.addEventListener('click',importCTraderResult);$('#tvSampleSignal')?.addEventListener('click',()=>{const el=$('#tvSignalInput');if(el){el.value=JSON.stringify({symbol:'BTCUSDT',action:'buy',score:82,confidence:78,timeframe:'4h',strategy:'TV-Pine-Example'},null,2);$('#tvBridgeStatus').textContent='EXAMPLE LOADED · NOT IMPORTED';}});$('#ctSampleSignal')?.addEventListener('click',()=>{const el=$('#ctSignalInput');if(el){el.value=JSON.stringify({symbol:'BTCUSDT',timeframe:'4h',strategy:'cBot Trend Example',trades:120,winRate:58,profitFactor:1.55,maxDrawdown:8.2,expectancy:0.31},null,2);$('#ctBridgeStatus').textContent='EXAMPLE LOADED · NOT IMPORTED';}});
const tradeForm=$('#tradeDialog form');
tradeForm?.addEventListener('submit',e=>{
  if(e.submitter?.value!=='confirm')return;
  e.preventDefault();
  if(!pending)return;
  const safety=safetyStatus();
  if(safety.lossBreached||safety.exposureBreached){addLog('Trade blocked by portfolio safety limits.');return;}
  if(lastEntryAt(pending.symbol)&&Date.now()-lastEntryAt(pending.symbol)<settings.cooldownMinutes*60000){addLog(`Trade blocked: ${pending.coin} is inside cooldown.`);return;}
  const qualifiedNow=currentQualifiedOpportunities();
  const engineQualified=qualifiedNow.some(m=>m.symbol===pending.symbol);
  const indicatorQualified=indicatorScore(pending).qualified;
  if(!engineQualified && !indicatorQualified){addLog(`Simulation allowed only for a qualified signal. ${pending.base}/${pending.quote} is currently WATCH.`);return;}
  if(!engineQualified) addLog(`Simulation note: ${pending.base}/${pending.quote} is indicator-qualified but not yet promoted by the full Opportunity Engine (AI/MTF/Risk).`);
  const capacity=dynamicPositionCapacity(Math.max(qualifiedNow.length,1));
  if(settings.positionMode==='dynamic'&&engineQualified&&capacity<=0){addLog('Trade blocked: no qualified opportunity remains within available capital/exposure.');return;}
  const oo=opportunityScore(pending), cycleMode=cycleModeFor(pending,oo); const amount=Math.min(balance,dynamicPositionAmount(pending,oo));
  if(amount<10){addLog('Trade blocked: insufficient simulated balance.');return;}
  balance-=amount;rollDailyStats();dailyStats.entries++;
  positions.push({coin:pending.base,base:pending.base,quote:pending.quote,symbol:pending.symbol,price:pending.price*(1+settings.slippage/100),entryPrice:pending.price*(1+settings.slippage/100),amount,openedAt:Date.now(),cycleMode,cycles:1,partialTaken:false,trailingStopPct:cycleMode==='TREND CYCLE'?Number(settings.trendCycleTrail||0.7):0});
  persist();addLog(`Simulated purchase: ${pending.base}/${pending.quote} for ${money(amount, pending.quote)}.`);pending=null;$('#tradeDialog')?.close();render();
});
$('#saveSettings').onclick=()=>{readSettings();settings.quoteAssets=[...new Set([settings.quote,...(settings.quoteAssets||[])])];settings.budget=Math.max(25,settings.budget);settings.dailyLossLimit=Math.min(10,Math.max(0.5,settings.dailyLossLimit));settings.maxExposure=Math.min(100,Math.max(10,settings.maxExposure));settings.cooldownMinutes=Math.min(1440,Math.max(0,settings.cooldownMinutes));settings.slippage=Math.min(2,Math.max(0,settings.slippage));if(settings.autoTradeMode==='paper')settings.validationMode='paper';if(settings.autoTradeMode==='off')settings.autoTradeArmed=false;if(settings.autoTradeMode==='live'&&settings.autoTradeArmed){settings.autoTradeArmed=false;addLog('LIVE remains LOCKED in v7.33.2. No real execution gateway is connected.');}if(positions.length===0&&balance<=0)balance=settings.budget;if(balance>settings.budget&&positions.length===0)balance=settings.budget;/* AUTO Project Pool is intentionally uncapped; Candidate Pool controls scan workload. */persist();startAutoReview();render();addLog('Strategy, MTF, validation mode, indicators, risk, AUTO Project Pool, watchlist, and interface settings updated.')};
function fillControlRoom(){
  const ids={crProfile:controlPolicy.profile,crScoreFloor:controlPolicy.scoreFloor,crAiFloor:controlPolicy.aiFloor,crConfidenceFloor:controlPolicy.confidenceFloor,crRiskFloor:controlPolicy.riskFloor,crRrFloor:controlPolicy.rrFloor,crUncertainty:controlPolicy.maxUncertainty,crExternalWeight:controlPolicy.externalWeight,crLearningWeight:controlPolicy.learningWeight};
  for(const [id,v] of Object.entries(ids)){const e=$('#'+id);if(e)e.value=v;} const a=$('#crAbstention');if(a)a.checked=controlPolicy.strictAbstention!==false; renderControlRoom();
}
function renderControlRoom(){
 const e=$('#controlRoomStatus');if(e)e.textContent=String(controlPolicy.profile||'balanced').toUpperCase();
 const tv=$('#crTv');if(tv)tv.textContent=Number(controlPolicy.externalWeight)>0?'LIMITED':'OFF'; const ct=$('#crCt');if(ct)ct.textContent='CHALLENGER';
 const d=$('#crDecision');if(d)d.textContent=controlPolicy.strictAbstention!==false?'CONTROLLED / ABSTAIN':'CONTROLLED';
}
function applyControlRoom(){
 const n=id=>Number($('#'+id)?.value); const profile=$('#crProfile')?.value||'balanced';
 controlPolicy={profile,scoreFloor:Math.max(68,Math.min(95,n('crScoreFloor')||68)),aiFloor:Math.max(68,Math.min(95,n('crAiFloor')||68)),confidenceFloor:Math.max(75,Math.min(95,n('crConfidenceFloor')||75)),riskFloor:Math.max(68,Math.min(95,n('crRiskFloor')||68)),rrFloor:Math.max(1.45,Math.min(4,n('crRrFloor')||1.45)),maxUncertainty:Math.min(42,Math.max(15,n('crUncertainty')||42)),externalWeight:Math.max(0,Math.min(3,n('crExternalWeight')||0)),learningWeight:Math.max(0,Math.min(2,n('crLearningWeight')||0)),strictAbstention:$('#crAbstention')?.checked!==false};
 persistControlPolicy(); renderControlRoom(); render(); addLog(`Control Room policy applied: ${profile.toUpperCase()} · score ${controlPolicy.scoreFloor} · AI ${controlPolicy.aiFloor} · confidence ${controlPolicy.confidenceFloor} · risk ${controlPolicy.riskFloor} · R:R ${controlPolicy.rrFloor}.`);
}
function resetControlRoom(){controlPolicy={...CONTROL_DEFAULT};persistControlPolicy();fillControlRoom();render();addLog('Control Room restored to safe defaults.');}
$('#crApply')?.addEventListener('click',applyControlRoom);$('#crReset')?.addEventListener('click',resetControlRoom);$('#crProfile')?.addEventListener('change',e=>{const d=controlProfileDefaults(e.target.value);for(const [k,v] of Object.entries(d)){controlPolicy[k]=v;}fillControlRoom();});
fillControlRoom();
function renderPrimaryControls(){
  const autoOn=settings.autoSelection!==false;
  const paperOn=settings.autoTradeMode==='paper'&&settings.autoTradeArmed===true;
  const gate=autoTradeRequirements();
  const a=$('#autoEngineButton'),p=$('#paperAutoButton'),l=$('#liveButton'),st=$('#primaryControlStatus');
  if(a){a.classList.toggle('active',autoOn);a.setAttribute('aria-pressed',String(autoOn));a.querySelector('small').textContent=autoOn?'Opportunity Engine ON':'Opportunity Engine OFF';}
  if(p){p.classList.toggle('active',paperOn);p.setAttribute('aria-pressed',String(paperOn));p.querySelector('small').textContent=paperOn?'Armed · virtual only':'OFF · click to arm';}
  if(l){l.classList.add('locked');l.setAttribute('aria-disabled','true');l.title='LIVE is permanently locked in this version; no real order gateway exists.';}
  if(st){const paperState=paperOn?'PAPER AUTO ON':'PAPER AUTO OFF';st.textContent=`AUTO ${autoOn?'ON':'OFF'} · ${paperState} · LIVE LOCKED · Gate ${gate.passed}/${gate.total}`;}
}
function toggleAutoEngine(){settings.autoSelection=!settings.autoSelection;persist();syncOpportunityControls();renderPrimaryControls();render();addLog(`Automatic Opportunity Selection: ${settings.autoSelection?'ON':'OFF'}.`);}
function togglePaperAuto(){
  if(settings.autoTradeMode==='paper'&&settings.autoTradeArmed===true){settings.autoTradeArmed=false;settings.autoTradeMode='off';settings.validationMode='simulation';persist();startAutoReview();render();addLog('PAPER AUTO disarmed. Virtual automatic execution is OFF.');return;}
  settings.autoTradeMode='paper';settings.validationMode='paper';settings.autoTradeArmed=true;persist();startAutoReview();render();const g=autoTradeRequirements();if(g.passed===g.total)addLog('PAPER AUTO armed and all mandatory gates currently pass.');else addLog(`PAPER AUTO armed, but execution is waiting for readiness: ${g.passed}/${g.total} gates pass.`);
}
$('#autoEngineButton')?.addEventListener('click',toggleAutoEngine);
$('#paperAutoButton')?.addEventListener('click',togglePaperAuto);
$('#liveButton')?.addEventListener('click',()=>{addLog('LIVE is LOCKED. This version has no real-order execution gateway.');renderPrimaryControls();});
$('#resetDemo').onclick=()=>{if(confirm('Reset all local simulation data?')){settings=JSON.parse(JSON.stringify(DEFAULT));settings.quoteAssets=[...settings.quoteAssets];autoProjectPairs=[];balance=settings.budget;positions=[];closedTrades=[];localStorage.clear();persist();startAutoReview();addLog('Demo data reset.');render()}};
function applyTheme(mode){
  const light=mode==='light';
  document.body.classList.toggle('light',light);
  localStorage.setItem('lsai-theme',light?'light':'dark');
  const b=$('#themeButton');
  if(b){b.textContent='◐';b.setAttribute('aria-label',light?'التبديل إلى الوضع الليلي':'التبديل إلى الوضع الفاتح');b.title=light?'اضغط ◐ للتبديل إلى الوضع الليلي':'اضغط ◐ للتبديل إلى الوضع الفاتح';}
}
function toggleTheme(){applyTheme(document.body.classList.contains('light')?'dark':'light');}
// v7.14: light mode is the default. Existing users are migrated once from the old theme default;
// after that, only the ◐ button controls the theme and the choice is preserved.
if(localStorage.getItem('lsai-theme-default-v77')!=='1'){localStorage.setItem('lsai-theme','light');localStorage.setItem('lsai-theme-default-v77','1');}
applyTheme(localStorage.getItem('lsai-theme')||'light');
$('#themeButton').onclick=toggleTheme;
// Keyboard shortcut: Ctrl + F8 opens Settings without changing theme or scrolling elsewhere.
document.addEventListener('keydown',e=>{
  if(e.ctrlKey && !e.shiftKey && !e.altKey && e.key==='F8'){
    e.preventDefault();
    const dialog=$('#settingsDialog');
    if(dialog){fillSettings(); if(!dialog.open) dialog.showModal();}
  }
});
/* Interactive market chart: research/simulation visualization only. */
const chartState={candles:[],symbol:'',interval:'4h'};
window.addEventListener('error',e=>{try{addLog(`UI error: ${e.message||'unknown error'}`);}catch{}});
window.addEventListener('unhandledrejection',e=>{try{addLog(`Async error: ${e.reason?.message||String(e.reason||'unknown error')}`);}catch{}});
try{ensureCorePairs();watchPairs().forEach(ensureMarket);renderPairList();renderTradFiResults('');startAutoReview();render();}catch(e){try{addLog(`BOOT ERROR: ${e?.message||String(e)}`);}catch{};console.error('LSAI BOOT ERROR',e);}
function chartContextAt(i){
  const c=chartState.candles; if(!c[i]) return null;
  const ind=settings.indicators, closes=c.map(x=>x.close);
  const e=ind.ema?.enabled?ema(closes,ind.ema.period||20):[];
  const rr=ind.rsi?.enabled?rsi(closes,ind.rsi.period||14):[];
  const mac=ind.macd?.enabled?macd(closes,ind.macd.fast||12,ind.macd.slow||26,ind.macd.signal||9):null;
  const ich=ind.ichimoku?.enabled?ichimoku(c,ind.ichimoku.conversion||9,ind.ichimoku.base||26,ind.ichimoku.spanB||52,ind.ichimoku.displacement||26):null;
  const ut=ind.utbot?.enabled?utBotSignals(c,ind.utbot.keyValue||1,ind.utbot.atrPeriod||10,ind.utbot.source||'close'):null;
  const fr=ind.fractals?.enabled?fractals(c,ind.fractals.lookback||2):null;
  const parts=[];
  if(ind.utbot?.enabled) parts.push(['UT Bot',ut?.signals[i]==='buy',ut?.signals[i]||'neutral']);
  if(ind.ema?.enabled) parts.push(['EMA',e[i]!=null&&c[i].close>e[i],e[i]!=null?`price ${c[i].close>e[i]?'above':'below'} EMA`: 'n/a']);
  if(ind.rsi?.enabled) parts.push(['RSI',rr[i]!=null&&rr[i]<=ind.rsi.threshold,rr[i]!=null?rr[i].toFixed(1):'n/a']);
  if(ind.fractals?.enabled) { const bull=!!fr?.down[i], bear=!!fr?.up[i]; parts.push(['Williams Fractal',bull,!bull&&bear?'bearish':bull?'bullish':'none']); }
  if(ind.macd?.enabled) parts.push(['MACD',mac?.hist[i]!=null&&mac.hist[i]>0,mac?.hist[i]!=null?`hist ${mac.hist[i].toFixed(4)}`:'n/a']);
  if(ind.volume?.enabled) { const n=10, avg=c.slice(Math.max(0,i-n),i).reduce((a,x)=>a+x.volume,0)/Math.max(1,c.slice(Math.max(0,i-n),i).length); parts.push(['Volume',c[i].volume>=avg*(ind.volume.multiplier||1.2),'volume filter']); }
  if(ind.atr?.enabled) parts.push(['ATR',true,'adaptive risk']);
  if(ind.adx?.enabled){const ad=adxDmi(c,ind.adx.period||14),av=ad.adx[i]||0,dir=(ad.pdi[i]||0)>(ad.mdi[i]||0);parts.push(['ADX',av>=(ind.adx.min||18),`${av.toFixed(1)} · ${dir?'bull':'bear'}`]);}
  if(ind.bollinger?.enabled){const bb=bollingerBands(closes,ind.bollinger.period||20,ind.bollinger.multiplier||2),bp=bb.position[i]??50;parts.push(['Bollinger',bp>=35&&bp<=85,`position ${bp.toFixed(0)}%`]);}
  if(ind.ichimoku?.enabled&&ich){const a=ich.spanA[i+ich.displacement],b=ich.spanB[i+ich.displacement],top=Math.max(a??c[i].close,b??c[i].close),bot=Math.min(a??c[i].close,b??c[i].close),t=ich.tenkan[i],k=ich.kijun[i],past=i-ich.displacement,cloudBull=c[i].close>top&&t!=null&&k!=null&&t>k,cloudBear=c[i].close<bot&&t!=null&&k!=null&&t<k,lagOk=past<0||c[i].close>c[past].close;parts.push(['Ichimoku',cloudBull&&lagOk,cloudBull?'bullish cloud':'neutral/bearish']);}
  const score=parts.filter(x=>x[1]).length,total=parts.length,required=Math.min(settings.minSignalScore,total);
  const qualified=total>0&&score>=required;
  let grade=qualified?(score===total&&total>1?'STRONG BUY':'BUY'):(ut?.signals[i]==='sell'?'SELL':'WAIT');
  return {i,bar:c[i],parts,score,total,required,qualified,grade};
}
function showChartContext(i,clientX=null,clientY=null){
  const d=chartContextAt(i); if(!d)return;
  const detail=$('#chartSignalDetail');
  detail.innerHTML=`<strong>${chartState.symbol} · ${d.grade}</strong><span>${new Date(d.bar.openTime).toLocaleString()} · Close ${d.bar.close.toLocaleString(undefined,{maximumFractionDigits:6})}</span><span>${d.score}/${d.total} confirmations · required ${d.required}</span>${d.parts.map(x=>`<span class="ctx-chip ${x[1]?'pass':'fail'}">${x[0]} ${x[1]?'✓':'·'} ${x[2]}</span>`).join('')}`;
  const tip=$('#chartTooltip'); if(tip&&clientX!=null){const wrap=$('.chart-wrap').getBoundingClientRect();tip.style.display='block';tip.style.left=Math.max(5,Math.min(clientX-wrap.left+10,wrap.width-180))+'px';tip.style.top=Math.max(5,Math.min(clientY-wrap.top+10,wrap.height-55))+'px';tip.textContent=`${d.grade} · ${d.score}/${d.total}`;clearTimeout(showChartContext.t);showChartContext.t=setTimeout(()=>tip.style.display='none',3500)}
}
function drawMarketChart(){
  const canvas=$('#marketChart'); if(!canvas||!chartState.candles.length)return;
  const rect=canvas.getBoundingClientRect(), dpr=window.devicePixelRatio||1, w=Math.max(320,rect.width), h=rect.height||360;
  canvas.width=Math.floor(w*dpr); canvas.height=Math.floor(h*dpr); const ctx=canvas.getContext('2d'); if(!ctx)return; ctx.setTransform(dpr,0,0,dpr,0,0); ctx.clearRect(0,0,w,h);
  const c=chartState.candles.slice(-100), closes=c.map(x=>x.close), highs=c.map(x=>x.high), lows=c.map(x=>x.low);
  const emaVals=ema(closes,settings.indicators.ema?.period||20);
  const ut=settings.indicators.utbot?.enabled?utBotSignals(c,settings.indicators.utbot.keyValue||1,settings.indicators.utbot.atrPeriod||10,settings.indicators.utbot.source||'close'):null;
  const fr=settings.indicators.fractals?.enabled?fractals(c,settings.indicators.fractals.lookback||2):null;
  const min=Math.min(...lows), max=Math.max(...highs), pad=(max-min)*.08||1, lo=min-pad, hi=max+pad;
  const left=52,right=12,top=16,bottom=28,plotW=w-left-right,plotH=h-top-bottom;
  const x=i=>left+(i/(c.length-1))*plotW, y=v=>top+(hi-v)/(hi-lo)*plotH;
  ctx.font='11px sans-serif';ctx.fillStyle=getComputedStyle(document.body).getPropertyValue('--muted')||'#888';ctx.strokeStyle=getComputedStyle(document.body).getPropertyValue('--line')||'#333';ctx.lineWidth=1;
  for(let j=0;j<5;j++){const yy=top+j*plotH/4;ctx.beginPath();ctx.moveTo(left,yy);ctx.lineTo(w-right,yy);ctx.stroke();ctx.fillText((hi-(j/4)*(hi-lo)).toLocaleString(undefined,{maximumFractionDigits:2}),4,yy+4)}
  const step=Math.max(3,plotW/c.length*.62);
  c.forEach((bar,i)=>{const xx=x(i),open=y(bar.open),close=y(bar.close),high=y(bar.high),low=y(bar.low),up=bar.close>=bar.open;ctx.strokeStyle=up?'#35c58a':'#ef6b73';ctx.fillStyle=up?'#35c58a':'#ef6b73';ctx.beginPath();ctx.moveTo(xx,high);ctx.lineTo(xx,low);ctx.stroke();const bh=Math.max(1,Math.abs(close-open));ctx.fillRect(xx-step/2,Math.min(open,close),step,bh)});
  function line(values,dash){ctx.beginPath();ctx.setLineDash(dash||[]);values.forEach((v,i)=>{if(v==null)return;const xx=x(i),yy=y(v);if(i===0||values[i-1]==null)ctx.moveTo(xx,yy);else ctx.lineTo(xx,yy)});ctx.stroke();ctx.setLineDash([])}
  ctx.lineWidth=1.6;ctx.strokeStyle='#f2b84b';line(emaVals);
  if(ut){ctx.lineWidth=1.1;ctx.strokeStyle='#8d7cff';line(ut.atr.map((a,i)=>{const price=c[i].close,loss=(settings.indicators.utbot.keyValue||1)*a;return price>0?price-loss:null}),[5,4]);
    c.forEach((bar,i)=>{if(ut.signals[i]==='buy'||ut.signals[i]==='sell'){const yy=y(bar.close),xx=x(i);ctx.fillStyle=ut.signals[i]==='buy'?'#35d49b':'#ff6b7a';ctx.beginPath();ctx.arc(xx,yy,4,0,Math.PI*2);ctx.fill();ctx.font='10px sans-serif';ctx.fillText(ut.signals[i]==='buy'?'BUY':'SELL',xx+6,yy-6)}})}
  if(fr){c.forEach((bar,i)=>{if(fr.up[i]){ctx.fillStyle='#ef6b73';ctx.beginPath();ctx.moveTo(x(i),y(bar.high)-6);ctx.lineTo(x(i)-4,y(bar.high)-1);ctx.lineTo(x(i)+4,y(bar.high)-1);ctx.closePath();ctx.fill()}if(fr.down[i]){ctx.fillStyle='#35c58a';ctx.beginPath();ctx.moveTo(x(i),y(bar.low)+6);ctx.lineTo(x(i)-4,y(bar.low)+1);ctx.lineTo(x(i)+4,y(bar.low)+1);ctx.closePath();ctx.fill()}})}
  ctx.fillStyle=getComputedStyle(document.body).getPropertyValue('--muted')||'#888';ctx.fillText(c[0]?.openTime?new Date(c[0].openTime).toLocaleDateString():'',left,h-7);ctx.fillText(c.at(-1)?.openTime?new Date(c.at(-1).openTime).toLocaleDateString():'',w-right-70,h-7);
  canvas.onclick=(ev)=>{const r=canvas.getBoundingClientRect(), px=ev.clientX-r.left, idx=Math.round(((px-left)/plotW)*(c.length-1));if(idx>=0&&idx<c.length)showChartContext(chartState.candles.length-c.length+idx,ev.clientX,ev.clientY)};
  canvas.onmousemove=(ev)=>{const r=canvas.getBoundingClientRect(),px=ev.clientX-r.left,idx=Math.round(((px-left)/plotW)*(c.length-1));if(idx>=0&&idx<c.length){const d=chartContextAt(chartState.candles.length-c.length+idx);canvas.title=`${new Date(d.bar.openTime).toLocaleString()} · ${d.grade} · ${d.score}/${d.total}`}};
}
function normalizeCandleRows(rows){
  return (rows||[]).map(x=>Array.isArray(x)?({openTime:x[0],open:Number(x[1]),high:Number(x[2]),low:Number(x[3]),close:Number(x[4]),volume:Number(x[5]),closeTime:x[6]}):x).filter(x=>Number.isFinite(x.open)&&Number.isFinite(x.high)&&Number.isFinite(x.low)&&Number.isFinite(x.close));
}
const CHART_CACHE_KEY='lsai-chart-cache-v2';
function chartCacheRead(symbol,interval){try{const x=JSON.parse(localStorage.getItem(CHART_CACHE_KEY)||'{}');const row=x[`${symbol}_${interval}`];return row&&Array.isArray(row.candles)&&row.candles.length>=30?row:null;}catch{return null;}}
function chartCacheWrite(symbol,interval,candles,source){try{const x=JSON.parse(localStorage.getItem(CHART_CACHE_KEY)||'{}');x[`${symbol}_${interval}`]={at:Date.now(),source,candles:candles.slice(-500)};const keys=Object.keys(x);while(keys.length>8){delete x[keys.shift()];}localStorage.setItem(CHART_CACHE_KEY,JSON.stringify(x));}catch{}}
async function fetchWithTimeout(url,options={},ms=10000){const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),ms);try{return await fetch(url,{...options,signal:controller.signal});}finally{clearTimeout(timer);}}
async function fetchChartCandles(symbol,interval,limit=180){
  const qs=`symbol=${encodeURIComponent(symbol)}&interval=${encodeURIComponent(interval)}&limit=${limit}`;
  const errors=[];
  // Same-origin Worker first: avoids browser CORS restrictions and guarantees the deployed
  // application uses the same Spot data contract as the scanner.
  try{
    const r=await apiFetch(`/api/candles?${qs}`,{cache:'no-store',headers:{accept:'application/json'},retryAttempts:2});
    const d=await r.json().catch(()=>({}));
    if(r.ok&&Array.isArray(d.candles)&&d.candles.length>=30){
      const candles=normalizeCandleRows(d.candles);chartCacheWrite(symbol,interval,candles,d.source||'LOODY’S Spot API');
      return {symbol,interval,source:d.source||'LOODY’S Spot API',candles};
    }
    errors.push(`Worker API ${r.status}${d.error?`: ${d.error}`:''}`);
  }catch(e){errors.push(`Worker API: ${e.message}`)}
  // Public Binance mirrors are fallback sources. They are useful for a standalone/PWA build,
  // but some browsers or networks block cross-origin market-data requests.
  for(const base of ['https://data-api.binance.vision','https://api.binance.com','https://api1.binance.com']){
    try{
      const r=await fetchWithTimeout(`${base}/api/v3/klines?${qs}`,{cache:'no-store',headers:{accept:'application/json'}},9000);
      const rows=await r.json().catch(()=>[]); const candles=normalizeCandleRows(rows);
      if(r.ok&&candles.length>=30){chartCacheWrite(symbol,interval,candles,'Binance Spot public market data');return {symbol,interval,source:'Binance Spot public market data',candles};}
      errors.push(`${new URL(base).hostname} ${r.status}${rows?.msg?`: ${rows.msg}`:''}`);
    }catch(e){errors.push(`${new URL(base).hostname}: ${e.name==='AbortError'?'timeout':e.message}`)}
  }
  const cached=chartCacheRead(symbol,interval);
  if(cached)return {symbol,interval,source:`Cached Spot candles · ${new Date(cached.at).toLocaleString()}`,candles:normalizeCandleRows(cached.candles)};
  throw new Error(`No Spot candle source available (${errors.join(' · ')})`);
}
async function loadChart(symbol=(chartState.symbol||($('#chartSymbol')?.value||watchPairs()[0]||'')),interval=(chartState.interval||$('#chartInterval').value||settings.timeframe)){
  if(!symbol){$('#chartStatus').textContent='Add a Spot pair to display its chart.';return;}
  chartState.symbol=normalizePair(symbol);chartState.interval=interval;$('#chartTitle').textContent=`${chartState.symbol} analysis`;$('#chartStatus').textContent='Loading live Spot candles…';
  try{
    const data=await fetchChartCandles(pairParts(chartState.symbol).symbol,interval,180);
    chartState.candles=data.candles;
    drawMarketChart();
    const last=data.candles.at(-1);
    const closes=data.candles.map(c=>c.close);
    const rv=rsi(closes,settings.indicators.rsi?.period||14).at(-1);
    const ut=settings.indicators.utbot?.enabled?utBotSignals(data.candles,settings.indicators.utbot.keyValue||1,settings.indicators.utbot.atrPeriod||10,settings.indicators.utbot.source||'close'):null;
    const fr=settings.indicators.fractals?.enabled?fractals(data.candles,settings.indicators.fractals.lookback||2):null;
    const utSig=ut?.signals.at(-1)||'neutral';
    const fractalSig=fr?.down.at(-1)?'bullish fractal':fr?.up.at(-1)?'bearish fractal':'none';
    $('#chartStatus').textContent=`${data.source} · Last ${last.close.toLocaleString(undefined,{maximumFractionDigits:8})} · RSI ${rv!=null?rv.toFixed(1):'—'} · UT Bot ${utSig.toUpperCase()} · ${fractalSig}`;
  }catch(e){
    chartState.candles=[];
    const canvas=$('#marketChart');if(canvas){const ctx=canvas.getContext('2d');ctx.clearRect(0,0,canvas.width,canvas.height);}
    $('#chartStatus').textContent=`Chart unavailable — ${e?.message||'Spot data could not be loaded'}`;
  }
}

let chartBound=false;
function chartUniversePairs(){
  const source=Array.isArray(universeSymbols)&&universeSymbols.length?universeSymbols:watchPairs().map(pair=>{const {base,quote,symbol}=pairParts(pair);return {baseAsset:base,quoteAsset:quote,symbol,status:'TRADING'};});
  return [...new Set(source.filter(x=>x&&x.status==='TRADING').map(x=>`${x.baseAsset}/${x.quoteAsset}`))].sort();
}
let chartUniverseRenderKey='';
let chartSearchTimer=null;
function renderChartPairOptions(filter=''){
  const select=$('#chartSymbol'); if(!select)return;
  const all=chartUniversePairs();
  const q=String(filter||'').trim().toUpperCase();
  const matches=q?all.filter(x=>x.includes(q)):all;
  const previous=chartState.symbol&&matches.includes(chartState.symbol)?chartState.symbol:(matches[0]||chartState.symbol||'BTC/USDT');
  // Keep the selector usable even with the full Binance Spot universe; search narrows it instantly.
  select.innerHTML=matches.map(x=>`<option value="${x}">${x}</option>`).join('')||'<option value="">No matching Spot pair</option>';
  // v7.27.1: the native datalist is intentionally not populated with 1,000+ pairs.
  // It produced confusing browser suggestions while the real chart selector stayed unchanged.
  select.value=previous;
  chartState.symbol=previous;
  const search=$('#chartPairSearch');
  // Do not overwrite the user's query while typing. This was the main reason
  // the chart search felt broken: every input event immediately replaced the text
  // with the first matching pair. Only selection/change/Enter commits a pair.
  if(search && !q && document.activeElement!==search) search.value=previous;
  return matches;
}
function initChart(){
  const select=$('#chartSymbol'); if(!select)return;
  ensureCorePairs();
  const all=chartUniversePairs();
  const previous=chartState.symbol&&all.includes(chartState.symbol)?chartState.symbol:(all[0]||'BTC/USDT');
  renderChartPairOptions('');
  chartState.symbol=previous; chartState.interval=settings.timeframe;
  $('#chartInterval').value=settings.timeframe; select.value=previous;
  const search=$('#chartPairSearch');
  if(search && !search.dataset.bound){
    search.addEventListener('input',()=>{
      // Local filtering first. Exact base symbols (BTC, ETH, BNB...) commit automatically;
      // partial queries only narrow the selector and never trigger network calls.
      const raw=String(search.value||'').trim().toUpperCase();
      const all=chartUniversePairs();
      renderChartPairOptions(raw);
      clearTimeout(chartSearchTimer);
      if(raw && !raw.includes('/')){
        const exact=all.find(x=>x.startsWith(raw+'/'));
        if(exact){
          chartSearchTimer=setTimeout(()=>{
            if(String(search.value||'').trim().toUpperCase()===raw){
              search.value=exact;
              renderChartPairOptions(exact);
              loadChart(exact,$('#chartInterval').value);
            }
          },350);
        }
      }
    });
    const commitChartSearch=()=>{
      const all=chartUniversePairs(), raw=String(search.value||'').trim().toUpperCase();
      const normalized=normalizePair(raw);
      const p=all.includes(normalized)?normalized:(raw&&!raw.includes('/')?all.find(x=>x.startsWith(raw+'/')):'');
      if(p){
        search.value=p; renderChartPairOptions(p); loadChart(p,$('#chartInterval').value);
      } else {
        $('#chartStatus').textContent='Choose a valid Binance Spot pair from the matches, e.g. BTC/USDT.';
      }
    };
    search.addEventListener('change',commitChartSearch);
    search.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();commitChartSearch();}});
    search.dataset.bound='1';
  }
  if(!chartBound){
    select.addEventListener('change',()=>{const p=select.value; if(p){if(search)search.value=p;loadChart(p,$('#chartInterval').value);}});
    $('#chartInterval').addEventListener('change',()=>loadChart(select.value,$('#chartInterval').value));
    $('#refreshChart').addEventListener('click',()=>loadChart(select.value,$('#chartInterval').value));
    chartBound=true;
  }
  if(chartState.symbol && !chartState.candles.length) loadChart(chartState.symbol,chartState.interval);
}
window.addEventListener('resize',()=>{if(chartState.candles.length)drawMarketChart()});


const ASSET_LEARNING_QUEUE_KEY='lsai-asset-learning-queue-v2';let assetLearningInFlight=false;
function assetLearningQueue(){try{const q=JSON.parse(localStorage.getItem(ASSET_LEARNING_QUEUE_KEY)||'[]');return Array.isArray(q)?q:[]}catch{return []}}
function saveAssetLearningQueue(q){try{localStorage.setItem(ASSET_LEARNING_QUEUE_KEY,JSON.stringify([...new Set(q.map(normalizePair).filter(Boolean))].slice(0,10000)))}catch{}}
function queueUniverseForLearning(pairs){const existing=assetLearningQueue(),fresh=[...existing,...pairs.map(normalizePair).filter(Boolean)];const adaptive=assetAdaptiveStore(),now=Date.now();const filtered=fresh.filter(pair=>{const p=adaptive[normalizePair(pair)];if(p&&Number(p.updatedAt||0)>now-30*86400000&&p.selectedTimeframe&&p.selectedStrategy)return false;if(p&&p.status==='INSUFFICIENT_HISTORY'&&Number(p.retryAfter||0)>now)return false;return true});saveAssetLearningQueue(filtered);return filtered}
async function runHistoricalLearningQueue(limit=1){
  if(assetLearningInFlight||!universeSymbols.length)return;assetLearningInFlight=true;
  try{let q=assetLearningQueue();let done=0;while(q.length&&done<Math.max(1,limit)){const pair=q.shift();try{const sym=pairParts(pair).symbol;const market=markets.find(x=>x.symbol===sym)||{};await learnAssetAdaptiveProfile(pair,market,365);done++;}catch(e){const msg=e.message||String(e);if(/365|history|candles|insufficient/i.test(msg)){const store=assetAdaptiveStore();store[normalizePair(pair)]={...(store[normalizePair(pair)]||{}),status:'INSUFFICIENT_HISTORY',historyCoverageDays:Number(store[normalizePair(pair)]?.historyCoverageDays||0),updatedAt:Date.now(),retryAfter:Date.now()+30*86400000,error:msg};saveAssetAdaptiveStore(store);}addLog(`Adaptive historical learning skipped ${pair}: ${msg}`)}await new Promise(r=>setTimeout(r,150));}saveAssetLearningQueue(q);const st=$('#assetLearningStatus');if(st&&done)st.textContent=`QUEUE · ${q.length} left`;}finally{assetLearningInFlight=false}}
async function runCurrentAssetLearning(){
  const pair=$('#chartSymbol')?.value||chartState.symbol||chosenPair();
  const tf=$('#chartInterval')?.value||settings.timeframe||'4h';
  const status=$('#assetLearningStatus'),info=$('#assetLearningInfo');
  if(status)status.textContent='LEARNING…';if(info)info.textContent=`جارٍ اختبار ${pair} على ${tf} لمدة 365 يومًا على الأقل…`;
  try{const st=await learnAssetStrategies(pair,tf,365);if(status)status.textContent=`READY · ${STRATEGY_CATALOG[st.winner]?.label||st.winner}`;if(info)info.textContent=`تم حفظ الملف الخاص بـ ${pair} · ${tf}. confidence ${Number(st.confidence||0).toFixed(0)}%.`;addLog(`Per-asset learning complete: ${pair} · ${STRATEGY_CATALOG[st.winner]?.label||st.winner} · ${st.days}d.`);render();}catch(e){if(status)status.textContent='FAILED';if(info)info.textContent=e.message||String(e);addLog(`Per-asset learning failed: ${pair} · ${e.message||e}`);}}
async function runSelectedAssetLearning(){
  const pairs=[...new Set((selectedOpportunities.length?selectedOpportunities:qualifiedOpportunities).slice(0,5).map(normalizePair).filter(Boolean))];
  if(!pairs.length){$('#assetLearningInfo').textContent='لا توجد فرص مختارة حاليًا. شغّل Scan أولًا.';return;}
  const status=$('#assetLearningStatus');if(status)status.textContent=`0/${pairs.length}`;
  for(let i=0;i<pairs.length;i++){if(status)status.textContent=`${i}/${pairs.length} LEARNING…`;try{const sym=pairParts(pairs[i]).symbol;const tick=(markets.find(x=>x.symbol===sym)||{});if(settings.timeframeMode==='auto') await learnAssetAdaptiveProfile(pairs[i],tick,365); else await learnAssetStrategies(pairs[i],settings.timeframe||'4h',365)}catch(e){addLog(`Asset learning skipped ${pairs[i]}: ${e.message||e}`)}await new Promise(r=>setTimeout(r,150));}
  if(status)status.textContent=`DONE · ${pairs.length}`;$('#assetLearningInfo').textContent=`تم تحديث ملفات ${pairs.length} أزواج.`;render();
}
$('#runAssetLearning')?.addEventListener('click',runCurrentAssetLearning);
$('#runAssetLearningBatch')?.addEventListener('click',runSelectedAssetLearning);
$('#runAssetLearningAuto')?.addEventListener('click',()=>{if(universeSymbols.length){queueUniverseForLearning(universeSymbols.map(x=>`${x.baseAsset}/${x.quoteAsset}`));$('#assetLearningStatus').textContent=`QUEUED · ${assetLearningQueue().length}`;$('#assetLearningInfo').textContent='AUTO learning queue enabled: one pair per review cycle to respect public API limits.';runHistoricalLearningQueue(1).catch(()=>{});}else{$('#assetLearningInfo').textContent='Load Binance Spot universe first.';}});

function runArchitectureAudit(){
  const issues=[],allowed=['1m','3m','5m','15m','30m','1h','2h','4h','6h','8h','12h','1d','3d','1w','1M'];
  if(!['auto','manual'].includes(settings.timeframeMode))issues.push('Invalid timeframe mode');
  if(!allowed.includes(settings.timeframe))issues.push('Invalid manual timeframe');
  if(!Array.isArray(settings.confirmationTimeframes)||settings.confirmationTimeframes.some(x=>!allowed.includes(x)))issues.push('Invalid MTF confirmation timeframe');
  if(!Array.isArray(ADAPTIVE_TIMEFRAMES)||!ADAPTIVE_TIMEFRAMES.every(x=>allowed.includes(x)))issues.push('Adaptive timeframe registry mismatch');
  if(settings.timeframeMode==='auto'&&settings.maxOpenPositions!==null)issues.push('AUTO position capacity conflict');
  if(Number(settings.maxExposure||0)>50)issues.push('Exposure exceeds safety ceiling');
  if(typeof engineQualified!=='function'||typeof opportunityScore!=='function'||typeof selectAdaptiveTimeframe!=='function'||typeof learnAssetAdaptiveProfile!=='function'||typeof strategyIndicatorConfig!=='function'||!STRATEGY_PARAMETER_CATALOG||Object.keys(STRATEGY_PARAMETER_CATALOG).length<6||!STRATEGY_EXECUTION_CATALOG||Object.keys(STRATEGY_EXECUTION_CATALOG).length<6)issues.push('Core adaptive engine missing');
  if(settings.autoTradeMode==='live'&&settings.autoTradeArmed)issues.push('LIVE armed request detected; it must remain locked');
  const status=issues.length?'FAIL':'PASS';try{localStorage.setItem('lsai-architecture-audit-v1',JSON.stringify({version:APP_VERSION,at:Date.now(),status,issues}))}catch{}
  addLog(issues.length?`Architecture audit: FAIL · ${issues.join(' | ')}`:`Architecture audit: PASS · v${APP_VERSION} · adaptive TF/OOS/MTF/risk/auto-trade locks consistent.`);return {status,issues};
}

/* v7.59.0 — Autonomous Policy / Model Revalidation Engine.
   Recovery recommendations must earn their way back through historical/OOS/holdout
   evidence plus the latest global robustness checks. Revalidation is bounded and
   queued; it never lowers hard safety gates or authorizes live orders. */
const REVALIDATION_VERSION='lsai-autonomous-revalidation-v1';
const REVALIDATION_DEFAULT={enabled:true,minHistoryDays:365,minTrades:20,minOosWinRate:50,minPF:1.10,maxDD:20,minConfidence:60,cooldownHours:24,maxQueue:100,maxEntries:300};
function revalidationStore(){try{return {...REVALIDATION_DEFAULT,...JSON.parse(localStorage.getItem(REVALIDATION_VERSION)||'{}')}}catch{return {...REVALIDATION_DEFAULT,queue:[],entries:[]}}}
function saveRevalidationStore(x){try{x.queue=(x.queue||[]).slice(-Number(x.maxQueue||100));x.entries=(x.entries||[]).slice(-Number(x.maxEntries||300));x.updatedAt=Date.now();localStorage.setItem(REVALIDATION_VERSION,JSON.stringify(x))}catch{}}
function revalidationKey(pair,tf,strategy,variant){return [normalizePair(pair),tf||'AUTO',strategy||'AUTO',variant||'BASE'].join('|')}
function queuePolicyRevalidation(pair,tf,strategy,variant,reason='recovery'){
  if(!pair)return false;const st=revalidationStore(),key=revalidationKey(pair,tf,strategy,variant),now=Date.now();
  const recent=(st.entries||[]).slice().reverse().find(x=>x.key===key);
  if(recent&&now-Number(recent.at||0)<Number(st.cooldownHours||24)*3600000)return false;
  if((st.queue||[]).some(x=>x.key===key))return false;
  st.queue=Array.isArray(st.queue)?st.queue:[];st.queue.push({key,pair:normalizePair(pair),timeframe:tf||'AUTO',strategy:strategy||'AUTO',variant:variant||'BASE',reason,queuedAt:now});saveRevalidationStore(st);return true;
}
function latestValidationHealth(){const st=backgroundStamp(),keys=['backtest','walkForward','walkBackward','stress','monteCarlo'];const rows=keys.map(k=>({key:k,status:st[k]?.status||'UNKNOWN',at:Number(st[k]?.at||0)}));const fresh=rows.filter(x=>x.status==='PASSED'&&Date.now()-x.at<=48*3600000);return {rows,freshCount:fresh.length,robust:fresh.length>=3&&['walkForward','stress','monteCarlo'].every(k=>st[k]?.status==='PASSED')};}
function revalidationEvaluateResult(state,strategy,variant){
  if(!state)return {pass:false,score:0,reason:'history unavailable'};
  const cfg=revalidationStore(), rows=Array.isArray(state.results)?state.results:[], exact=rows.find(x=>x.id===strategy&&String(x.variant||'BASE')===String(variant||'BASE'))||rows.find(x=>x.id===strategy);
  if(!exact)return {pass:false,score:0,reason:'candidate not present in historical learning result'};
  const history=Number(state.historyCoverageDays||0),trades=Number(exact.trades||0),oosWin=Number(exact.oosWinRate||0),pf=Number(exact.oosPF||0),dd=Number(exact.oosDD||100),hold=Number(exact.holdoutNet||-Infinity),robust=!!exact.oosRobust;
  const score=clamp((history>=cfg.minHistoryDays?20:0)+(trades>=cfg.minTrades?15:0)+(robust?20:0)+(oosWin>=cfg.minOosWinRate?15:0)+(pf>=cfg.minPF?10:0)+(dd<=cfg.maxDD?10:0)+(hold>=0?10:0),0,100);
  const pass=history>=cfg.minHistoryDays&&trades>=cfg.minTrades&&robust&&oosWin>=cfg.minOosWinRate&&pf>=cfg.minPF&&dd<=cfg.maxDD&&hold>=0&&score>=cfg.minConfidence;
  return {pass,score,history,trades,oosWin,pf,dd,hold,robust,reason:pass?'candidate passed historical/OOS/holdout checks':'candidate failed one or more historical/OOS/holdout checks'};
}
async function runPolicyRevalidation(){
  const st=revalidationStore(); if(st.enabled===false)return {status:'DISABLED'};
  const item=st.queue?.[0]; if(!item)return {status:'IDLE',queue:0};
  st.queue=st.queue.slice(1); saveRevalidationStore(st);
  let state=null,error='';
  try{
    const existing=learnedStrategyFor(item.pair,item.timeframe);
    if(existing&&Number(existing.historyCoverageDays||0)>=365&&Array.isArray(existing.results))state=existing;
    else state=await learnAssetStrategies(item.pair,item.timeframe,365);
  }catch(e){error=String(e?.message||e)}
  const hist=revalidationEvaluateResult(state,item.strategy,item.variant), health=latestValidationHealth();
  const finalPass=!!hist.pass&&health.robust;
  const entry={at:Date.now(),key:item.key,pair:item.pair,timeframe:item.timeframe,strategy:item.strategy,variant:item.variant,reason:item.reason,historical:hist,validation:health,pass:finalPass,status:finalPass?'PROMOTE_READY':(hist.pass?'HOLD_GLOBAL_VALIDATION':'REJECT'),error};
  const out=revalidationStore();out.entries=Array.isArray(out.entries)?out.entries:[];out.entries.push(entry);saveRevalidationStore(out);
  addLog(`Policy revalidation ${item.pair} ${item.timeframe} · ${item.strategy} · ${entry.status}.`);
  return entry;
}
function renderRevalidationPanel(){
  const host=$('#bgRevalidationMount .background-mount');if(!host)return;let box=$('#autonomousRevalidationPanel');if(!box){box=document.createElement('section');box.id='autonomousRevalidationPanel';box.className='panel autonomous-revalidation-panel';host.appendChild(box)}
  const st=revalidationStore(), last=(st.entries||[]).slice().reverse().slice(0,10), health=latestValidationHealth();
  box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">AUTONOMOUS POLICY / MODEL REVALIDATION</p><h2>إعادة التحقق الذاتي للسياسات والنماذج</h2><p class="muted">أي استراتيجية يقترحها Recovery تدخل طابور تحقق محدود. لا تصبح مرشحًا نشطًا إلا بعد اجتياز التاريخ وOOS وHoldout مع سلامة اختبارات Walk-Forward / Stress / Monte Carlo الأخيرة.</p></div><span class="tag">${st.enabled?'AUTO':'OFF'}</span></div><div class="performance-results"><article><span>Queue</span><strong>${st.queue?.length||0}</strong><small>revalidation jobs</small></article><article><span>Last result</span><strong>${last[0]?.status||'—'}</strong><small>${last[0]?.pair||'لا يوجد'}</small></article><article><span>Global robustness</span><strong>${health.robust?'PASS':'WAIT'}</strong><small>${health.freshCount}/5 checks fresh</small></article><article><span>Promote-ready</span><strong>${last.filter(x=>x.status==='PROMOTE_READY').length}</strong><small>recent results</small></article></div><div class="table-wrap"><table><thead><tr><th>Pair</th><th>TF</th><th>Strategy</th><th>Score</th><th>OOS</th><th>Holdout</th><th>Global</th><th>Status</th></tr></thead><tbody>${last.map(x=>`<tr><td>${escapeHTML(x.pair||'—')}</td><td>${escapeHTML(x.timeframe||'—')}</td><td>${escapeHTML(x.strategy||'—')}</td><td>${Number(x.historical?.score||0).toFixed(0)}</td><td>${x.historical?.robust?'PASS':'FAIL'}</td><td>${Number(x.historical?.hold||-1)<0?'FAIL':'PASS'}</td><td>${x.validation?.robust?'PASS':'WAIT'}</td><td>${escapeHTML(x.status||'—')}</td></tr>`).join('')||'<tr><td colspan="8">لا توجد نتائج إعادة تحقق بعد.</td></tr>'}</tbody></table></div><div class="audit-detail"><strong>قاعدة الترقية:</strong> التاريخ ≥ ${st.minHistoryDays} يومًا · Trades ≥ ${st.minTrades} · OOS Robust · OOS WR ≥ ${st.minOosWinRate}% · PF ≥ ${st.minPF} · DD ≤ ${st.maxDD}% · Holdout ≥ 0 · Global robustness PASS. لا توجد أي صلاحية لتجاوز Safety Gates.</div>`;
}
function revalidationRecoveryHook(){
  const rs=recoveryStore();const last=(rs.entries||[]).slice().reverse().slice(0,8);let n=0;
  for(const r of last){if(r.action==='STRATEGY_RECOVERY'&&r.recommendedStrategy&&queuePolicyRevalidation(r.symbol,r.timeframe,r.recommendedStrategy,r.recommendedVariant||'BASE','recovery'))n++;}
  return n;
}

/* v7.34.1 BOT BRAIN / BACKGROUND ORCHESTRATOR */
const BACKGROUND_VERSION='lsai-background-orchestrator-v2';
const BACKGROUND_DEFAULT={enabled:true,cycleMinutes:5,learningPerCycle:1,validationCooldownHours:24,externalSyncMinutes:1,priorityMode:'adaptive',autoRecovery:true};
let backgroundState=(()=>{try{return {...BACKGROUND_DEFAULT,...JSON.parse(localStorage.getItem(BACKGROUND_VERSION)||'{}')}}catch{return {...BACKGROUND_DEFAULT}}})();
let backgroundBusy=false,backgroundTimer=null,backgroundExternalTimer=null;
const GOVERNANCE_GATE_VERSION='lsai-autonomous-governance-gate-v1';
const GOVERNANCE_GATE_DEFAULT={enabled:true,minEvidence:8,maxRecoveryInfluence:4,requireGlobalValidation:true,blockCriticalDrift:true};
function governanceGateStore(){try{return {...GOVERNANCE_GATE_DEFAULT,...JSON.parse(localStorage.getItem(GOVERNANCE_GATE_VERSION)||'{}')}}catch{return {...GOVERNANCE_GATE_DEFAULT}}}
function governanceGateEvaluate(){const g=governanceGateStore(), d=typeof updateDriftLedger==='function'?updateDriftLedger():null, r=typeof revalidationStore==='function'?revalidationStore():{entries:[]}, rec=typeof recoveryStore==='function'?recoveryStore():{entries:[]}; const critical=Boolean(d&&d.overall&&d.overall.severity==='CRITICAL'); const last=(r.entries||[]).slice().reverse(); const promote=last.find(x=>x.status==='PROMOTE_READY'); const recentRecovery=(rec.entries||[]).slice().reverse()[0]||null; let status='HOLD',reason='الأدلة غير كافية أو لا توجد سياسة مرشحة.'; if(g.blockCriticalDrift&&critical){status='BLOCKED';reason='انجراف حرج: الترقية والاستعادة التلقائية متوقفتان مؤقتًا.'} else if(promote&&(!g.requireGlobalValidation||promote.validation?.robust)){status='PROMOTE_READY';reason='المرشح اجتاز إعادة التحقق العالمية والضوابط الحالية.'} else if(recentRecovery){status='RECOVERY_PENDING';reason='تم اقتراح استعادة، لكن يلزم اجتياز إعادة التحقق قبل اعتمادها.'} return {status,reason,critical,promote:promote||null,recentRecovery,updatedAt:Date.now()};}
function renderGovernanceGatePanel(){const host=document.querySelector('#bgGovernanceGateMount .background-mount');if(!host)return;let box=document.querySelector('#autonomousGovernanceGatePanel');if(!box){box=document.createElement('section');box.id='autonomousGovernanceGatePanel';box.className='panel governance-gate-panel';host.appendChild(box)}const g=governanceGateStore(),e=governanceGateEvaluate();box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">AUTONOMOUS GOVERNANCE GATE</p><h2>بوابة الحوكمة الذاتية</h2><p class="muted">طبقة نهائية تفصل بين التعلم والاعتماد: Drift → Recovery → Revalidation → Promotion. لا تخفض بوابات السلامة ولا تمنح صلاحية تداول حقيقي.</p></div><span class="tag">${e.status}</span></div><div class="performance-results"><article><span>Gate status</span><strong>${e.status}</strong><small>${e.critical?'Critical drift detected':'No critical drift'}</small></article><article><span>Candidate</span><strong>${e.promote?.pair||'—'}</strong><small>${e.promote?.strategy||'لا يوجد'}</small></article><article><span>Recovery</span><strong>${e.recentRecovery?.action||'—'}</strong><small>${e.recentRecovery?.symbol||'لا يوجد'}</small></article><article><span>Global validation</span><strong>${e.promote?.validation?.robust?'PASS':'WAIT'}</strong><small>mandatory before promotion</small></article></div><div class="audit-detail"><strong>القرار:</strong> ${escapeHTML(e.reason)} <br><strong>الحدود:</strong> Critical Drift = Block · Global Validation = ${g.requireGlobalValidation?'Required':'Optional'} · Recovery influence ≤ ${Number(g.maxRecoveryInfluence||4).toFixed(1)}.</div>`}
const EXPERIMENT_LAB_VERSION='lsai-autonomous-experiment-lab-v1';
const EXPERIMENT_LAB_DEFAULT={enabled:true,maxExperiments:6,minEvidence:12,maxInfluence:.04,cooldownHours:24};
function experimentLabStore(){try{return {...EXPERIMENT_LAB_DEFAULT,...JSON.parse(localStorage.getItem(EXPERIMENT_LAB_VERSION)||'{}')}}catch{return {...EXPERIMENT_LAB_DEFAULT}}}
function experimentLabLedger(){try{return JSON.parse(localStorage.getItem('lsai-experiment-lab-ledger-v1')||'[]')}catch{return []}}
function saveExperimentLabLedger(x){try{localStorage.setItem('lsai-experiment-lab-ledger-v1',JSON.stringify(x.slice(-100)))}catch{}}
function runAutonomousExperimentLab(){const cfg=experimentLabStore();if(!cfg.enabled||!Array.isArray(markets)||!markets.length)return {tested:0};const now=Date.now(),ledger=experimentLabLedger();const candidates=[];for(const m of markets.filter(x=>x?.candles?.length).slice(0,24)){let o;try{o=opportunityScore(m)}catch{continue}const current=Number(o?.score||0);const rows=Object.entries(STRATEGY_CATALOG||{}).map(([key,prof])=>{const prior=typeof strategyPolicyPrior==='function'?strategyPolicyPrior({strategy:key}):{};const hist=Number(prior?.score||prior?.confidence||0);const fit=Number(m?.strategyFit||0);return {strategy:key,label:prof?.label||key,score:Math.max(0,Math.min(100,current*.72+hist*.18+fit*.10))}}).sort((a,b)=>b.score-a.score);const best=rows[0];if(!best)continue;const delta=best.score-current;if(delta<3)continue;candidates.push({symbol:`${m.base}/${m.quote}`,timeframe:m.timeframe||'AUTO',regime:m.regime||m.marketRegime||'UNKNOWN',currentScore:Number(current.toFixed(2)),challenger:best,delta:Number(delta.toFixed(2)),at:now,status:'SHADOW_ONLY'});}
const out=candidates.sort((a,b)=>b.delta-a.delta).slice(0,Number(cfg.maxExperiments)||6);saveExperimentLabLedger([...ledger,...out]);if(out.length)addLog(`Experiment Lab: ${out.length} bounded challenger experiments queued in SHADOW_ONLY mode.`);return {tested:out.length,candidates:out};}
function renderExperimentLabPanel(){const host=document.querySelector('#bgExperimentMount .background-mount');if(!host)return;let box=document.querySelector('#experimentLabPanel');if(!box){box=document.createElement('section');box.id='experimentLabPanel';box.className='panel';host.appendChild(box)}const cfg=experimentLabStore(),rows=experimentLabLedger().slice().reverse().slice(0,12);box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">AUTONOMOUS EXPERIMENT LAB</p><h2>مختبر التجارب الذاتية</h2><p class="muted">يجرب النظام بدائل محدودة في وضع SHADOW فقط. لا يتم اعتماد أي تغيير مباشرة؛ النتائج يجب أن تمر عبر Revalidation ثم Governance.</p></div><span class="tag">${cfg.enabled?'AUTO':'PAUSED'}</span></div><div class="performance-results"><article><span>Experiments</span><strong>${rows.length}</strong><small>Bounded local ledger</small></article><article><span>Max / cycle</span><strong>${Number(cfg.maxExperiments||6)}</strong><small>Safe experiment cap</small></article><article><span>Influence cap</span><strong>${Number(cfg.maxInfluence||.04).toFixed(2)}</strong><small>No direct gate impact</small></article><article><span>Mode</span><strong>SHADOW</strong><small>Promotion requires revalidation</small></article></div><div class="table-wrap"><table><thead><tr><th>Symbol</th><th>TF / Regime</th><th>Current</th><th>Challenger</th><th>Delta</th><th>Status</th></tr></thead><tbody>${rows.map(x=>`<tr><td>${escapeHTML(x.symbol)}</td><td>${escapeHTML(x.timeframe)} / ${escapeHTML(x.regime)}</td><td>${x.currentScore}</td><td>${escapeHTML(x.challenger?.label||x.challenger?.strategy||'—')} · ${Number(x.challenger?.score||0).toFixed(1)}</td><td>+${Number(x.delta||0).toFixed(1)}</td><td>${escapeHTML(x.status||'SHADOW_ONLY')}</td></tr>`).join('')||'<tr><td colspan="6">لا توجد تجارب بعد. سيبدأ المختبر تلقائيًا مع دورة الخلفية التالية.</td></tr>'}</tbody></table></div>`}


/* v7.66.0 — AGI Causal Attribution Engine. Bounded observational/counterfactual attribution; not a proof of causality. */
const CAUSAL_ATTR_VERSION='lsai-agi-causal-attribution-v1';
const CAUSAL_ATTR_DEFAULT={enabled:true,maxEntries:800,minResolved:12,maxInfluence:0.025,ablationStep:8};
function causalAttributionStore(){try{return {...CAUSAL_ATTR_DEFAULT,...JSON.parse(localStorage.getItem(CAUSAL_ATTR_VERSION)||'{}')}}catch{return {...CAUSAL_ATTR_DEFAULT,entries:[]}}}
function saveCausalAttributionStore(x){try{x.entries=(x.entries||[]).slice(-Number(x.maxEntries||800));x.updatedAt=Date.now();localStorage.setItem(CAUSAL_ATTR_VERSION,JSON.stringify(x))}catch{}}
function causalFactorVector(a){const u=Number(a?.uncertainty||0);return [
 {key:'score',label:'Opportunity Score',value:clamp(Number(a?.score||0),0,100),direction:1},
 {key:'ai',label:'AI Consensus',value:clamp(Number(a?.ai||a?.aiConsensus||0),0,100),direction:1},
 {key:'confidence',label:'Decision Confidence',value:clamp(Number(a?.confidence||0),0,100),direction:1},
 {key:'data',label:'Data Quality',value:clamp(Number(a?.dataQuality||0),0,100),direction:1},
 {key:'risk',label:'Risk Score',value:clamp(Number(a?.risk||a?.riskScore||0),0,100),direction:1},
 {key:'rr',label:'Reward / Risk',value:clamp(Number(a?.rr||a?.rewardRisk||0)*40,0,100),direction:1},
 {key:'mtf',label:'MTF Alignment',value:clamp(Number(a?.mtf||0),0,100),direction:1},
 {key:'strategy',label:'Strategy Agreement',value:clamp(Number(a?.strategyVotes||0)*50,0,100),direction:1},
 {key:'fusion',label:'Context Fusion',value:clamp(Number(a?.fusion?.score||0),0,100),direction:1},
 {key:'policy',label:'Policy Learning',value:clamp(Number(a?.learning?.policyScore||a?.policyScore||0),0,100),direction:1},
 {key:'uncertainty',label:'Uncertainty',value:clamp(u,0,100),direction:-1}
];}
function causalAttributionForAudit(audit,outcome,source){
 if(!audit||!Number.isFinite(Number(outcome)))return null;
 const ret=Number(outcome),win=ret>0, factors=causalFactorVector(audit), decision=['BEST','STRONG'].includes(String(audit.decision||'').toUpperCase()), expected=decision?1:0;
 const baseline=clamp(Number(audit.confidence||0)*.4+Number(audit.score||0)*.3+Number(audit.ai||audit.aiConsensus||0)*.15+Number(audit.risk||a.riskScore||0)*.15,0,100);
 const rows=factors.map(f=>{
   const signed=(f.direction===1?f.value:100-f.value); const centered=(signed-50)/50;
   const ablated=clamp(baseline-(centered*Number(causalAttributionStore().ablationStep||8)),0,100);
   const observedEdge=(win?1:-1)*centered;
   return {...f,normalized:signed,observedEdge,ablationDelta:baseline-ablated};
 }).sort((a,b)=>Math.abs(b.observedEdge)-Math.abs(a.observedEdge));
 const dominant=rows.slice(0,5).map(x=>({factor:x.key,label:x.label,score:Number(x.observedEdge.toFixed(4)),ablationDelta:Number(x.ablationDelta.toFixed(2))}));
 return {id:`${audit.id}|${source}|${Date.now()}`,auditId:audit.id,at:Date.now(),symbol:audit.symbol,timeframe:audit.timeframe,strategy:audit.strategy,regime:audit.regime,decision:audit.decision,realizedPct:ret,win,source,baselineScore:Number(baseline.toFixed(2)),dominant,allFactors:rows.map(x=>({factor:x.key,label:x.label,score:Number(x.observedEdge.toFixed(4)),ablationDelta:Number(x.ablationDelta.toFixed(2))})),fragility:rows.slice(0,3).reduce((n,x)=>n+Math.abs(x.ablationDelta),0),expectedDirection:expected};
}
function runCausalAttribution(){const st=causalAttributionStore();if(st.enabled===false)return {processed:0,added:0};const existing=new Set((st.entries||[]).map(x=>x.id));const outcomes=[];shadowLedger().filter(x=>x.resolved&&Number.isFinite(Number(x.realizedPct))).forEach(r=>outcomes.push({r,source:'shadow',outcome:r.realizedPct}));paperLedger().filter(x=>x.status==='CLOSED'&&Number.isFinite(Number(x.pnlPct))).forEach(r=>outcomes.push({r,source:'paper',outcome:r.pnlPct}));let added=0,processed=0;for(const x of outcomes){const audit=decisionAttributionFindAudit(x.r);if(!audit)continue;processed++;const id=`${audit.id}|${x.source}`;if([...existing].some(k=>k.startsWith(id)))continue;const row=causalAttributionForAudit(audit,x.outcome,x.source);if(row){st.entries.push(row);existing.add(row.id);added++;}}saveCausalAttributionStore(st);return {processed,added,entries:st.entries.length};}
function causalAttributionSummary(){const rows=causalAttributionStore().entries||[];const factor={};for(const r of rows){for(const f of r.allFactors||[]){factor[f.factor] ||= {factor:f.factor,label:f.label,n:0,sum:0,abs:0,ablation:0};const q=factor[f.factor];q.n++;q.sum+=Number(f.score||0);q.abs+=Math.abs(Number(f.score||0));q.ablation+=Number(f.ablationDelta||0);}}const top=Object.values(factor).map(x=>({...x,avg:x.n?x.sum/x.n:0,avgAbs:x.n?x.abs/x.n:0,avgAblation:x.n?x.ablation/x.n:0})).sort((a,b)=>b.avgAbs-a.avgAbs).slice(0,10);return {resolved:rows.length,wins:rows.filter(x=>x.win).length,top};}
function renderCausalAttributionPanel(){const host=$('#bgCausalMount .background-mount');if(!host)return;let box=$('#causalAttributionPanel');if(!box){box=document.createElement('section');box.id='causalAttributionPanel';box.className='panel causal-attribution-panel';host.appendChild(box)}const run=runCausalAttribution(),s=causalAttributionSummary(),rows=(causalAttributionStore().entries||[]).slice().reverse().slice(0,10);box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">AGI CAUSAL ATTRIBUTION</p><h2>محرك نَسب العوامل والاختبار المضاد</h2><p class="muted">يحلل ما العوامل الأكثر ارتباطًا بنجاح أو فشل القرار، ويستخدم إزالة العامل (ablation) لقياس هشاشة القرار. هذه Attribution استدلالية وليست إثباتًا سببيًا علميًا.</p></div><span class="tag">${s.resolved} RESOLVED</span></div><div class="performance-results"><article><span>Resolved decisions</span><strong>${s.resolved}</strong><small>Shadow / Paper linked</small></article><article><span>Top factor</span><strong>${escapeHTML(s.top[0]?.label||'—')}</strong><small>${s.top[0]?Number(s.top[0].avgAbs).toFixed(3):'—'} avg directional contribution</small></article><article><span>Average ablation</span><strong>${s.top.length?Number(s.top.reduce((a,x)=>a+Number(x.avgAblation||0),0)/s.top.length).toFixed(2):'—'}</strong><small>counterfactual sensitivity</small></article><article><span>New links</span><strong>${run.added}</strong><small>this cycle</small></article></div><div class="table-wrap"><table><thead><tr><th>Factor</th><th>Avg contribution</th><th>Avg |impact|</th><th>Ablation</th><th>Evidence</th></tr></thead><tbody>${s.top.map(x=>`<tr><td>${escapeHTML(x.label)}</td><td>${x.avg>=0?'+':''}${Number(x.avg).toFixed(3)}</td><td>${Number(x.avgAbs).toFixed(3)}</td><td>${Number(x.avgAblation).toFixed(2)}</td><td>${x.n}</td></tr>`).join('')||'<tr><td colspan="5">لا توجد نتائج كافية بعد. سيبدأ الربط تلقائيًا بعد إغلاق نتائج Shadow/Paper.</td></tr>'}</tbody></table></div><div class="table-wrap"><table><thead><tr><th>Pair</th><th>Decision</th><th>Outcome</th><th>Dominant factor</th><th>Fragility</th></tr></thead><tbody>${rows.map(x=>`<tr><td>${escapeHTML(x.symbol||'—')}</td><td>${escapeHTML(x.decision||'—')}</td><td>${Number(x.realizedPct||0).toFixed(2)}%</td><td>${escapeHTML(x.dominant?.[0]?.label||'—')}</td><td>${Number(x.fragility||0).toFixed(2)}</td></tr>`).join('')||'<tr><td colspan="5">لا يوجد سجل Attribution بعد.</td></tr>'}</tbody></table></div><p class="meta">لا يتم تعديل القرارات السابقة. نتائج Attribution تدخل البحث والتعلم المستقبلي فقط ضمن حدود التأثير الآمنة.</p>`}

/* v7.68.0 — AGI Self-Improvement Loop. Chooses the next bounded research action from observed evidence; never changes safety gates directly. */
const AGI_SELF_IMPROVE_VERSION='lsai-agi-self-improvement-v1';
const AGI_SELF_IMPROVE_DEFAULT={enabled:true,maxActions:5,minPriority:55,maxInfluence:.03};
function agiSelfImprovementStore(){try{return {...AGI_SELF_IMPROVE_DEFAULT,...JSON.parse(localStorage.getItem(AGI_SELF_IMPROVE_VERSION)||'{}')}}catch{return {...AGI_SELF_IMPROVE_DEFAULT,ledger:[]}}}
function saveAgiSelfImprovementStore(x){try{x.ledger=(x.ledger||[]).slice(-250);x.updatedAt=Date.now();localStorage.setItem(AGI_SELF_IMPROVE_VERSION,JSON.stringify(x))}catch{}}
function agiSelfImprovementContext(x){return [x.symbol||'GLOBAL',x.timeframe||'AUTO',x.strategy||'AUTO',x.regime||'UNKNOWN'].join('|')}
function agiSelfImprovementRun(){const cfg=agiSelfImprovementStore();if(cfg.enabled===false)return {actions:0};const st=driftStore?.()||{};const ca=causalAttributionSummary?.()||{resolved:0,top:[]};const exp=experimentLabLedger?.()||[];const rec=recoveryStore?.().entries||[];const rv=(typeof autonomousRevalidationStore==='function'?autonomousRevalidationStore():{})||{};const actions=[];
  if(Number(ca.resolved||0)>=5&&ca.top?.[0])actions.push({type:'CAUSAL_FOLLOWUP',priority:Math.min(95,60+Math.abs(Number(ca.top[0].avgAblation||0))*5),reason:`اختبار أثر العامل ${ca.top[0].label}`,context:'GLOBAL',route:'AGI Research → Experiment Lab'});
  const critical=Number(st?.lastOverall?.delta||0)<-.12 || Number(st?.overall?.delta||0)<-.12;
  if(critical)actions.push({type:'DRIFT_RECOVERY',priority:92,reason:'إعادة اختبار السياسة المتأثرة بالانجراف',context:'GLOBAL',route:'Drift → Recovery → Revalidation'});
  if(Array.isArray(rec)&&rec.length)actions.push({type:'RECOVERY_REVALIDATION',priority:88,reason:'إعادة تحقق من آخر مرشح Recovery',context:agiSelfImprovementContext(rec[rec.length-1]||{}),route:'Recovery → Revalidation → Governance'});
  const pending=Object.values(rv||{}).filter?.(x=>x&&typeof x==='object'&&String(x.status||'').includes('HOLD'))?.length||0;
  if(pending)actions.push({type:'REVALIDATION_RETRY',priority:82,reason:`مراجعة ${pending} حالات Revalidation معلقة`,context:'GLOBAL',route:'Revalidation'});
  if(Array.isArray(exp)&&exp.length)actions.push({type:'EXPERIMENT_FOLLOWUP',priority:76,reason:'تحليل أفضل Challenger من Experiment Lab',context:agiSelfImprovementContext(exp[exp.length-1]||{}),route:'Experiment Lab → Revalidation'});
  if(!actions.length)actions.push({type:'EVIDENCE_REFRESH',priority:60,reason:'جمع أدلة جديدة قبل اقتراح تغيير',context:'GLOBAL',route:'Evidence Center → Adaptive Weighting'});
  const uniq=[],seen=new Set();for(const a of actions.sort((a,b)=>b.priority-a.priority)){if(a.priority<Number(cfg.minPriority||55))continue;const k=a.type+'|'+a.context;if(seen.has(k))continue;seen.add(k);uniq.push({...a,id:`asi-${Date.now()}-${uniq.length}`,at:Date.now(),status:'QUEUED_SHADOW_ONLY'});if(uniq.length>=Number(cfg.maxActions||5))break}
  const store=agiSelfImprovementStore();const prior=store.ledger||[];saveAgiSelfImprovementStore({...store,ledger:[...prior,...uniq]});return {actions:uniq.length,items:uniq};}
function agiSelfImprovementSummary(){const rows=(agiSelfImprovementStore().ledger||[]);const counts={};rows.forEach(x=>counts[x.type]=(counts[x.type]||0)+1);return {total:rows.length,queued:rows.filter(x=>x.status==='QUEUED_SHADOW_ONLY').length,types:counts,recent:rows.slice(-10).reverse()};}
function renderAgiSelfImprovementPanel(){const host=$('#bgSelfImproveMount .background-mount');if(!host)return;let box=$('#agiSelfImprovementPanel');if(!box){box=document.createElement('section');box.id='agiSelfImprovementPanel';box.className='panel';host.appendChild(box)}const run=agiSelfImprovementRun(),s=agiSelfImprovementSummary();box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">AGI SELF-IMPROVEMENT LOOP</p><h2>حلقة التحسين الذاتي الموجّهة بالأدلة</h2><p class="muted">يحدد AGI ما الذي يستحق البحث أو الاختبار بعد ذلك اعتمادًا على Attribution وDrift وRecovery وExperiment وRevalidation. لا يغيّر بوابات السلامة مباشرة.</p></div><span class="tag">${run.actions} NEW</span></div><div class="performance-results"><article><span>Total actions</span><strong>${s.total}</strong><small>bounded research ledger</small></article><article><span>Queued</span><strong>${s.queued}</strong><small>SHADOW ONLY</small></article><article><span>Max / cycle</span><strong>${Number(agiSelfImprovementStore().maxActions||5)}</strong><small>safe cap</small></article><article><span>Influence cap</span><strong>${Number(agiSelfImprovementStore().maxInfluence||.03).toFixed(2)}</strong><small>no direct gate impact</small></article></div><div class="table-wrap"><table><thead><tr><th>Priority</th><th>Action</th><th>Reason</th><th>Context</th><th>Route</th><th>Status</th></tr></thead><tbody>${s.recent.map(x=>`<tr><td>${Number(x.priority||0)}</td><td>${escapeHTML(x.type)}</td><td>${escapeHTML(x.reason)}</td><td>${escapeHTML(x.context)}</td><td>${escapeHTML(x.route)}</td><td>${escapeHTML(x.status)}</td></tr>`).join('')||'<tr><td colspan="6">لا توجد إجراءات بحثية بعد.</td></tr>'}</tbody></table></div><p class="meta">التحسين الذاتي يولد أولويات وتجارب فقط. أي تغيير يمر عبر Experiment Lab → Revalidation → Governance.</p>`}


/* v7.68.0 — AGI Memory & Knowledge Graph. Contextual memory built from existing local ledgers; bounded, explainable, no direct trading authority. */
const AGI_KG_VERSION='lsai-agi-knowledge-graph-v1';
const AGI_KG_DEFAULT={enabled:true,maxNodes:1800,maxEdges:5000,minEvidence:2,updatedAt:0};
function agiKnowledgeStore(){try{return {...AGI_KG_DEFAULT,...JSON.parse(localStorage.getItem(AGI_KG_VERSION)||'{}')}}catch{return {...AGI_KG_DEFAULT,nodes:{},edges:{}}}}
function saveAgiKnowledgeStore(x){try{const ns=Object.values(x.nodes||{}).slice(-Number(x.maxNodes||1800));const es=Object.values(x.edges||{}).slice(-Number(x.maxEdges||5000));x.nodes=Object.fromEntries(ns.map(n=>[n.id,n]));x.edges=Object.fromEntries(es.map(e=>[e.id,e]));x.updatedAt=Date.now();localStorage.setItem(AGI_KG_VERSION,JSON.stringify(x))}catch{}}
function kgId(type,key){return `kg:${type}:${String(key||'unknown').toLowerCase().replace(/[^a-z0-9:_./-]+/g,'_').slice(0,180)}`}
function kgNode(store,type,key,attrs={}){const id=kgId(type,key),old=store.nodes[id]||{id,type,key,evidence:0,firstSeen:Date.now()};store.nodes[id]={...old,...attrs,id,type,key,evidence:Number(old.evidence||0)+1,lastSeen:Date.now()};return id}
function kgEdge(store,a,b,type,weight=1,attrs={}){if(!a||!b||a===b)return;const id=`${a}|${type}|${b}`;const old=store.edges[id]||{id,from:a,to:b,type,weight:0,evidence:0};store.edges[id]={...old,weight:Number(old.weight||0)+Number(weight||1),evidence:Number(old.evidence||0)+1,lastSeen:Date.now(),...attrs}}
function agiKnowledgeIngest(){
  const st=agiKnowledgeStore(); if(st.enabled===false)return {nodes:0,edges:0};
  const add=(symbol,tf,strategy,regime,source,outcome,decision,confidence)=>{
    if(!symbol)return;
    const a=kgNode(st,'asset',symbol,{label:symbol}),t=kgNode(st,'timeframe',tf||'AUTO',{label:tf||'AUTO'}),r=kgNode(st,'regime',regime||'UNKNOWN',{label:regime||'UNKNOWN'}),s=kgNode(st,'strategy',strategy||'UNKNOWN',{label:strategy||'UNKNOWN'}),src=kgNode(st,'source',source||'core',{label:source||'core'});
    kgEdge(st,a,t,'USES_TIMEFRAME');kgEdge(st,a,r,'SEEN_IN_REGIME');kgEdge(st,a,s,'USES_STRATEGY');kgEdge(st,s,r,'PERFORMS_IN_REGIME');kgEdge(st,src,a,'EVIDENCE_FOR');
    if(decision)kgNode(st,'decision',`${symbol}|${tf||'AUTO'}|${decision}`,{label:decision,confidence:Number(confidence||0)});
    if(outcome!==undefined&&outcome!==null){const o=Number(outcome);kgNode(st,'outcome',`${symbol}|${tf||'AUTO'}|${o>=0?'WIN':'LOSS'}`,{label:o>=0?'WIN':'LOSS'});kgEdge(st,s,kgId('outcome',`${symbol}|${tf||'AUTO'}|${o>=0?'WIN':'LOSS'}`),'OUTCOME',Math.min(3,Math.max(.25,Math.abs(o)/5||.5)));kgEdge(st,src,kgId('outcome',`${symbol}|${tf||'AUTO'}|${o>=0?'WIN':'LOSS'}`),'OUTCOME_EVIDENCE',.5)}
  };
  const audit=(()=>{try{return JSON.parse(localStorage.getItem('lsai-decision-audit-v1')||'{}').entries||[]}catch{return []}})();
  audit.slice(-500).forEach(x=>add(x.symbol,x.timeframe||x.tf,x.strategy,x.regime,'core',x.realizedPct,x.decision,x.confidence));
  const uni=(()=>{try{return JSON.parse(localStorage.getItem('lsai-universal-evidence-v1')||'[]')}catch{return []}})();
  uni.slice(-500).forEach(x=>add(x.symbol,x.timeframe,x.strategy,x.regime,String(x.source||'external').toLowerCase(),x.realizedPct,x.action||x.decision,x.confidence||x.score));
  const pol=(()=>{try{return JSON.parse(localStorage.getItem('lsai-strategy-policy-learning-v1')||'{}')}catch{return {}}})();
  Object.values(pol.contexts||{}).slice(-300).forEach(c=>{const parts=String(c.key||'').split('|');add(parts[0],parts[1],parts[2],parts[3],'policy',undefined,undefined,c.weight)});
  saveAgiKnowledgeStore(st);return {nodes:Object.keys(st.nodes).length,edges:Object.keys(st.edges).length};
}
function agiKnowledgeRelated(symbol,tf,strategy,regime){const st=agiKnowledgeStore(),a=st.nodes[kgId('asset',symbol)];if(!a)return[];const ids=new Set([a.id]);const out=[];Object.values(st.edges||{}).forEach(e=>{if(e.from===a.id||e.to===a.id){ids.add(e.from);ids.add(e.to);out.push(e)}});const nodes=Object.values(st.nodes||{}).filter(n=>ids.has(n.id));return {nodes,edges:out,contexts:nodes.filter(n=>['timeframe','regime','strategy','source','outcome'].includes(n.type)).slice(0,20)}}
function agiKnowledgeContextScore(m,o){const rel=agiKnowledgeRelated(m?.symbol||o?.symbol,m?.timeframe||o?.timeframe,o?.assetStrategy||o?.strategy,m?.regime||m?.marketRegime);const outcomes=(rel?.nodes||[]).filter(n=>n.type==='outcome');const wins=outcomes.filter(n=>String(n.label)==='WIN').length,losses=outcomes.filter(n=>String(n.label)==='LOSS').length,samples=wins+losses;return {score:samples?clamp(50+(wins-losses)/Math.max(1,samples)*50,0,100):50,samples}}
function agiKnowledgeSummary(){const st=agiKnowledgeStore(),nodes=Object.values(st.nodes||{}),edges=Object.values(st.edges||{});const counts={};nodes.forEach(n=>counts[n.type]=(counts[n.type]||0)+1);const topAssets=nodes.filter(n=>n.type==='asset').sort((a,b)=>b.evidence-a.evidence).slice(0,8);return {nodes:nodes.length,edges:edges.length,counts,topAssets,updatedAt:st.updatedAt}}
function renderAgiKnowledgeGraphPanel(){const host=$('#bgKnowledgeMount .background-mount');if(!host)return;let box=$('#agiKnowledgeGraphPanel');if(!box){box=document.createElement('section');box.id='agiKnowledgeGraphPanel';box.className='panel agi-knowledge-panel';host.appendChild(box)}const run=agiKnowledgeIngest(),s=agiKnowledgeSummary();const top=s.topAssets.map(n=>`<tr><td>${escapeHTML(n.label||n.key)}</td><td>${n.evidence}</td><td>${(agiKnowledgeRelated(n.key,'','','')?.contexts||[]).filter(x=>x.type==='strategy').map(x=>escapeHTML(x.label)).slice(0,3).join(', ')||'—'}</td></tr>`).join('');box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">AGI MEMORY &amp; KNOWLEDGE GRAPH</p><h2>ذاكرة AGI السياقية وشبكة المعرفة</h2><p class="muted">يربط المعرفة الموجودة عبر العملة والإطار والاستراتيجية وRegime ومصادر الأدلة والنتائج. الذاكرة للاستدلال والبحث فقط ولا تملك صلاحية تجاوز بوابات السلامة.</p></div><span class="tag">${run.nodes} NODES</span></div><div class="performance-results"><article><span>Knowledge nodes</span><strong>${s.nodes}</strong><small>contextual memory</small></article><article><span>Knowledge edges</span><strong>${s.edges}</strong><small>relationships</small></article><article><span>Assets</span><strong>${s.counts.asset||0}</strong><small>observed symbols</small></article><article><span>Outcomes</span><strong>${s.counts.outcome||0}</strong><small>WIN / LOSS memory</small></article></div><div class="table-wrap"><table><thead><tr><th>Asset</th><th>Evidence</th><th>Known strategies</th></tr></thead><tbody>${top||'<tr><td colspan="3">لا توجد ذاكرة كافية بعد. ستُبنى تلقائيًا من سجلات القرارات والأدلة والنتائج.</td></tr>'}</tbody></table></div><p class="meta">تُستخدم الذاكرة كـcontext retrieval للـAGI. أي تأثير مستقبلي يبقى محدودًا ويمر عبر Validation وGovernance.</p>`}

const BG_TASKS={
  external:{priority:100,cooldown:60000,label:'External Evidence'},
  universe:{priority:95,cooldown:12*3600000,label:'Spot Universe'},
  scan:{priority:90,cooldown:0,label:'Opportunity Scan'},
  learning:{priority:80,cooldown:0,label:'Historical Learning'},
  backtest:{priority:70,cooldown:24*3600000,label:'Backtest'},
  walkForward:{priority:68,cooldown:24*3600000,label:'Walk-Forward'},
  walkBackward:{priority:67,cooldown:24*3600000,label:'Walk-Backward'},
  stress:{priority:66,cooldown:24*3600000,label:'Stress Test'},
  monteCarlo:{priority:65,cooldown:24*3600000,label:'Monte Carlo'},
  paper:{priority:60,cooldown:0,label:'Paper Ledger'},
  readiness:{priority:55,cooldown:0,label:'Readiness'},
  architecture:{priority:50,cooldown:0,label:'Architecture Audit'},
  autoOpen:{priority:45,cooldown:0,label:'Paper Auto Execution'},
  agi:{priority:92,cooldown:0,label:'AGI Decision Supervisor'},
  policyArena:{priority:58,cooldown:24*3600000,label:'Policy Validation Arena'},
  decisionAudit:{priority:52,cooldown:0,label:'Decision Replay & Audit'},
  decisionAttribution:{priority:51,cooldown:0,label:'Decision Quality Attribution'},
  governanceGate:{priority:54,cooldown:0,label:'Autonomous Governance Gate'},
  drift:{priority:50,cooldown:0,label:'Policy / Model Drift Monitor'},
  recovery:{priority:49,cooldown:0,label:'Adaptive Recovery Engine'},
  revalidation:{priority:48,cooldown:24*3600000,label:'Autonomous Policy Revalidation'},
  experimentLab:{priority:47,cooldown:24*3600000,label:'Autonomous Experiment Lab'},
  agiResearch:{priority:46,cooldown:12*3600000,label:'AGI Autonomous Research'},
  causalAttribution:{priority:44,cooldown:0,label:'AGI Causal Attribution'},
  agiSelfImprovement:{priority:43,cooldown:0,label:'AGI Self-Improvement'},
  agiKnowledge:{priority:42,cooldown:0,label:'AGI Memory & Knowledge Graph'}
};
function saveBackgroundState(){try{localStorage.setItem(BACKGROUND_VERSION,JSON.stringify(backgroundState))}catch{}}
function backgroundStamp(){try{return JSON.parse(localStorage.getItem('lsai-background-task-ledger-v2')||'{}')}catch{return {}}}
function saveBackgroundStamp(x){try{localStorage.setItem('lsai-background-task-ledger-v2',JSON.stringify(x))}catch{}}
function backgroundTaskFresh(key){const st=backgroundStamp(),last=Number(st[key]?.at||0),cd=Number(st[key]?.cooldown||BG_TASKS[key]?.cooldown||0);return last>0&&Date.now()-last<cd}
function backgroundTaskState(key,status,extra={}){const st=backgroundStamp();st[key]={at:Date.now(),status,...extra};saveBackgroundStamp(st);return st[key]}
function backgroundStatus(text,phase){const a=$('#bgOrchestratorStatus');if(a)a.textContent=text;if(phase){const p=$('#bgOrchestratorPhase');if(p)p.textContent=phase}const n=$('#bgNextCycle');if(n)n.textContent=`التالي: ${new Date(Date.now()+Number(backgroundState.cycleMinutes||5)*60000).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}`;}
function backgroundMetric(){const e=$('#bgOrchestratorMetrics');if(!e)return;const q=typeof currentQualifiedOpportunities==='function'?currentQualifiedOpportunities().length:0;const queue=typeof assetLearningQueue==='function'?assetLearningQueue().length:0;const paper=typeof paperStats==='function'?paperStats():{};const st=backgroundStamp();const failures=Object.values(st).filter(x=>x?.status==='FAILED').length;e.innerHTML=`<article><span>Qualified</span><strong>${q}</strong></article><article><span>Learning queue</span><strong>${queue}</strong></article><article><span>Paper closed</span><strong>${Number(paper.closed||0)}</strong></article><article><span>Failed tasks</span><strong>${failures}</strong></article><article><span>Mode</span><strong>${backgroundState.enabled?'AUTO':'PAUSED'}</strong></article>`;}
async function backgroundRunTask(key,fn){if(typeof fn!=='function')return false;if(backgroundTaskFresh(key))return false;backgroundTaskState(key,'RUNNING');try{await fn();backgroundTaskState(key,'PASSED');return true}catch(e){backgroundTaskState(key,'FAILED',{error:String(e?.message||e)});addLog(`Background ${key} failed: ${e?.message||e}`);if(!backgroundState.autoRecovery)throw e;return false}}
async function backgroundRunValidationSuite(){
  const jobs=[['backtest','runBacktest'],['walkForward','runWalkForward'],['walkBackward','runWalkBackward'],['stress','runStressTest'],['monteCarlo','runMonteCarlo']];
  for(const [key,id] of jobs){if(backgroundTaskFresh(key))continue;const fn=window[id];if(typeof fn!=='function')continue;backgroundStatus('RUNNING',BG_TASKS[key].label);await backgroundRunTask(key,fn);await new Promise(r=>setTimeout(r,250));}
  await backgroundRunTask('readiness',async()=>{if(typeof renderReadiness==='function')renderReadiness();});
}
async function backgroundRunCycle(){
 if(backgroundBusy||!backgroundState.enabled)return;
 backgroundBusy=true;
 try{
   backgroundStatus('RUNNING','External Evidence');await backgroundRunTask('external',()=>syncExternalBridgeFeeds());
   if(typeof discoverUniverse==='function'&&(!universeSymbols.length||Date.now()-Number(window._lsaiBgUniverse||0)>12*3600000)){backgroundStatus('RUNNING',BG_TASKS.universe.label);await backgroundRunTask('universe',async()=>{await discoverUniverse();window._lsaiBgUniverse=Date.now();});}
   if(settings.autoSelection&&universeSymbols.length&&!scanInFlight){backgroundStatus('RUNNING',BG_TASKS.scan.label);await backgroundRunTask('scan',()=>scan());}
   backgroundStatus('RUNNING',BG_TASKS.agi.label);await backgroundRunTask('governanceGate',async()=>{renderGovernanceGatePanel();return governanceGateEvaluate();});await backgroundRunTask('agi',async()=>{const extLearn=agiLearnFromExternalSources();markets.slice(0,Math.min(markets.length,Number(backgroundState.learningPerCycle||1)*20)).forEach(m=>{try{opportunityScore(m)}catch{}});renderAGIPanel();if(extLearn)addLog(`AGI fast learning: ${extLearn} external evidence records assimilated from TradingView/cTrader and the internal evidence stack.`);});
   if(universeSymbols.length){queueUniverseForLearning(universeSymbols.map(x=>`${x.baseAsset}/${x.quoteAsset}`));backgroundStatus('RUNNING',BG_TASKS.learning.label);await runHistoricalLearningQueue(Number(backgroundState.learningPerCycle||1)).catch(e=>addLog(`Background learning failed: ${e.message||e}`));}
   backgroundStatus('RUNNING','Validation Suite');await backgroundRunValidationSuite();
   await backgroundRunTask('paper',async()=>{if(typeof updatePaperLedger==='function')updatePaperLedger();});
   await backgroundRunTask('policyArena',async()=>{const r=policyArenaRun();if(r?.contexts)addLog(`Policy Arena: ${r.contexts} contexts · ${r.eligible} promotion candidates.`);renderPolicyValidationArena();});
   await backgroundRunTask('decisionAudit',async()=>{renderDecisionAuditPanel();});
   await backgroundRunTask('drift',async()=>{updateDriftLedger();renderDriftMonitorPanel();});
   await backgroundRunTask('recovery',async()=>{revalidationRecoveryHook();renderAdaptiveRecoveryPanel();});
   await backgroundRunTask('revalidation',async()=>{await runPolicyRevalidation();renderRevalidationPanel();});
   await backgroundRunTask('experimentLab',async()=>{runAutonomousExperimentLab();renderExperimentLabPanel();});
   await backgroundRunTask('agiResearch',async()=>{agiGenerateHypotheses();renderAGIResearchPanel();});
   await backgroundRunTask('causalAttribution',async()=>{const r=runCausalAttribution();renderCausalAttributionPanel();if(r.added)addLog(`AGI Causal Attribution: linked ${r.added} resolved decisions to factor attribution.`);});
  await backgroundRunTask('agiSelfImprovement',async()=>{const r=agiSelfImprovementRun();renderAgiSelfImprovementPanel();if(r.actions)addLog(`AGI Self-Improvement: queued ${r.actions} bounded research actions.`);});
  await backgroundRunTask('agiKnowledge',async()=>{const r=agiKnowledgeIngest();renderAgiKnowledgeGraphPanel();if(r.nodes)addLog(`AGI Knowledge Graph: ${r.nodes} nodes / ${r.edges} relationships refreshed.`);});
   await backgroundRunTask('decisionAttribution',async()=>{decisionAttributionRun();renderDecisionAttributionPanel();});
   await backgroundRunTask('architecture',async()=>{if(typeof runArchitectureAudit==='function')runArchitectureAudit();});
   await backgroundRunTask('autoOpen',async()=>{if(typeof autoOpenQualified==='function')autoOpenQualified();});
   backgroundStatus('READY','Cycle complete');backgroundMetric();backgroundTaskState('cycle','PASSED');
 }catch(e){backgroundTaskState('cycle','FAILED',{error:String(e?.message||e)});addLog(`Background orchestrator error: ${e?.message||e}`);backgroundStatus('ERROR',e?.message||'unknown');}
 finally{backgroundBusy=false;saveBackgroundStamp(backgroundStamp());}
}
function startBackgroundOrchestrator(){clearInterval(backgroundTimer);clearInterval(backgroundExternalTimer);if(!backgroundState.enabled)return;backgroundRunCycle().catch(()=>{});backgroundTimer=setInterval(()=>backgroundRunCycle().catch(()=>{}),Math.max(1,Number(backgroundState.cycleMinutes||5))*60000);backgroundExternalTimer=setInterval(()=>{if(backgroundState.enabled&&!backgroundBusy)syncExternalBridgeFeeds().catch(()=>{});},Math.max(1,Number(backgroundState.externalSyncMinutes||1))*60000);backgroundStatus('READY','Autonomous cycle active');backgroundMetric();}
function applyBackgroundSettings(){backgroundState.enabled=$('#bgEnabled')?.checked!==false;backgroundState.cycleMinutes=Math.max(1,Math.min(60,Number($('#bgCycle')?.value)||5));backgroundState.learningPerCycle=Math.max(1,Math.min(3,Number($('#bgLearning')?.value)||1));saveBackgroundState();startBackgroundOrchestrator();renderBackgroundOrchestrator();addLog(`Autonomous Background ${backgroundState.enabled?'enabled':'paused'} · cycle ${backgroundState.cycleMinutes}m · learning ${backgroundState.learningPerCycle}/cycle.`);}
function renderBackgroundOrchestrator(){const en=$('#bgEnabled');if(en)en.checked=backgroundState.enabled;const c=$('#bgCycle');if(c)c.value=backgroundState.cycleMinutes;const l=$('#bgLearning');if(l)l.value=backgroundState.learningPerCycle;backgroundMetric();}

function mountBackgroundPages(){
  const mounts={
    bgDataMount:['safetyPanel'],
    bgLearningMount:['championChallengerPanel','assetLearningPanel','mlMonitorPanel'],
    bgValidationMount:['backtestPanel'],
    bgArenaMount:[],
    bgExperimentMount:[],
    bgLifecycleMount:[],
    bgKnowledgeMount:[],
    bgEvidenceMount:['shadowMonitorPanel','paperMonitorPanel'],
    bgAdaptiveWeightMount:[],
    bgStructureMount:[],
    bgAIDecisionMount:['aiCenterPanel'],
    bgDecisionMount:['adaptiveArchitecturePanel','autoTradeStatusPanel'],
    bgAuditMount:[],
    bgOrchestratorMount:['backgroundOrchestratorPanel']
  };
  Object.entries(mounts).forEach(([mountId,ids])=>{
    const target=document.getElementById(mountId)?.querySelector('.background-mount');
    if(!target)return;
    ids.forEach(id=>{const el=document.getElementById(id);if(el&&el.parentElement!==target)target.appendChild(el);});
  });
}
function renderBackgroundCenter(){
  renderAGIPanel();
  renderAIDecisionCenter();
  renderContextPolicyLearningPanel();
  renderStrategyPolicyPanel();
  renderPolicyValidationArena();
  renderExperimentLabPanel();
  renderAdaptiveSourceWeightingPanel();
  renderAdaptiveSourceSelectionPanel();
  renderStructureFibonacciPanel();
  renderDecisionAuditPanel();
  const status=document.getElementById('backgroundCenterStatus');
  if(status)status.textContent=backgroundState?.enabled?'AUTO ACTIVE':'PAUSED';
  const summary=document.getElementById('backgroundCenterSummary');
  if(summary){
    const ledger=backgroundStamp?.()||{};
    const keys=['external','universe','scan','agi','learning','backtest','walkForward','walkBackward','stress','monteCarlo','paper','readiness','architecture','autoOpen','policyArena'];
    const states=keys.map(k=>ledger[k]?.status||'WAITING');
    const running=states.filter(x=>x==='RUNNING').length;
    const passed=states.filter(x=>x==='PASSED').length;
    const failed=states.filter(x=>x==='FAILED').length;
    summary.innerHTML=`<article><span>Background</span><strong>${backgroundState?.enabled?'AUTO':'PAUSED'}</strong><small>Orchestrator policy</small></article><article><span>Running</span><strong>${running}</strong><small>Tasks currently active</small></article><article><span>Passed</span><strong>${passed}</strong><small>Latest successful tasks</small></article><article><span>Failed</span><strong>${failed}</strong><small>Tasks needing recovery</small></article><article><span>Cycle</span><strong>${backgroundState?.cycleMinutes||5}m</strong><small>Automatic review interval</small></article>`;
  }
}
function bindBackgroundCenterTabs(){
  document.querySelectorAll('[data-bg-tab]').forEach(btn=>btn.addEventListener('click',()=>{
    const id=btn.dataset.bgTab;
    document.querySelectorAll('.background-tab').forEach(x=>x.classList.toggle('active',x===btn));
    document.querySelectorAll('.background-center-section').forEach(x=>x.hidden=x.id!==id);
  }));
}

function bindEvidenceCenterTabs(){
  document.querySelectorAll('[data-evidence-tab]').forEach(btn=>{
    if(btn.dataset.boundEvidenceTab==='1')return;
    btn.dataset.boundEvidenceTab='1';
    btn.addEventListener('click',()=>{
      const id=btn.dataset.evidenceTab;
      document.querySelectorAll('.evidence-center-tab').forEach(x=>{x.classList.toggle('active',x===btn);x.setAttribute('aria-selected',String(x===btn));});
      document.querySelectorAll('.evidence-center-section').forEach(x=>x.hidden=x.id!==id);
      if(id==='tradingViewMount'||id==='ctraderMount')renderExternalResearch();
      renderUniversalEvidencePanel();
    });
  });
}

function renderStrategyRiskPage(){
  const el=$('#strategyRiskSummary'); if(!el)return;
  const p=controlPolicy||CONTROL_DEFAULT, s=settings||DEFAULT;
  el.innerHTML=`<article><span>Active strategy</span><strong>${escapeHTML(s.strategyName||'—')}</strong><small>Ensemble ${s.strategyEnsemble===false?'OFF':'ON'}</small></article><article><span>Risk / trade</span><strong>${Number(s.risk||0).toFixed(1)}%</strong><small>Stop ${Number(s.sl||0).toFixed(1)}% · TP ${Number(s.tp||0).toFixed(1)}%</small></article><article><span>Decision floor</span><strong>${Number(p.scoreFloor||68)}</strong><small>Minimum Opportunity Score</small></article><article><span>Confidence floor</span><strong>${Number(p.confidenceFloor||75)}</strong><small>Hard decision gate</small></article><article><span>Risk floor</span><strong>${Number(p.riskFloor||68)}</strong><small>Hard risk gate</small></article><article><span>Minimum R:R</span><strong>${Number(p.rrFloor||1.45).toFixed(2)}</strong><small>Hard reward/risk gate</small></article><article><span>Uncertainty max</span><strong>${Number(p.maxUncertainty||42)}</strong><small>Strict abstention ${p.strictAbstention===false?'OFF':'ON'}</small></article><article><span>Auto Trade</span><strong>${escapeHTML(String(s.autoTradeMode||'off').toUpperCase())}</strong><small>LIVE remains locked</small></article>`;
}
function updateAppRoute(){
  const route=location.hash.replace(/^#/,'').trim().toLowerCase();
  const aliases={backtestpanel:'backgroundCenterPage',backtest:'backgroundCenterPage',strategyRisk:'strategyRiskPage',strategyriskpage:'strategyRiskPage',settings:'dashboard',signals:'signalsPage',signalspage:'signalsPage',research:'research',tradingview:'universalEvidenceGateway',tradingviewpage:'universalEvidenceGateway',ctrader:'universalEvidenceGateway',ctraderpage:'universalEvidenceGateway',evidencecenter:'universalEvidenceGateway',evidence:'universalEvidenceGateway',controlroom:'controlRoomPage',controlroompage:'controlRoomPage',backgroundcenter:'backgroundCenterPage',backgroundcenterpage:'backgroundCenterPage',bgdatapage:'backgroundCenterPage',bglearningpage:'backgroundCenterPage',bgvalidationpage:'backgroundCenterPage',bgevidencepage:'backgroundCenterPage',bgdecisionpage:'backgroundCenterPage',bgorchestratorpage:'backgroundCenterPage'};
  const activeId=aliases[route]||'dashboard';
  const isExternal=activeId!=='dashboard'&&activeId!=='signalsPage'&&activeId!=='universalEvidenceGateway';
  const shell=document.querySelector('main.shell'); if(shell)shell.hidden=isExternal||activeId==='strategyRiskPage';
  const wrapper=document.getElementById('externalResearchPages'); if(wrapper)wrapper.hidden=activeId==='backgroundCenterPage'||!['research','controlRoomPage'].includes(activeId);
  const bg=document.getElementById('backgroundCenterPage');if(bg)bg.hidden=activeId!=='backgroundCenterPage';
  const gateway=document.getElementById('universalEvidenceGateway');if(gateway){gateway.hidden=activeId!=='universalEvidenceGateway';gateway.setAttribute('aria-hidden',String(activeId!=='universalEvidenceGateway'));}
  ['research','controlRoomPage','strategyRiskPage'].forEach(id=>{const el=document.getElementById(id);if(el){const active=id===activeId;el.hidden=!active;el.setAttribute('aria-hidden',String(!active));}});
  const signals=document.getElementById('signalsPage');if(signals)signals.hidden=activeId!=='signalsPage';
  document.body.classList.toggle('signal-route',activeId==='signalsPage');
  document.body.classList.toggle('research-route',activeId==='research');
  document.body.classList.toggle('external-route',isExternal||activeId==='strategyRiskPage');
  if(activeId==='strategyRiskPage'){renderStrategyRiskPage();window.scrollTo({top:0,behavior:'smooth'});}
  if(activeId==='signalsPage'){renderSignals();window.scrollTo({top:0,behavior:'smooth'});}
  if(activeId==='research'){renderTradFiResults($('#tradfiSearch')?.value||'');window.scrollTo({top:0,behavior:'smooth'});}
  if(activeId==='universalEvidenceGateway'){renderExternalResearch();renderUniversalEvidencePanel();bindEvidenceCenterTabs();window.scrollTo({top:0,behavior:'smooth'});}
  if(activeId==='controlRoomPage'){fillControlRoom();window.scrollTo({top:0,behavior:'smooth'});}
  if(activeId==='backgroundCenterPage'){renderBackgroundCenter();renderBackgroundOrchestrator();renderAGIPanel();renderAIDecisionCenter();renderEvidenceIntelligencePanel();renderAdaptiveSourceWeightingPanel();renderAdaptiveSourceSelectionPanel();renderDecisionAuditPanel();renderDecisionAttributionPanel();renderDriftMonitorPanel();renderAdaptiveRecoveryPanel();renderRevalidationPanel();renderGovernanceGatePanel();renderExperimentLabPanel();renderAGIResearchPanel();renderCausalAttributionPanel();renderAgiSelfImprovementPanel();renderAgiKnowledgeGraphPanel();window.scrollTo({top:0,behavior:'smooth'});}
  if(route==='backtestpanel'||route==='backtest'){document.querySelector('[data-bg-tab="bgValidationMount"]')?.click();}
  if(activeId==='universalEvidenceGateway'){renderExternalResearch();renderUniversalEvidencePanel();bindEvidenceCenterTabs();}
}

window.addEventListener('hashchange',updateAppRoute);
setInterval(()=>{syncExternalBridgeFeeds().catch(()=>{});},60000);
syncExternalBridgeFeeds().catch(()=>{});
renderUniversalEvidencePanel();
document.addEventListener('click',e=>{
  const f=e.target.closest?.('[data-signal-filter]');
  if(f){signalFilter=f.dataset.signalFilter||'all';document.querySelectorAll('.signal-filter').forEach(x=>x.classList.toggle('active',x===f));renderSignals();}
});
$('#signalCenterScan')?.addEventListener('click',()=>scan());
$('#tradfiSearchBtn')?.addEventListener('click',()=>renderTradFiResults($('#tradfiSearch')?.value||''));
$('#toggleActivityLog')?.addEventListener('click',()=>{activityLogExpanded=!activityLogExpanded;renderLog();});

// v7.24.9: render() no longer rebuilds the full chart selector/datalist. Chart initialization is one-time;
// universe changes call renderChartPairOptions explicitly. This removes a major DOM hot path.

/* ================================================================
   LOODY'S SPOT AI — v7.69 → v8.0 SEQUENTIAL AUTONOMOUS EVOLUTION
   All layers are advisory/bounded. Core safety gates remain authoritative.
   No real orders, no API keys, no LIVE execution.
================================================================ */
const SEMANTIC_MEMORY_VERSION='lsai-agi-semantic-retrieval-v1';
const PREDICTIVE_MEMORY_VERSION='lsai-agi-predictive-memory-v1';
const COUNTERFACTUAL_VERSION='lsai-counterfactual-decision-v1';
const PORTFOLIO_INTEL_VERSION='lsai-autonomous-portfolio-intelligence-v1';
const CONTINUOUS_VALIDATION_VERSION='lsai-continuous-validation-v1';
const FINAL_GATE_VERSION='lsai-final-safety-readiness-gate-v1';
const BRAIN_VERSION='lsai-integrated-agi-market-intelligence-v9';
const EVOLUTION_VERSION='lsai-evolution-chain-v1';
const EVOLUTION_STAGE='BRAIN'; const EVOLUTION_STAGE_NUMBER=7;

function evoStore(key,def){try{return {...def,...JSON.parse(localStorage.getItem(key)||'{}')}}catch{return {...def}}}
function evoSave(key,x){try{localStorage.setItem(key,JSON.stringify({...x,updatedAt:Date.now()}))}catch{}}
const EVO_DEFAULT={enabled:true,maxInfluence:0.04,minEvidence:8,strictSafety:true};
function semanticStore(){return evoStore(SEMANTIC_MEMORY_VERSION,{...EVO_DEFAULT,maxRows:700});}
function semanticRows(){const a=decisionAuditEntries();const c=causalAttributionStore().entries||[];const rows=[];for(const x of a){const linked=c.filter(y=>y.auditId===x.id).slice(-1)[0];if(!linked)continue;rows.push({...x,realizedPct:Number(linked.realizedPct),win:!!linked.win});}return rows.slice(-Number(semanticStore().maxRows||700));}
function intervalMinutes(tf){const s=String(tf||'AUTO');const m=s.match(/^(\d+)(m|h|d|w|M)$/);if(!m)return 240;const n=Number(m[1]);return n*(m[2]==='m'?1:m[2]==='h'?60:m[2]==='d'?1440:m[2]==='w'?10080:43200);}
function num(v,d=50){return Number.isFinite(Number(v))?Number(v):d;}
function semanticVector(x){return {tf:Math.log1p(intervalMinutes(x.timeframe||'AUTO')),score:num(x.score),ai:num(x.ai),confidence:num(x.confidence),data:num(x.dataQuality,100),risk:num(x.risk),rr:clamp(num(x.rr)*40,0,100),mtf:num(x.mtf),meta:num(x.meta),uncertainty:num(x.uncertainty),fusion:num(x.fusion?.score),structure:num(x.structureCombinedScore,x.structureScore||50),strategy:String(x.strategy||'AUTO'),regime:String(x.regime||'UNKNOWN'),sources:new Set(Array.isArray(x.sources)?x.sources:[])};}
function semanticSimilarity(a,b){const A=semanticVector(a),B=semanticVector(b);const numeric=[['tf',.08],['score',.14],['ai',.10],['confidence',.12],['data',.06],['risk',.10],['rr',.10],['mtf',.08],['meta',.05],['uncertainty',.07],['fusion',.05],['structure',.05]];let s=0,w=0;for(const [k,ww] of numeric){const den=k==='tf'?Math.max(A[k],B[k],1):100;const d=Math.abs(A[k]-B[k])/den;s+=ww*(1-clamp(d,0,1));w+=ww;}s+=.07*(A.strategy===B.strategy?1:0);s+=.06*(A.regime===B.regime?1:0);const union=new Set([...A.sources,...B.sources]).size,inter=[...A.sources].filter(x=>B.sources.has(x)).length;s+=.07*(union?inter/union:.5);return clamp(s/w,0,1);}
function agiSemanticContext(m,o){const target={symbol:m?.symbol,timeframe:m?.timeframe||o?.timeframe,strategy:o?.assetStrategy||o?.strategy,regime:m?.regime||m?.marketRegime,score:o?.score,ai:o?.aiConsensus,confidence:o?.decisionConfidence||o?.confidence,risk:o?.riskScore,rr:o?.rewardRisk,mtf:o?.mtfScore,meta:o?.metaScore,uncertainty:o?.uncertainty,dataQuality:m?.dataQuality,fusion:{score:o?.contextFusionScore},structureCombinedScore:o?.structureCombinedScore,structureScore:o?.structureScore,sources:o?.contextFusionSources};const rows=semanticRows().filter(x=>Number.isFinite(Number(x.realizedPct)));if(rows.length<Number(semanticStore().minEvidence||8))return {score:50,samples:rows.length,similar:[],status:'INSUFFICIENT_EVIDENCE'};const scored=rows.map(x=>{const sim=semanticSimilarity(target,x);const age=Math.max(0,(Date.now()-Number(x.at||0))/86400000);const recency=Math.exp(-age/180);const reliability=Number(x.win===true||x.win===false?1:.8);return {...x,similarity:sim,weight:sim*recency*reliability}}).filter(x=>x.similarity>=.58).sort((a,b)=>b.weight-a.weight).slice(0,12);if(!scored.length)return {score:50,samples:rows.length,similar:[],status:'NO_SIMILAR_CONTEXT'};const ws=scored.reduce((a,x)=>a+x.weight,0)||1,win=scored.reduce((a,x)=>a+x.weight*(x.win?1:0),0)/ws;return {score:clamp(Math.round(win*100),0,100),samples:rows.length,similar:scored.map(x=>({symbol:x.symbol,timeframe:x.timeframe,strategy:x.strategy,regime:x.regime,similarity:Number(x.similarity.toFixed(3)),realizedPct:Number(x.realizedPct.toFixed(3))})),status:'ACTIVE'};}
function renderSemanticPanel(){const host=$('#bgSemanticMount .background-mount');if(!host)return;let box=$('#agiSemanticPanel');if(!box){box=document.createElement('section');box.id='agiSemanticPanel';box.className='panel';host.appendChild(box)}const rows=semanticRows();const s=rows.length?agiSemanticContext({symbol:markets[0]?.symbol,timeframe:markets[0]?.timeframe,regime:markets[0]?.regime},{strategy:markets[0]?.assetStrategy,score:markets[0]?.score}):{score:50,samples:0,similar:[]};box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">v7.69 · SEMANTIC CONTEXT RETRIEVAL</p><h2>الذاكرة الدلالية للسياقات المشابهة</h2><p class="muted">يبحث في قرارات سابقة متحللة حسب الإطار والاستراتيجية وRegime والمخاطر والأدلة والهيكل، وليس حسب اسم العملة فقط.</p></div><span class="tag">${rows.length} OUTCOMES</span></div><div class="performance-results"><article><span>Semantic score</span><strong>${s.score}</strong><small>contextual historical fit</small></article><article><span>Evidence</span><strong>${s.samples}</strong><small>resolved contexts</small></article><article><span>Similar matches</span><strong>${s.similar?.length||0}</strong><small>top contextual retrieval</small></article><article><span>Influence</span><strong>≤ 2 pts</strong><small>ranking only</small></article></div><div class="table-wrap"><table><thead><tr><th>Pair</th><th>TF</th><th>Strategy</th><th>Regime</th><th>Similarity</th><th>Outcome</th></tr></thead><tbody>${(s.similar||[]).map(x=>`<tr><td>${escapeHTML(x.symbol||'—')}</td><td>${escapeHTML(x.timeframe||'—')}</td><td>${escapeHTML(x.strategy||'—')}</td><td>${escapeHTML(x.regime||'—')}</td><td>${(x.similarity*100).toFixed(1)}%</td><td>${x.realizedPct.toFixed(2)}%</td></tr>`).join('')||'<tr><td colspan="6">ستُبنى الذاكرة تلقائيًا مع نتائج Shadow/Paper المحلولة.</td></tr>'}</tbody></table></div>`}

function predictiveMemory(m,o){const sem=agiSemanticContext(m,o);if(sem.samples<Number(evoStore(PREDICTIVE_MEMORY_VERSION,EVO_DEFAULT).minEvidence||8)||!sem.similar?.length)return {probability:50,confidence:0,samples:sem.samples,status:'INSUFFICIENT'};const cfg=evoStore(PREDICTIVE_MEMORY_VERSION,{...EVO_DEFAULT,minEvidence:8});const weighted=sem.similar.reduce((a,x)=>{const w=Math.pow(Number(x.similarity||0),2);return {w:a.w+w,p:a.p+w*(Number(x.realizedPct)>0?1:0)}},{w:0,p:0});const p=weighted.w?weighted.p/weighted.w*100:50;const confidence=clamp(Math.round(Math.min(100,sem.similar.length*7+Math.abs(p-50)*.8)),0,90);return {probability:Math.round(p*10)/10,confidence,samples:sem.samples,status:'ACTIVE',semanticScore:sem.score};}
function renderPredictivePanel(){const host=$('#bgPredictiveMount .background-mount');if(!host)return;let box=$('#predictiveMemoryPanel');if(!box){box=document.createElement('section');box.id='predictiveMemoryPanel';box.className='panel';host.appendChild(box)}const m=markets.find(x=>x?.price)||markets[0]||{};const p=predictiveMemory(m,opportunityScoreSafe(m));box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">v7.70 · PREDICTIVE MEMORY</p><h2>الذاكرة التنبؤية</h2><p class="muted">تحول السياقات التاريخية المشابهة إلى احتمال نجاح bounded؛ ليست ضمانًا ولا بوابة مستقلة.</p></div><span class="tag">${p.status}</span></div><div class="performance-results"><article><span>Predicted success</span><strong>${p.probability.toFixed(1)}%</strong><small>similar resolved contexts</small></article><article><span>Prediction confidence</span><strong>${p.confidence}</strong><small>bounded confidence</small></article><article><span>Samples</span><strong>${p.samples}</strong><small>semantic evidence</small></article><article><span>Gate authority</span><strong>CORE</strong><small>prediction cannot qualify</small></article></div>`}
function opportunityScoreSafe(m){try{return opportunityScore(m)||{}}catch{return {}}}

function counterfactualDecision(m,o){const base=num(o?.score);const p=num(o?.aiConsensus);const c=num(o?.decisionConfidence||o?.agiConfidence);const variants=[{name:'BASE',score:base},{name:'NO_EXTERNAL',score:base-(num(o?.contextFusionScore)-50)*.03},{name:'NO_LEARNING',score:base-(num(o?.strategyPolicyScore)-50)*.03},{name:'CONSERVATIVE',score:Math.min(base,c,num(o?.riskScore))},{name:'ALTERNATE_TF',score:(base+num(o?.mtfScore))/2}];const ranked=variants.map(v=>({...v,score:clamp(v.score,0,100)})).sort((a,b)=>b.score-a.score);const fragility=clamp(ranked[0].score-ranked[ranked.length-1].score,0,100);const spread=ranked[0].score-ranked[ranked.length-1].score;return {variants:ranked,spread:Number(spread.toFixed(2)),fragility:Number(fragility.toFixed(2)),stable:spread<12,preferred:ranked[0].name};}
function renderCounterfactualPanel(){const host=$('#bgCounterfactualMount .background-mount');if(!host)return;let box=$('#counterfactualPanel');if(!box){box=document.createElement('section');box.id='counterfactualPanel';box.className='panel';host.appendChild(box)}const m=markets.find(x=>x?.price)||{};const o=opportunityScoreSafe(m),c=counterfactualDecision(m,o);box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">v7.71 · COUNTERFACTUAL DECISION ENGINE</p><h2>اختبار البدائل قبل القرار</h2><p class="muted">يقارن القرار الحالي ببدائل محدودة لكشف هشاشته؛ لا يغير بوابات الأمان.</p></div><span class="tag">${c.stable?'STABLE':'FRAGILE'}</span></div><div class="performance-results"><article><span>Preferred</span><strong>${c.preferred}</strong></article><article><span>Decision spread</span><strong>${c.spread}</strong></article><article><span>Fragility</span><strong>${c.fragility}</strong></article><article><span>Safety</span><strong>CORE</strong><small>authoritative gates</small></article></div><div class="table-wrap"><table><thead><tr><th>Scenario</th><th>Score</th></tr></thead><tbody>${c.variants.map(x=>`<tr><td>${escapeHTML(x.name)}</td><td>${x.score.toFixed(1)}</td></tr>`).join('')}</tbody></table></div>`}

function candleReturns(m){const c=Array.isArray(m?.candles)?m.candles:[];return c.slice(-80).map((x,i,a)=>i?Math.log(Number(x.close)/Number(a[i-1].close)):0).filter(Number.isFinite)}
function corr(a,b){const n=Math.min(a.length,b.length);if(n<12)return 0;const A=a.slice(-n),B=b.slice(-n),ma=A.reduce((x,y)=>x+y,0)/n,mb=B.reduce((x,y)=>x+y,0)/n;let xy=0,xx=0,yy=0;for(let i=0;i<n;i++){const x=A[i]-ma,y=B[i]-mb;xy+=x*y;xx+=x*x;yy+=y*y}return xx&&yy?xy/Math.sqrt(xx*yy):0}
function portfolioIntelligence(rows){const cfg=evoStore(PORTFOLIO_INTEL_VERSION,{...EVO_DEFAULT,maxCorrelation:.82,maxPositions:Infinity});const selected=[],blocked=[];for(const m of [...rows].sort((a,b)=>num(b.rankScore,b.score)-num(a.rankScore,a.score))){const tooCorrelated=selected.some(x=>Math.abs(corr(candleReturns(m),candleReturns(x)))>Number(cfg.maxCorrelation||.82));if(tooCorrelated){blocked.push({symbol:m.symbol,reason:'HIGH_CORRELATION'});continue}selected.push(m);if(selected.length>=Math.min(Number(cfg.maxPositions||999),rows.length))break}return {selected,blocked,concentration:selected.length?Math.max(...selected.map(x=>num(x.riskScore))):0};}
function portfolioQualifiedOpportunities(){const source=settings.autoSelection?(qualifiedOpportunities.length?qualifiedOpportunities:watchPairs()):watchPairs();const rows=source.map(pair=>markets.find(m=>m.symbol===pairParts(pair).symbol)).filter(m=>m&&m.price>0).filter(m=>{const o=opportunityScore(m);return engineQualified(m,o)});return portfolioIntelligence(rows).selected;}
function renderPortfolioIntelPanel(){const host=$('#bgPortfolioMount .background-mount');if(!host)return;let box=$('#portfolioIntelPanel');if(!box){box=document.createElement('section');box.id='portfolioIntelPanel';box.className='panel';host.appendChild(box)}const rows=portfolioQualifiedOpportunities(),p=portfolioIntelligence(rows);box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">v7.72 · AUTONOMOUS PORTFOLIO INTELLIGENCE</p><h2>اختيار محفظة لاختيار فرص منفردة فقط</h2><p class="muted">يمنع تكديس فرص شديدة الارتباط عندما تكون السعة والمخاطر محدودة.</p></div><span class="tag">${rows.length} QUALIFIED</span></div><div class="performance-results"><article><span>Portfolio candidates</span><strong>${rows.length}</strong></article><article><span>Selected</span><strong>${p.selected.length}</strong></article><article><span>Correlation blocks</span><strong>${p.blocked.length}</strong></article><article><span>Position capacity</span><strong>AUTO</strong></article></div><div class="table-wrap"><table><thead><tr><th>Selected</th><th>Score</th><th>Risk</th><th>R:R</th></tr></thead><tbody>${p.selected.map(x=>{const o=opportunityScoreSafe(x);return `<tr><td>${escapeHTML(x.symbol)}</td><td>${num(o.rankScore,o.score).toFixed(1)}</td><td>${num(o.riskScore).toFixed(1)}</td><td>${num(o.rewardRisk,0).toFixed(2)}</td></tr>`}).join('')||'<tr><td colspan="4">لا توجد فرص مؤهلة حاليًا.</td></tr>'}</tbody></table></div>`}

function continuousValidationSnapshot(){const read=k=>{try{return JSON.parse(localStorage.getItem(k)||'null')}catch{return null}};const w=read('lsai-walkforward-last'),wb=read('lsai-walkbackward-last'),mc=read('lsai-montecarlo-last'),st=read('lsai-stress-last');const checks={walkForward:w?.verdict==='ROBUST',walkBackward:wb?.verdict==='PASS DIAGNOSTIC',monteCarlo:mc?.verdict==='ROBUST',stress:String(st?.verdict||'').startsWith('PASS'),paper:paperStats().closed>=50,shadow:shadowLedger().filter(x=>x.resolved).length>=50};const passed=Object.values(checks).filter(Boolean).length;return {version:CONTINUOUS_VALIDATION_VERSION,at:Date.now(),checks,passed,total:Object.keys(checks).length,healthy:passed>=5};}
function runContinuousValidation(){const s=continuousValidationSnapshot();evoSave(CONTINUOUS_VALIDATION_VERSION,s);return s}
function renderContinuousValidationPanel(){const host=$('#bgContinuousValidationMount .background-mount');if(!host)return;let box=$('#continuousValidationPanel');if(!box){box=document.createElement('section');box.id='continuousValidationPanel';box.className='panel';host.appendChild(box)}const s=runContinuousValidation();box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">v7.73 · CONTINUOUS VALIDATION</p><h2>التحقق المستمر</h2><p class="muted">كل نموذج جديد يبقى Challenger حتى يمر عبر الاختبارات الزمنية والضغطية والأدلة الواقعية الافتراضية.</p></div><span class="tag">${s.passed}/${s.total}</span></div><div class="validation-row"><strong>Current chain</strong><span>${Object.entries(s.checks).map(([k,v])=>`${v?'✓':'✕'} ${k}`).join(' · ')}</span></div>`}

function finalSafetyGate(){const cv=continuousValidationSnapshot(),dr=driftSnapshot(),p=predictiveMemory(markets.find(x=>x?.price)||{},opportunityScoreSafe(markets.find(x=>x?.price)||{}));const criticalDrift=dr?.overall?.severity==='CRITICAL';const uncertainty=p.confidence>0?100-p.confidence:50;const checks=[['Continuous validation',cv.healthy],['No critical drift',!criticalDrift],['Predictive memory uncertainty',uncertainty<=55],['Core safety policy',settings.maxExposure<=50&&settings.dailyLossLimit>0],['LIVE locked',true]];return {version:FINAL_GATE_VERSION,passed:checks.filter(x=>x[1]).length,total:checks.length,checks,status:checks.every(x=>x[1])?'RESEARCH READY':'RESEARCH HOLD',autoTradeEligible:checks.every(x=>x[1])&&cv.healthy&&!criticalDrift};}
function renderFinalSafetyPanel(){const host=$('#bgFinalGateMount .background-mount');if(!host)return;let box=$('#finalSafetyPanel');if(!box){box=document.createElement('section');box.id='finalSafetyPanel';box.className='panel';host.appendChild(box)}const g=finalSafetyGate();evoSave(FINAL_GATE_VERSION,g);box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">v7.74 · FINAL SAFETY & READINESS GATE</p><h2>بوابة الأمان والاستعداد النهائية</h2><p class="muted">لا تسمح هذه البوابة للذاكرة أو AGI أو Portfolio أو أي مصدر خارجي بتجاوز القواعد الأساسية.</p></div><span class="tag">${g.status}</span></div><div class="performance-results"><article><span>Passed</span><strong>${g.passed}/${g.total}</strong></article><article><span>Research state</span><strong>${g.status}</strong></article><article><span>Auto Trade</span><strong>${g.autoTradeEligible?'ELIGIBLE':'HOLD'}</strong></article><article><span>LIVE</span><strong>LOCKED</strong></article></div><div class="validation-row"><strong>Final checks</strong><span>${g.checks.map(c=>`${c[1]?'✓':'✕'} ${c[0]}`).join(' · ')}</span></div>`}

function autonomousBrainCycle(){const semantic=markets.slice(0,20).map(m=>({m,o:opportunityScoreSafe(m)})).filter(x=>x.m?.price);const scored=semantic.map(x=>{const pm=predictiveMemory(x.m,x.o),cf=counterfactualDecision(x.m,x.o);return {...x,pm,cf,final:clamp(num(x.o.rankScore,x.o.score)+((pm.probability-50)*.03)+(cf.stable?1:-1),0,100)}}).sort((a,b)=>b.final-a.final);const top=scored.slice(0,10);evoSave(BRAIN_VERSION,{at:Date.now(),cycle:((evoStore(BRAIN_VERSION,{cycles:0}).cycles||0)+1),top:top.map(x=>({symbol:x.m.symbol,timeframe:x.m.timeframe,score:x.final,predictive:x.pm.probability,fragility:x.cf.fragility}))});return {scanned:semantic.length,top};}
function renderBrainPanel(){const host=$('#bgBrainMount .background-mount');if(!host)return;let box=$('#brainPanel');if(!box){box=document.createElement('section');box.id='brainPanel';box.className='panel';host.appendChild(box)}const r=autonomousBrainCycle();box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">v9.1.3 · INTEGRATED AGI MARKET INTELLIGENCE BRAIN</p><h2>العقل التشغيلي المستقل — Research/Paper فقط</h2><p class="muted">Scan → Retrieve → Predict → Counterfactual → Portfolio → Validate → Decide → Observe → Learn. لا توجد أوامر حقيقية.</p></div><span class="tag">${r.scanned} REVIEWED</span></div><div class="table-wrap"><table><thead><tr><th>Rank</th><th>Pair</th><th>TF</th><th>Final</th><th>Prediction</th><th>Fragility</th></tr></thead><tbody>${r.top.map((x,i)=>`<tr><td>${i+1}</td><td>${escapeHTML(x.m.symbol)}</td><td>${escapeHTML(x.m.timeframe||'AUTO')}</td><td>${x.final.toFixed(1)}</td><td>${x.pm.probability.toFixed(1)}%</td><td>${x.cf.fragility.toFixed(1)}</td></tr>`).join('')||'<tr><td colspan="6">بانتظار بيانات السوق.</td></tr>'}</tbody></table></div><p class="meta">v9.1.3 لا يفتح صفقات حقيقية. PAPER AUTO يظل محكومًا بكل بوابات الأمان السابقة.</p>`}

function agiEvidence(m,o){const trend=clamp((num(o.trendStrength,0)+12)/24*100,0,100),mom=clamp((num(o.momentum,0)+12)/24*100,0,100);const ext=agiExternalEvidence(m?.symbol||o?.symbol),conflict=evidenceConflictForMarket(m,o),fusion=contextFusion(m,o),mem=agiKnowledgeContextScore(m,o),sem=agiSemanticContext(m,o),pred=predictiveMemory(m,o),cf=counterfactualDecision(m,o);return {trend,momentum:mom,mtf:num(o.mtfScore),risk:num(o.riskScore),rr:clamp(num(o.rewardRisk,1)/2*100,0,100),regime:num(o.regimeFit),ml:num(o.mlProbability),tv:ext.tv,ctrader:ext.ctrader,validation:agiValidationEvidence(),fusion:fusion.score,memory:mem.score,memorySamples:mem.samples,semantic:sem.score,semanticSamples:sem.samples,predictive:pred.probability,predictiveConfidence:pred.confidence,counterfactualStability:cf.stable?100:40,counterfactualFragility:cf.fragility,evidenceConflict:Math.max(conflict.score,fusion.conflict)}}
function agiV2Agents(m,o,baseDecision){const e=agiEvidence(m,o),regime=String(m?.regime||m?.marketRegime||'UNKNOWN'),context=agiV2ContextStats(m,o);const trend=e.trend,mom=e.momentum;const agents=[{name:'TECHNICAL',score:clamp(e.trend*.38+e.momentum*.28+e.mtf*.18+e.semantic*.08+e.counterfactualStability*.08,0,100),direction:(trend>=55?1:-1)+(mom>=55?1:-1)},{name:'REGIME',score:clamp(e.regime*.50+e.mtf*.22+e.semantic*.13+e.counterfactualStability*.15,0,100),direction:['TREND_UP','EARLY_UP'].includes(regime)?1:['TREND_DOWN','PANIC'].includes(regime)?-1:0},{name:'RISK',score:clamp(e.risk*.56+e.rr*.28+(100-e.evidenceConflict)*.10+e.counterfactualStability*.06,0,100),direction:e.risk>=68&&e.rr>=72?1:0},{name:'EVIDENCE',score:clamp(e.fusion*.42+e.semantic*.18+e.predictive*.16+e.validation*.14+(100-e.evidenceConflict)*.10,0,100),direction:e.semantic>=58&&e.predictive>=55?1:0},{name:'VALIDATION',score:clamp(e.validation*.58+e.ml*.17+e.mtf*.15+e.predictive*.10,0,100),direction:e.validation>=60?1:0},{name:'COUNTERFACTUAL',score:clamp(e.counterfactualStability*.72+(100-e.counterfactualFragility)*.28,0,100),direction:e.counterfactualStability>=60?1:-1}];if(context.samples>=Number(agiV2Store().minResolved||12))agents.push({name:'CONTEXT_MEMORY',score:clamp(context.winRate*.60+context.calibration*.20+(context.avgReturn>0?20:0),0,100),direction:context.winRate>=55?1:context.winRate<=45?-1:0});return agents}
function agiSupervisorV2(m,o,baseDecision){const cfg=agiV2Store();if(!cfg.enabled)return agiSupervisor(m,o,baseDecision);const e=agiEvidence(m,o),agents=agiV2Agents(m,o,baseDecision),cf=agiV2Counterfactual(m,o,agents),ctx=agiV2ContextStats(m,o),weighted=agents.reduce((a,x)=>a+num(x.score),0)/Math.max(1,agents.length),coreConf=num(baseDecision?.confidence),safety=num(o.dataQuality,0)>=85&&coreConf>=75&&num(o.riskScore,0)>=68&&num(o.rewardRisk,0)>=1.45&&num(o.uncertainty,100)<=42&&!o.abstain;const semanticSupport=(e.semantic-50)*.06,predSupport=(e.predictive-50)*.04;const uncertainty=clamp(Math.round((100-weighted)*.40+cf.fragility*.38+Math.abs(weighted-coreConf)*.25+(ctx.samples<Number(cfg.minResolved||12)?8:0)),0,100);let action='WAIT',reason='AGI agents require more evidence.';if(!safety&&cfg.strictSafety){action='NO_TRADE';reason='Core safety gate failed; autonomous layers cannot override it.'}else if(cf.stable&&weighted>=78&&coreConf>=75&&cf.negative===0){action='CONFIRM';reason='Multi-agent consensus remains stable after counterfactual review.'}else if(weighted>=68&&cf.positive>=Number(cfg.minAgentAgreement||3)&&cf.negative<=1){action='SUPPORT';reason='Agents support the setup while Core remains authoritative.'}else if(cf.conflict>=35||cf.negative>=2){action='CONFLICT';reason='Material agent disagreement; prefer abstention.'}const score=clamp(Math.round(weighted+semanticSupport+predSupport-cf.fragility*.15-e.evidenceConflict*.08),0,100),confidence=clamp(Math.round(100-uncertainty),0,Number(cfg.confidenceCap||92)),boost=action==='CONFIRM'?Math.min(Number(cfg.maxInfluence||.12)*100,8):action==='SUPPORT'?4:0;return {enabled:true,score,confidence,action,reason,conflict:Math.max(cf.conflict,Math.abs(weighted-coreConf)),uncertainty,evidence:e,finalBoost:boost,agents,counterfactual:cf,context:ctx,learning:`${ctx.samples} context samples`,version:AGI_V2_VERSION}}
function currentQualifiedOpportunities(){const source=settings.autoSelection?(qualifiedOpportunities.length?qualifiedOpportunities:watchPairs()):watchPairs();const rows=source.map(pair=>markets.find(m=>m.symbol===pairParts(pair).symbol)).filter(m=>m&&m.price>0).filter(m=>{const o=opportunityScore(m);return engineQualified(m,o)});return portfolioIntelligence(rows).selected;}
function autoTradeRequirements(){const base=(()=>{const w=(()=>{try{return JSON.parse(localStorage.getItem('lsai-walkforward-last')||'null')}catch{return null}})(),wb=(()=>{try{return JSON.parse(localStorage.getItem('lsai-walkbackward-last')||'null')}catch{return null}})(),mc=(()=>{try{return JSON.parse(localStorage.getItem('lsai-montecarlo-last')||'null')}catch{return null}})(),st=(()=>{try{return JSON.parse(localStorage.getItem('lsai-stress-last')||'null')}catch{return null}})(),p=paperStats(),shadow=shadowLedger().filter(x=>x.resolved),championRows=typeof championStatsSummary==='function'?championStatsSummary():[],champion=championRows.find(x=>x.key===championState().champion);return [['Forward Purged Walk-forward',!!w&&w.verdict==='ROBUST'],['Backward diagnostic',!!wb&&wb.verdict==='PASS DIAGNOSTIC'],['Monte Carlo',!!mc&&mc.verdict==='ROBUST'],['Stress Test',!!st&&String(st.verdict||'').startsWith('PASS')],['Paper closed trades',p.closed>=50],['Paper win rate',p.closed>=50&&p.winRate>=52],['Paper drawdown evidence',p.closed>=50&&p.net>=-settings.budget*.05],['Shadow resolved evidence',shadow.length>=50],['Champion evidence',!!champion&&champion.trials>=50],['Daily loss / exposure guardrails',settings.dailyLossLimit>0&&settings.maxExposure<=50],['Auto-trade armed',settings.autoTradeArmed===true]]})();const fg=finalSafetyGate();const checks=[...base,['Final safety/readiness gate',fg.autoTradeEligible]];const passed=checks.filter(x=>x[1]).length;return {checks,passed,total:checks.length,liveEligible:false,finalGate:fg}}
function renderEvolutionCenter(){renderSemanticPanel(); if(EVOLUTION_STAGE_NUMBER>=2)renderPredictivePanel(); if(EVOLUTION_STAGE_NUMBER>=3)renderCounterfactualPanel(); if(EVOLUTION_STAGE_NUMBER>=4)renderPortfolioIntelPanel(); if(EVOLUTION_STAGE_NUMBER>=5)renderContinuousValidationPanel(); if(EVOLUTION_STAGE_NUMBER>=6)renderFinalSafetyPanel(); if(EVOLUTION_STAGE_NUMBER>=7)renderBrainPanel(); renderAGI9Panel();renderControlBridgePanel();}
function renderBackgroundCenter(){renderAGIPanel();renderAIDecisionCenter();renderContextPolicyLearningPanel();renderStrategyPolicyPanel();renderPolicyValidationArena();renderExperimentLabPanel();renderAdaptiveSourceWeightingPanel();renderAdaptiveSourceSelectionPanel();renderStructureFibonacciPanel();renderDecisionAuditPanel();renderDecisionAttributionPanel();renderDriftMonitorPanel();renderAdaptiveRecoveryPanel();renderRevalidationPanel();renderGovernanceGatePanel();renderAGIResearchPanel();renderCausalAttributionPanel();renderAgiSelfImprovementPanel();renderAgiKnowledgeGraphPanel();renderEvolutionCenter();const status=document.getElementById('backgroundCenterStatus');if(status)status.textContent=backgroundState?.enabled?'AUTO ACTIVE':'PAUSED';const summary=document.getElementById('backgroundCenterSummary');if(summary){const ledger=backgroundStamp?.()||{};const states=Object.values(ledger).map(x=>x?.status||'WAITING');summary.innerHTML=`<article><span>Background</span><strong>${backgroundState?.enabled?'AUTO':'PAUSED'}</strong><small>Orchestrator policy</small></article><article><span>Running</span><strong>${states.filter(x=>x==='RUNNING').length}</strong></article><article><span>Passed</span><strong>${states.filter(x=>x==='PASSED').length}</strong></article><article><span>Failed</span><strong>${states.filter(x=>x==='FAILED').length}</strong></article><article><span>Evolution</span><strong>v9.1.3</strong><small>integrated AGI chain</small></article>`}}
function runEvolutionCycle(){try{renderEvolutionCenter(); if(EVOLUTION_STAGE_NUMBER>=5)runContinuousValidation(); if(EVOLUTION_STAGE_NUMBER>=6)renderFinalSafetyPanel(); if(EVOLUTION_STAGE_NUMBER>=7)renderBrainPanel();}catch(e){try{addLog(`Evolution chain error: ${e?.message||e}`)}catch{}}}
/* v9.0 compatibility aliases for the self-improvement loop */
function agiSelfImprovementRun(){const cfg=agiSelfImprovementStore();if(cfg.enabled===false)return {actions:0};const rec=recoveryStore?.().entries||[],ca=causalAttributionSummary?.()||{resolved:0,top:[]},exp=experimentLabLedger?.()||[];const actions=[];if(ca.resolved>=5&&ca.top?.[0])actions.push({type:'CAUSAL_FOLLOWUP',priority:80,reason:`اختبار أثر العامل ${ca.top[0].label}`,context:'GLOBAL',route:'AGI Research → Experiment Lab'});if(rec.length)actions.push({type:'RECOVERY_REVALIDATION',priority:88,reason:'إعادة تحقق من آخر Recovery',context:agiSelfImprovementContext(rec[rec.length-1]||{}),route:'Recovery → Revalidation → Governance'});if(exp.length)actions.push({type:'EXPERIMENT_FOLLOWUP',priority:76,reason:'تحليل Challenger',context:agiSelfImprovementContext(exp[exp.length-1]||{}),route:'Experiment Lab → Revalidation'});if(!actions.length)actions.push({type:'EVIDENCE_REFRESH',priority:60,reason:'جمع أدلة جديدة قبل اقتراح تغيير',context:'GLOBAL',route:'Evidence Center'});const out=[];for(const a of actions.slice(0,Number(cfg.maxActions||5)))out.push({...a,id:`asi-${Date.now()}-${out.length}`,at:Date.now(),status:'QUEUED_SHADOW_ONLY'});const st=agiSelfImprovementStore();saveAgiSelfImprovementStore({...st,ledger:[...(st.ledger||[]),...out]});return {actions:out.length,items:out};}


/* ================================================================
   LOODY'S SPOT AI — v8.1 → v9.0 AGI MARKET INTELLIGENCE EXPANSION
   Research/Paper/Shadow only. Hard safety gates are authoritative.
================================================================ */
const WORLD_MODEL_VERSION='lsai-agi-world-model-v1';
const REGIME_INTEL_VERSION='lsai-agi-regime-intelligence-v1';
const UNCERTAINTY_VERSION='lsai-agi-uncertainty-v1';
const ADVERSARIAL_VERSION='lsai-agi-adversarial-defense-v1';
const DECISION_GRAPH_VERSION='lsai-agi-decision-graph-v1';
const SELF_PROTECTION_VERSION='lsai-agi-self-protection-v1';
const AGI9_VERSION='lsai-agi-integrated-brain-v9';
const AGI_NEW_STAGE=6; // Integrated AGI Market Intelligence Brain
function worldModelStore(){return evoStore(WORLD_MODEL_VERSION,{enabled:true,maxHistory:120,maxInfluence:.04});}
function regimeIntelStore(){return evoStore(REGIME_INTEL_VERSION,{enabled:true,minConfidence:62,maxInfluence:.03});}
function uncertaintyStore(){return evoStore(UNCERTAINTY_VERSION,{enabled:true,abstainThreshold:58,maxInfluence:0});}
function adversarialStore(){return evoStore(ADVERSARIAL_VERSION,{enabled:true,hardBlockThreshold:72,maxInfluence:0});}
function decisionGraphStore(){return evoStore(DECISION_GRAPH_VERSION,{enabled:true,maxRows:250});}
function selfProtectionStore(){return evoStore(SELF_PROTECTION_VERSION,{enabled:true,maxInfluence:0,killOnCritical:true});}
function finiteSeries(m){const c=Array.isArray(m?.candles)?m.candles:Array.isArray(m?.klines)?m.klines:[];return c.slice(-80).map(x=>({o:num(x.open??x[1],0),h:num(x.high??x[2],0),l:num(x.low??x[3],0),c:num(x.close??x[4],0),v:num(x.volume??x[5],0)})).filter(x=>x.c>0);}
function worldModel(m,o){const c=finiteSeries(m), n=c.length;if(n<8)return {state:'INSUFFICIENT_DATA',score:50,confidence:0,trend:0,volatility:50,liquidity:50,momentum:50,structure:50};const ret=c.slice(1).map((x,i)=>c[i].c?x.c/c[i].c-1:0),mean=ret.reduce((a,x)=>a+x,0)/Math.max(1,ret.length),vol=Math.sqrt(ret.reduce((a,x)=>a+(x-mean)**2,0)/Math.max(1,ret.length))*100;const first=c[Math.max(0,n-20)].c,last=c[n-1].c,trend=clamp(50+(last/Math.max(first,1)-1)*450,0,100);const mom=clamp(50+(ret.slice(-8).reduce((a,x)=>a+x,0))*700,0,100);const vols=c.slice(-20).map(x=>x.v).filter(Number.isFinite),av=vols.reduce((a,x)=>a+x,0)/Math.max(1,vols.length),lv=vols.length?vols[vols.length-1]/Math.max(av,1):1;const liquidity=clamp(50+Math.log(Math.max(.25,lv))*25,0,100),vscore=clamp(100-vol*8,0,100),structure=clamp(trend*.45+mom*.25+vscore*.20+liquidity*.10,0,100),confidence=clamp(Math.round(35+Math.min(55,n)*.7+Math.abs(trend-50)*.35),0,92);let state='BALANCED';if(vscore<35)state='HIGH_VOLATILITY';else if(liquidity<35)state='LOW_LIQUIDITY';else if(trend>=70&&mom>=60)state='TREND_UP';else if(trend<=30&&mom<=40)state='TREND_DOWN';else if(Math.abs(trend-50)<10&&vscore>65)state='RANGE';return {state,score:Math.round(structure),confidence,trend,momentum:mom,volatility:vscore,liquidity,structure,sample:n};}
function classifyRegime(m,o){const w=worldModel(m,o),r=String(m?.regime||m?.marketRegime||'');if(r&&r!=='UNKNOWN')return {regime:r,confidence:Math.max(55,w.confidence),source:'market+world'};return {regime:w.state,confidence:w.confidence,source:'world-model'};}
function uncertaintyEngine(m,o){const w=worldModel(m,o),r=classifyRegime(m,o),vals=[num(o?.confidence,50),num(o?.aiConsensus,50),num(o?.dataQuality,50),num(o?.mtfScore,50),num(o?.riskScore,50),w.confidence,r.confidence];const mean=vals.reduce((a,x)=>a+x,0)/vals.length,spread=Math.sqrt(vals.reduce((a,x)=>a+(x-mean)**2,0)/vals.length),dataGap=100-num(o?.dataQuality,0),conflict=Math.abs(num(o?.confidence,50)-num(o?.aiConsensus,50));const uncertainty=clamp(Math.round(spread*.55+dataGap*.30+conflict*.25+(w.sample<20?12:0)),0,100),robust=100-uncertainty;return {uncertainty,robust,abstain:uncertainty>=Number(uncertaintyStore().abstainThreshold||58),confidence:clamp(Math.round(robust),0,100),drivers:{spread,dataGap,conflict,samples:w.sample},regime:r.regime};}
function adversarialDefense(m,o){const w=worldModel(m,o),u=uncertaintyEngine(m,o),c=finiteSeries(m);const ret=c.slice(1).map((x,i)=>c[i].c?x.c/c[i].c-1:0),last=Math.abs(ret.at(-1)||0),avg=Math.abs(ret.slice(-20).reduce((a,x)=>a+x,0)/Math.max(1,Math.min(20,ret.length)));const spike=avg>0&&last>avg*3.5,volRisk=w.volatility<30,liqRisk=w.liquidity<32,tfConflict=num(o?.mtfScore,50)<42&&num(o?.confidence,50)>70,score=clamp((spike?30:0)+(volRisk?20:0)+(liqRisk?25:0)+(tfConflict?18:0)+(u.uncertainty>60?20:0),0,100);const flags=[];if(spike)flags.push('ABNORMAL_MOVE');if(volRisk)flags.push('VOLATILITY_STRESS');if(liqRisk)flags.push('LIQUIDITY_LOSS');if(tfConflict)flags.push('TIMEFRAME_CONFLICT');if(u.uncertainty>60)flags.push('HIGH_UNCERTAINTY');return {score,flags,block:score>=Number(adversarialStore().hardBlockThreshold||72),severity:score>=72?'CRITICAL':score>=45?'ELEVATED':'NORMAL'};}
function selfProtection(){const d=driftMonitorStore?.()||{},r=recoveryStore?.()||{},gate=finalSafetyGate?.()||{};const critical=!!(d.critical||d.status==='CRITICAL'||r.status==='CRITICAL');return {enabled:true,critical,kill:critical&&selfProtectionStore().killOnCritical!==false,liveLocked:true,reason:critical?'Critical drift/recovery state detected':'Protection nominal'};}
function decisionGraph(m,o){const w=worldModel(m,o),r=classifyRegime(m,o),u=uncertaintyEngine(m,o),a=adversarialDefense(m,o),cf=counterfactualDecision(m,o),p=predictiveMemory(m,o);return {nodes:[['MARKET',m?.symbol||'UNKNOWN'],['WORLD_MODEL',w.state],['REGIME',r.regime],['EVIDENCE',Math.round(num(o?.dataQuality,0))],['MEMORY',Math.round(p.probability)],['COUNTERFACTUAL',cf.stable?'STABLE':'FRAGILE'],['UNCERTAINTY',u.uncertainty],['ADVERSARIAL',a.severity],['RISK',Math.round(num(o?.riskScore,0))],['FINAL_GATE',finalSafetyGate().autoTradeEligible?'PASS':'BLOCK']],edges:[['MARKET','WORLD_MODEL'],['WORLD_MODEL','REGIME'],['REGIME','EVIDENCE'],['EVIDENCE','MEMORY'],['MEMORY','COUNTERFACTUAL'],['COUNTERFACTUAL','UNCERTAINTY'],['UNCERTAINTY','ADVERSARIAL'],['ADVERSARIAL','RISK'],['RISK','FINAL_GATE']]};}
function agi9Decision(m,o){const w=worldModel(m,o),r=classifyRegime(m,o),u=uncertaintyEngine(m,o),a=adversarialDefense(m,o),p=predictiveMemory(m,o),cf=counterfactualDecision(m,o),sp=selfProtection();const core=engineQualified(m,o),hardBlock=sp.kill||a.block||u.abstain;let action=hardBlock?'ABSTAIN':core?'SUPPORT':'WAIT';return {version:AGI9_VERSION,action,world:w,regime:r,uncertainty:u,adversarial:a,predictive:p,counterfactual:cf,selfProtection:sp,hardBlock,coreQualified:core,graph:decisionGraph(m,o)};}

function renderControlBridgePanel(){
 const host=$('#bgControlBridgeMount .background-mount'); if(!host)return;
 let box=$('#controlBridgePanel'); if(!box){box=document.createElement('section');box.id='controlBridgePanel';box.className='panel';host.appendChild(box);}
 const snap=bridgeSnapshot();
 box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">LOODY’S AI CONTROL BRIDGE v${LSAI_BRIDGE_VERSION}</p><h2>جسر التحكم والتحليل الداخلي</h2><p class="muted">اتصال قراءة فقط بين التطبيق ومركز التحليل. لا توجد صلاحية لتنفيذ شراء أو بيع حقيقي.</p></div><span class="tag">CONNECTED</span></div><div class="performance-results"><article><span>App</span><strong>v${escapeHTML(String(snap.appVersion))}</strong><small>${escapeHTML(String(snap.brainVersion||''))}</small></article><article><span>Universe</span><strong>${snap.universe.toLocaleString()}</strong><small>Spot pairs</small></article><article><span>Scan</span><strong>${snap.analyzed}/${snap.candidates}</strong><small>analyzed / candidates</small></article><article><span>Qualified</span><strong>${snap.qualified}</strong><small>Top ${snap.top}</small></article><article><span>Safety</span><strong>LOCKED</strong><small>Simulation only</small></article></div><p class="meta">آخر heartbeat: ${new Date(snap.timestamp).toLocaleTimeString()} · البيانات المرسلة تشخيصية فقط ولا تشمل مفاتيح API أو أسرار الحساب.</p>`;
}
function renderAGI9Panel(){const host=$('#bgAGI9Mount .background-mount');if(!host)return;let box=$('#agi9Panel');if(!box){box=document.createElement('section');box.id='agi9Panel';box.className='panel';host.appendChild(box)}const m=markets.find(x=>x?.price)||markets[0]||{},o=opportunityScoreSafe(m),d=agi9Decision(m,o);box.innerHTML=`<div class="panel-head"><div><p class="eyebrow">v9.1.3 · INTEGRATED AGI MARKET INTELLIGENCE</p><h2>العقل السوقي المتكامل</h2><p class="muted">World Model → Regime → Memory → Counterfactual → Uncertainty → Adversarial Defense → Risk → Safety. هذه الطبقات لا تتجاوز البوابات الصلبة ولا تنفذ أوامر حقيقية.</p></div><span class="tag">${d.action}</span></div><div class="performance-results"><article><span>World state</span><strong>${escapeHTML(d.world.state)}</strong><small>confidence ${d.world.confidence}</small></article><article><span>Regime</span><strong>${escapeHTML(d.regime.regime)}</strong><small>confidence ${d.regime.confidence}</small></article><article><span>Uncertainty</span><strong>${d.uncertainty.uncertainty}</strong><small>${d.uncertainty.abstain?'ABSTAIN':'within bound'}</small></article><article><span>Adversarial</span><strong>${d.adversarial.score}</strong><small>${escapeHTML(d.adversarial.severity)}</small></article><article><span>Protection</span><strong>${d.selfProtection.kill?'KILL':'READY'}</strong><small>LIVE locked</small></article></div><div class="table-wrap"><table><thead><tr><th>Layer</th><th>Result</th><th>Role</th></tr></thead><tbody>${[['World Model',d.world.state,'market state'],['Regime Intelligence',d.regime.regime,'strategy context'],['Predictive Memory',Number(d.predictive.probability||50).toFixed(1)+'%','historical context'],['Counterfactual',d.counterfactual.stable?'STABLE':'FRAGILE','decision robustness'],['Uncertainty',d.uncertainty.uncertainty,'abstention control'],['Adversarial Defense',d.adversarial.severity,'hard defensive filter'],['Final Action',d.action,'bounded synthesis']].map(x=>`<tr><td>${x[0]}</td><td>${escapeHTML(String(x[1]))}</td><td>${x[2]}</td></tr>`).join('')}</tbody></table></div><p class="meta">القرار النهائي يظل خاضعًا لمحرك Spot الأساسي، جودة البيانات، المخاطر، الحوكمة، وFinal Safety Gate. لا يوجد LIVE execution.</p>`}
function renderAGI9Tabs(){renderAGI9Panel();}

const hadUniverseCache=loadUniverseCache();
mountBackgroundPages();
bindBackgroundCenterTabs();
bindEvidenceCenterTabs();
setTimeout(updateAppRoute,0);
// v7.62: autonomous market discovery/scan starts automatically while the app is open.
// Cloudflare Cron only warms server data; browser-side analysis requires this active client session.
setTimeout(()=>{startBackgroundOrchestrator();},900);
setTimeout(()=>{runEvolutionCycle();},1400);
setInterval(()=>{if(!backgroundBusy)runEvolutionCycle();},Math.max(1,Number(backgroundState?.cycleMinutes||5))*60000);
// v7.24.4: populate the Spot universe automatically on first launch so the chart and pair selectors are not empty.
if(!hadUniverseCache){setTimeout(()=>{discoverUniverse().catch(()=>{});},300);}
syncOpportunityControls();
bindVisibleOpportunityControls();
initChart();
runArchitectureAudit();

/* LOODY’S AI CONTROL BRIDGE v1 — read-only telemetry bridge for assistant diagnostics. */
const LSAI_BRIDGE_VERSION='1.0.0';
function bridgeSnapshot(){
  const safe=(v,d=null)=>{try{return v==null?d:v}catch{return d}};
  const q=typeof currentQualifiedOpportunities==='function'?safe(currentQualifiedOpportunities(),[]):[];
  return {
    bridgeVersion:LSAI_BRIDGE_VERSION, appVersion:APP_VERSION, brainVersion:typeof BRAIN_VERSION!=='undefined'?BRAIN_VERSION:null,
    mode:'simulation-only', spotOnly:true, ordersEnabled:false, liveExecution:false,
    timestamp:Date.now(), universe:Number(universeSymbols?.length||0),
    candidates:Number(lastScanStats?.candidates||0), analyzed:Number(lastScanStats?.analyzed||0),
    qualified:Number(lastScanStats?.qualified||q.length||0), top:Number(lastScanStats?.top||selectedOpportunities?.length||0),
    scanInFlight:!!scanInFlight, backgroundEnabled:!!backgroundState?.enabled,
    selected:Array.isArray(selectedOpportunities)?selectedOpportunities.slice(0,10):[],
    nearMisses:Array.isArray(lastNearMisses)?lastNearMisses.slice(0,10).map(x=>({symbol:x?.m?.symbol||x?.symbol||null,score:x?.score??null,reasons:x?.reasons||[]})):[],
    safety:{liveLocked:true, credentialsConfigured:false, maxOpenPositions:Number(settings?.maxOpenPositions||0), budget:Number(settings?.budget||0)},
  };
}
async function bridgeHeartbeat(){
  try{await fetch('/api/bridge/telemetry',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(bridgeSnapshot()),keepalive:true});}catch{}
}
function startControlBridge(){
  bridgeHeartbeat();
  setInterval(bridgeHeartbeat,30000);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',startControlBridge);else startControlBridge();
